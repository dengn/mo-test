# mo-benchmark

Unified MatrixOne benchmark code, configurations, results, and automated/AI benchmark harnesses.

See [`deploy/`](deploy/) for the dedicated self-hosted Runner and ephemeral
MatrixOne deployment used by automated JSONBench runs.

## TSBS Docker benchmark

[`tsbs/`](tsbs/) contains the TSBS adapters and the multi-engine Docker
profile. The `TSBS Docker benchmark` workflow runs either the scale100/1d smoke
profile or the scale4000/3d/10s reference profile against a selected
MatrixOne, ClickHouse, InfluxDB, TDengine, or TimescaleDB database; its default source directory is
`/data4/pengzhen/tsbs_data/baseline-scale100-1d` and its database bind mounts
are placed below `/data3/pengzhen`. The workflow assigns free host ports for
each run so it can coexist with other runner services. It defaults to the
`cpu-only` workload so the first run is a bounded smoke test. The manual
workflow uses a database drop-down and one checkbox per workload. Multiple
workloads can be checked and are executed sequentially in one run. See the
[TSBS Docker instructions](tsbs/matrixone/README.md#docker-scale1001d-and-scale40003d10s-runs)
for the local command and artifact layout.

## JSONBench

[`jsonbench/`](jsonbench/) contains the JSONBench adapters and the checked-in
result snapshots for MatrixOne, DuckDB, and PostgreSQL. The workload uses the
public Bluesky newline-delimited JSON (NDJSON) dataset and runs five analytical
queries at four scales: 1m, 10m, 100m, and 1000m documents. Each query is
executed three times. The first run at a new scale creates the database, loads
the selected files, executes the queries, and collects row-count and storage
metrics; loading time is not part of the query-runtime result.

The adapter-specific guides are the source of truth for the complete command
options: [MatrixOne](jsonbench/matrixone/README.md),
[DuckDB](jsonbench/duckdb/), and
[PostgreSQL](jsonbench/postgresql/). The commands below are the reproducible
paths used by this repository.

### Dataset location

The dataset is a set of compressed files named `file_0001.json.gz` through
`file_1000.json.gz`. `jsonbench/download_data.sh` downloads the selected prefix
from the public ClickHouse S3 bucket into `~/data/bluesky` by default. A local
run in the server 129 can use any directory containing these files, for example:

```bash
DATA_DIR=/data1/pengzhen/bluesky
```

The 1m/10m/100m/1000m choices consume 1/10/100/1000 files respectively. The
full compressed dataset is about 125 GB and the uncompressed data can require
up to about 425 GB, so the data directory must be outside the Git checkout on
normal benchmark machines. MatrixOne's dev-environment wrapper can instead
read the objects directly from OSS (`oss://mo-bench/bluesky`); it does not
download them to the runner. Credentials for that mode must be supplied
through a deployment-only environment file or environment variables, never
committed to this repository.

### Common run contract

All three adapters accept the scale choice as their first argument:

| Choice | Files | Dataset |
| --- | ---: | ---: |
| `1` | 1 | 1m |
| `2` | 10 | 10m |
| `3` | 100 | 100m |
| `4` | 1000 | 1000m |
| `5` | all | all four scales sequentially |

The remaining arguments are the data directory, success log, error log, and
output prefix. Omitting them starts an interactive scale selection and uses
the adapter defaults. Keep separate prefixes for different servers, versions,
and cache policies so that one run cannot overwrite another.

### MatrixOne

The MatrixOne adapter talks to an already-running MatrixOne MySQL endpoint; it
does not install or start the server. The default connection is
`127.0.0.1:6001`, user `root`. Set the password only in the process
environment (or another secret store):

Use the following `SHARED` file-service cache profile for comparable local
MatrixOne runs:

| Service | Memory cache | Disk cache | Disk path |
| --- | ---: | ---: | --- |
| CN | 20 GB | 8 GB | `mo-data/file-service-cache/cn` |
| TN | 2 GB | 8 GB | `mo-data/file-service-cache/tn` |
| LOG | 1 GB | 8 GB | `mo-data/file-service-cache/log` |

The manual MatrixOne workflow does not modify the MatrixOne checkout. It
extracts `cn.toml`, `tn.toml`, and `log.toml` from the exact image under test,
sets this cache profile, and mounts the generated files read-only over
`/etc/launch/`. Existing `SHARED` storage settings are retained. If an older
config relies on MatrixOne's implicit `SHARED`, the workflow makes the same
defaults explicit (`DISK` at `<data-dir>/shared`) solely so it can attach the
cache settings. It also verifies the image entrypoint, quickstart references,
read-only mounts, and mounted file contents. Original, effective, and live
TOML files are uploaded in the diagnostic artifact.


```bash

cd jsonbench/matrixone
#original data location
export DATA_DIR=/data1/pengzhen/bluesky
export MO_HOST=127.0.0.1
export MO_PORT=6001
export MO_USER=root
export MO_PASSWORD='111'
export MO_LOAD_MODE=direct       # direct, local, or oss

./main.sh 1 "$DATA_DIR" matrixone.success.log matrixone.error.log \
  results/matrixone_local
```

The manual `JSONBench benchmark` workflow can either pull a published
`matrixorigin/matrixone` image or check out and locally build an official
commit, branch, or tag. It supports timed 1m, 10m, or 100m benchmarks.
Each benchmark runs Q1-Q5 three times and uploads its metrics, plans, logs, and
JSON result as an artifact. The 1m and 10m modes also capture an unmeasured
query-result snapshot; 100m skips that additional full pass to avoid several
hours of unmeasured work. The single `matrixone_ref` input is
an image tag/digest in image mode, or a full SHA, branch (for example
`4.2-dev`), or tag in commit mode. The workflow records the resolved 40-character
SHA; use that immutable SHA rather than a moving branch for reproducible runs.
See
[`deploy/matrixone/README.md`](deploy/matrixone/README.md) for its build,
resource, provenance, and cleanup behavior.

Two optional manual inputs run DuckDB 1.1.3 and PostgreSQL 16.6 after
MatrixOne. The engines run sequentially on the same self-hosted Runner so they
do not compete for CPU, memory bandwidth, disk bandwidth, or page cache. The
source dataset is mounted read-only into every container. Database files and
decompression scratch space use workflow-owned Docker volumes that are
removed between engines. The job summary displays each selected engine's
version, loaded row count, storage size, median Q1--Q5 times, and MatrixOne's
relative query speed. Load duration is shown for operational context but is
not included in query runtimes. The artifact retains the full three-run timing matrices,
plans, and logs.

The Summary labels its speed ratios as reference-only. PostgreSQL uses the
five-expression JSONB index declared by its adapter and its container's default
memory settings, while MatrixOne and DuckDB have no corresponding JSON-path
index. Load durations also cover different engine-specific setup work, such as
PostgreSQL index maintenance and `VACUUM ANALYZE`, so they are operational
measurements rather than directly comparable performance scores.

The self-hosted job keeps generated database data, source checkout, artifacts,
and configuration in workflow-owned Docker or Runner temporary resources. Its
final step removes those resources without running a host-wide Docker prune.
Startup retries scoped cleanup from an interrupted run but never uses a stale
state file that could permanently block later benchmarks.


### DuckDB

The repository baseline uses DuckDB **1.1.3**. Install it before the run; the
adapter does not install or uninstall DuckDB as a side effect:

```bash
# already installed verision in server 129
/root/.duckdb/cli/1.1.3/

# install method if you need
curl https://install.duckdb.org | DUCKDB_VERSION=1.1.3 sh

#original data location
export DATA_DIR=/data1/pengzhen/bluesky
export DUCKDB_VERSION=1.1.3
export DUCKDB_CLI_DIR="$HOME/.duckdb/cli/$DUCKDB_VERSION"
# location that duckdb saves data
export DUCKDB_DATA_DIR=/data3/pengzhen/duckdb

cd jsonbench/duckdb
./main.sh 1 "$DATA_DIR" duckdb.success.log duckdb.error.log \
  _local_duckdb
```

DuckDB runs in disk-file mode, not `:memory:`. The database for a scale is
stored as `${DUCKDB_DATA_DIR}/db.duckdb_<files>` and is removed by the normal
cleanup step after the measurements. The NDJSON source remains in `DATA_DIR`.

### PostgreSQL

For local use, the PostgreSQL adapter requires an existing PostgreSQL server
and client; it does not install, start, or remove PostgreSQL. The manual GitHub
Actions workflow instead creates an isolated PostgreSQL 16.6 container and a
short-lived client container, so it does not connect to or modify a host
PostgreSQL installation. A typical local setup is:

```bash
#original data location
export DATA_DIR=/data1/pengzhen/bluesky
export PGHOST=127.0.0.1
export PGPORT=5432
export PGUSER=postgres

cd jsonbench/postgresql
./main.sh 1 "$DATA_DIR" postgres.success.log postgres.error.log \
  results/pg16.6
```

### Results and artifacts

Each run writes raw artifacts next to the adapter command output. The exact
directory is controlled by `OUTPUT_PREFIX`; typical files are:

```text
<prefix>_bluesky_<size>m.count
<prefix>_bluesky_<size>m.total_size
<prefix>_bluesky_<size>m.data_size
<prefix>_bluesky_<size>m.index_size       # when the adapter reports one
<prefix>_bluesky_<size>m.load_seconds
<prefix>_bluesky_<size>m.results_runtime
<prefix>_bluesky_<size>m.physical_query_plans
<prefix>_bluesky_<size>m.query_results    # adapter-dependent
```

`results_runtime` contains five rows of three timings, in seconds, in query
order Q1--Q5. MatrixOne and PostgreSQL stop on query errors; for DuckDB,
inspect the generated runtime log before publishing a snapshot. `count`,
`data_size`, `index_size`, and `total_size` are the adapter-reported values.
Curated JSON snapshots live in each adapter's
`results/` directory and contain the dataset size, loaded-document count,
storage metrics, machine/version metadata, and the five-by-three runtime
matrix. MatrixOne's JSON is produced by `write_result.sh`; DuckDB and
PostgreSQL raw runs can be assembled into the same schema for publication.
`generate-results.sh` consumes these JSON files when rebuilding the benchmark
dashboard.

The repository currently includes these result snapshots (they were collected
on different dates and machines, so they are historical records rather than a
direct performance ranking):

| Adapter | Checked-in snapshots |
| --- | --- |
| MatrixOne local | [1m](jsonbench/matrixone/results/matrixone_local_bluesky_1m.json), [10m](jsonbench/matrixone/results/matrixone_local_bluesky_10m.json), [100m](jsonbench/matrixone/results/matrixone_local_bluesky_100m.json) |
| MatrixOne dev/OSS | [1m](jsonbench/matrixone/results/matrixone_dev_20260824_oss_bluesky_1m.json), [10m](jsonbench/matrixone/results/matrixone_dev_20260824_oss_bluesky_10m.json), [100m partial/Q2 skipped](jsonbench/matrixone/results/matrixone_dev_20260824_oss_bluesky_q2_skipped_bluesky_100m.json) |
| DuckDB 1.1.3 | [1m](jsonbench/duckdb/results/m6i.8xlarge_bluesky_1m.json), [10m](jsonbench/duckdb/results/m6i.8xlarge_bluesky_10m.json), [100m](jsonbench/duckdb/results/m6i.8xlarge_bluesky_100m.json), [1000m](jsonbench/duckdb/results/m6i.8xlarge_bluesky_1000m.json) |
| PostgreSQL 16.6 | [1m](jsonbench/postgresql/results/m6i.8xlarge_bluesky_1m.json), [10m](jsonbench/postgresql/results/m6i.8xlarge_bluesky_10m.json), [100m](jsonbench/postgresql/results/m6i.8xlarge_bluesky_100m.json), [1000m](jsonbench/postgresql/results/m6i.8xlarge_bluesky_1000m.json) |

Storage values are not byte-for-byte equivalent across engines: MatrixOne
reports its logical table metric, DuckDB reports database blocks, and
PostgreSQL reports relation/table and index sizes. Always compare runs with
the same dataset, server version, machine, schema, cache policy, and query
revision, and inspect the raw logs when a load or query is incomplete.

## VectorDBBench

[`vectordbbench/`](vectordbbench/) contains the vendored VectorDBBench
integration for MatrixOne, Qdrant, pgvector, and Milvus. The Docker workflow
starts only the selected database on the self-hosted `mo-srv-129` runner,
mounts a persistent dataset cache, runs the fixed `Performance768D1M` profile
with `k=100` and concurrency `1,10,20`, samples container resources, publishes
metrics to `mo_benchmark`, and uploads raw results and diagnostics. The first
phase compares MatrixOne HNSW/IVF_FLAT, Milvus AUTOINDEX, Qdrant HNSW, and
PostgreSQL + pgvector HNSW. See the [VectorDBBench Docker
instructions](vectordbbench/README.md) for the exact matrix and MatrixOne's
normalized-L2 metric mapping. The other backends keep VDBBench's native
COSINE configuration for this dataset.

## ClickBench

`clickbench/` contains adapters for running the ClickBench workload against
MatrixOne, DuckDB, StarRocks, ClickHouse, and Apache Doris. The workload uses
one `hits` table and 43 analytical queries. All adapters expect the same
ClickBench-compatible source file and row count:

```text
source file: hits.tsv.gz (or hits.tsv)
rows:       99,997,497
```

The compressed file can be used directly. Do not create an uncompressed copy
just for the benchmark. The adapters use different loading mechanisms, but
they can consume `hits.tsv.gz` without a manually prepared uncompressed file.

### Dataset

The repository does not download the data automatically. Prepare the file
separately and pass its absolute path through the adapter-specific variable.
The official ClickBench-compatible files are:

```text
https://datasets.clickhouse.com/hits_compatible/hits.tsv.gz
https://datasets.clickhouse.com/hits_compatible/hits.csv.gz
https://datasets.clickhouse.com/hits_compatible/hits.json.gz
https://datasets.clickhouse.com/hits_compatible/hits.parquet
```

The SQL and loaders in this repository use the TSV layout, so use
`hits.tsv.gz` for the standard comparison. Before a run, verify the file is
the intended dataset:

```bash
ls -lh /data1/pengzhen/hits.tsv.gz
```

### Common benchmark behavior

Run each adapter from its own directory. `benchmark.sh` prepares the database,
loads data when required, executes the 43 queries, records per-query timings
in `result.csv`, reports the data-size value, and runs the concurrency phase
when the adapter enables it. The shared defaults are three tries per query, a
300-second readiness timeout, and a 10-connection/600-second concurrency test
for server-backed adapters.

For a quick smoke test, run one try and skip the long concurrency phase:

```bash
BENCH_TRIES=1 BENCH_CONCURRENT_DURATION=0 ./benchmark.sh
```

The short command checks installation, loading, SQL compatibility, and result
validity. Use the default three tries and concurrency settings for comparable
performance results. `result.csv` contains timing data in the form
`query_number,try_number,seconds`; query output and errors are printed to the
terminal. Save the terminal output separately when a reviewable
`raw_results.md` is needed.

The server-backed adapters use a local single-node deployment. Before a full
run, check that the service is healthy and that the configured data directory
has sufficient free space. The benchmark may restart the service and clear
the OS page cache between cold runs, so the account running it must be able to
run the required local service commands and cache-drop operation. Do not run
multiple adapters against the same ports or data directories at the same
time.

### GitHub Actions

[`clickbench-benchmark.yml`](.github/workflows/clickbench-benchmark.yml) provides
a manual workflow for the five adapters on the `mo-srv-129` self-hosted Linux
runner. It runs the existing adapters directly on the host, so it does not use
Docker, install database packages, or download the ClickBench dataset. Select
the database, provide the absolute path to the shared `hits.tsv.gz`/`hits.tsv`
file, and choose one or three tries. The default run keeps the comparable
ClickBench settings: three tries for all 43 queries, plus ten concurrent
connections for 600 seconds on server-backed systems; embedded DuckDB skips
that phase.

The runner needs passwordless `sudo` for the cold-cache phase. The workflow
uses the native paths documented below: MatrixOne, DuckDB, StarRocks, and
ClickHouse use the tested `/data*`/`/root/.duckdb` locations, while Apache
Doris additionally requires JDK 17, `vm.max_map_count > 2000000`, and disabled
swap. The workflow validates the source file and adapter result, uploads
`result.csv`, metrics, logs, queries, and host metadata, and leaves database
installation and data directories under operator control.

MatrixOne branch/commit runs create a run-scoped shallow checkout before
building the native `mo-service`. A pre-existing `/data3/pengzhen/matrixone`
checkout may be used as a read-only Git object reference, but the workflow
never fetches into or otherwise modifies that shared repository. The isolated
checkout is removed by the run-owned cleanup step.

### Clone repo

```bash

git clone https://github.com/matrixorigin/mo-benchmark.git

```

### MatrixOne

MatrixOne uses a standalone MatrixOne server through its MySQL-compatible
endpoint. The adapter does not download MatrixOne, build it, or download the
ClickBench data. Set the runtime, source-file, connection, and row-count
variables:

etc/launch/cn.toml
```
[fileservice.cache]
memory-capacity = "20GB"
disk-capacity = "8GB"
disk-path = "mo-data/file-service-cache"
```

etc/launch/tn.toml
```
[fileservice.cache]
memory-capacity = "2GB"
disk-capacity = "8GB"
disk-path = "mo-data/file-service-cache"
```

etc/launch/log.toml
```
[[fileservice]]
name = "SHARED"
backend = "DISK-V2"
data-dir = "./mo-data/shared2"

[fileservice.cache]
memory-capacity = "1GB"
disk-capacity = "8GB"
disk-path = "mo-data/file-service-cache"
```

```bash
cd mo-benchmark/clickbench/matrixone

export MATRIXONE_HOME=/data3/pengzhen/matrixone
export MATRIXONE_DATA_FILE=/data3/pengzhen/hits.tsv.gz
export MATRIXONE_HOST=127.0.0.1
export MATRIXONE_PORT=6001
export MATRIXONE_USER=root
export MATRIXONE_PASSWORD='111'
export MATRIXONE_EXPECTED_ROWS=99997497

./benchmark.sh
```

For example, on the existing test host:

```bash
MATRIXONE_HOME=/data3/pengzhen/matrixone \
MATRIXONE_DATA_FILE=/data1/pengzhen/hits.tsv.gz \
./benchmark.sh
```

The loader sends the gzip TSV directly to MatrixOne; decompression is not
required. When `hits.hits` already contains exactly
`MATRIXONE_EXPECTED_ROWS`, the load step is skipped. Check the endpoint before
running:

```bash
mysql -h"$MATRIXONE_HOST" -P"$MATRIXONE_PORT" \
  -u"$MATRIXONE_USER" -p"$MATRIXONE_PASSWORD" -e 'SELECT 1'
```

More MatrixOne-specific details are in
[`clickbench/matrixone/README.md`](clickbench/matrixone/README.md).

### DuckDB

DuckDB is an embedded database, so it does not need FE/BE or a server port.
The adapter requires an installed DuckDB CLI, a database-file path, and the
source-file path:

```bash
cd mo-benchmark/clickbench/duckdb

export DUCKDB_BIN_PATH=/root/.duckdb/cli/1.4.5/duckdb
export DUCKDB_DB_PATH=/data3/pengzhen/duckdb/hits.db
export DUCKDB_DATA_PATH=/data1/pengzhen/hits.tsv.gz

./benchmark.sh
```

DuckDB streams the gzip file while loading and does not retain an
uncompressed copy. Each benchmark load rebuilds the configured database file,
so a subsequent run should be expected to load the data again. Check and
record the installed version:

```bash
"$DUCKDB_BIN_PATH" --version
```

To prepare or inspect it separately:

```bash
DUCKDB_BIN_PATH=/root/.duckdb/cli/1.4.5/duckdb \
DUCKDB_DB_PATH=/data3/pengzhen/hits.db \
DUCKDB_DATA_PATH=/data1/pengzhen/hits.tsv.gz \
./load

printf '%s\n' 'SELECT COUNT(*) FROM hits;' | \
  DUCKDB_BIN_PATH=/root/.duckdb/cli/1.4.5/duckdb \
  DUCKDB_DB_PATH=/data3/pengzhen/hits.db \
  ./query
```

The embedded adapter does not run the server-style concurrency phase. See
[`clickbench/duckdb/README.md`](clickbench/duckdb/README.md) for the complete
DuckDB command set.

### StarRocks

The tested configuration is a single-node StarRocks 4.1.1 deployment: one FE
and one local BE, with metadata and data on local SSD. No S3 or storage
separation is required. Use the binary directory as `STARROCKS_HOME` and
keep metadata/storage in the requested data directory:

For a CentOS installation, replace the installation/data paths and set a
working Java path if required:

```bash
export JAVA_HOME=/usr/local/java17/jdk-23.0.1
export STARROCKS_HOME=/data1/pengzhen/StarRocks-4.1.1-centos-amd64
export STARROCKS_META_DIR=/data3/pengzhen/StarRocks-4.1.1-centos-amd64/meta
export STARROCKS_STORAGE_DIR=/data3/pengzhen/StarRocks-4.1.1-centos-amd64/storage
export STARROCKS_DATA_FILE=/data1/pengzhen/hits.tsv.gz
```

`./install` validates the existing installation and configures FE/BE paths
for a single node; it does not download StarRocks. `./start` starts FE and BE
and registers/checks the backend. A healthy deployment should show the FE and
BE as alive, the BE with `StatusCode: OK`, and no backend error:

```bash
mysql -h"$STARROCKS_FE_HOST" -P"$STARROCKS_QUERY_PORT" \
  -u"$STARROCKS_USER" -e "SHOW PROC '/frontends'\\G; SHOW PROC '/backends'\\G"
```

The loader uses the local gzip TSV through Stream Load. If the table already
has exactly `STARROCKS_EXPECTED_ROWS`, loading is skipped. Use the short
command for the initial smoke test, then run the default command for the
benchmark. See
[`clickbench/starrocks/README.md`](clickbench/starrocks/README.md).

### ClickHouse

The ClickHouse adapter uses an existing local ClickHouse installation and
supports both a monolithic `clickhouse` binary and a separate
`clickhouse-server` binary. It does not automatically install ClickHouse or
download the dataset. Configure the installation, server data directory, and
source file:

```bash
cd mo-benchmark/clickbench/clickhouse

export CLICKHOUSE_HOME=/data1/pengzhen/ClickHouse
export CLICKHOUSE_DATA_DIR=/data3/pengzhen/clickhouse-data
export CLICKHOUSE_DATA_FILE=/data1/pengzhen/hits.tsv.gz
export CLICKHOUSE_HOST=127.0.0.1
export CLICKHOUSE_PORT=9000
export CLICKHOUSE_HTTP_PORT=8123
export CLICKHOUSE_USER=default
export CLICKHOUSE_PASSWORD=
export CLICKHOUSE_DATABASE=default
export CLICKHOUSE_EXPECTED_ROWS=99997497

./benchmark.sh
```

If the binaries are not directly under `CLICKHOUSE_HOME`, set them explicitly:

```bash
export CLICKHOUSE_BIN_PATH=/path/to/clickhouse
export CLICKHOUSE_SERVER_BIN_PATH=/path/to/clickhouse-server
```

The adapter configures/starts the existing server, loads the local gzip TSV,
skips loading when the table row count is exactly
`CLICKHOUSE_EXPECTED_ROWS`, and writes query timings to `result.csv`. The gzip
stream is decompressed while piping data into ClickHouse; no uncompressed
dataset copy is required. The split commands are:

```bash
./install
./start
printf '%s\n' 'SELECT COUNT(*) FROM hits' | ./query
./stop
```

Compatibility note: the current ClickHouse schema contains the
`auto_statistics_types` MergeTree setting. ClickHouse 23.7.1 rejects this
setting with `UNKNOWN_SETTING`; when using that older version, remove/comment
the setting in the generated schema or use a ClickHouse version that supports
it before running the benchmark. See
[`clickbench/clickhouse/README.md`](clickbench/clickhouse/README.md).

### Apache Doris

The tested configuration is Apache Doris 4.1.0 in single-node mode: one FE
and one BE, with metadata and data stored on local SSD. The adapter supports
Ubuntu and CentOS, does not download Doris or the dataset, and loads
`hits.tsv.gz` directly through Stream Load:

```bash
cd mo-benchmark/clickbench/doris

export DORIS_HOME=/data1/pengzhen/apache-doris-4.1.0-bin-x64
export DORIS_META_DIR=/data3/pengzhen/doris-data/meta
export DORIS_STORAGE_DIR=/data3/pengzhen/doris-data/storage
export DORIS_DATA_FILE=/data3/pengzhen/hits.tsv.gz
export DORIS_FE_HOST=127.0.0.1
export DORIS_QUERY_PORT=9030
export DORIS_HTTP_PORT=8030
export DORIS_USER=root
export DORIS_PASSWORD=
export DORIS_DATABASE=hits
export DORIS_TABLE=hits
export DORIS_NODE_IP=127.0.0.1
export DORIS_EXPECTED_ROWS=99997497
./benchmark.sh
```

On CentOS, set `DORIS_JAVA_HOME` to a working JDK 17 installation and replace
the paths. Doris 4.x startup should use JDK 17; do not rely on an unrelated
JDK found under another application directory. The machine prerequisites are
`vm.max_map_count` greater than 2,000,000 and swap disabled. The scripts
check these prerequisites but do not change kernel settings or swap
configuration.

`./install` configures `meta_dir`, `storage_root_path`, local
`priority_networks`, and single-node replication. `./start` starts FE/BE and
registers the BE with the FE; `./check` should show both FE and BE ready. Check
the control plane and backend separately when diagnosing startup:

```bash
mysql -h"$DORIS_FE_HOST" -P"$DORIS_QUERY_PORT" \
  -u"$DORIS_USER" -e 'SHOW FRONTENDS\\G'
mysql -h"$DORIS_FE_HOST" -P"$DORIS_QUERY_PORT" \
  -u"$DORIS_USER" -e 'SHOW BACKENDS\\G'
```

The BE must be `Alive: true` with no error before loading. If the FE is
reachable but there is no available backend, the usual cause is that the BE
has not been registered or has not sent its first heartbeat; wait for
`SHOW BACKENDS` to become healthy before `./load` or `./benchmark.sh`. When
`hits.hits` already has exactly `DORIS_EXPECTED_ROWS`, the load step is
skipped.

Use the short command for the first validation:

```bash
BENCH_TRIES=1 BENCH_CONCURRENT_DURATION=0 ./benchmark.sh
```

Then run `./benchmark.sh` for the standard three-try benchmark. See
[`clickbench/doris/README.md`](clickbench/doris/README.md) for startup logs and
CentOS troubleshooting.

### Comparing results

For a fair comparison, keep the source file, row count, schema, query file,
number of tries, cache policy, and hardware fixed. Record at least the
database version, operating-system version, data-file path, database
data-directory path, load time, 43 query timings, query errors, data-size
value, and concurrency settings. The timing file is adapter-local:

```text
clickbench/<adapter>/result.csv
```

The first successful smoke test proves that the adapter can load and execute
the workload; it is not by itself a comparable performance result. Compare
query results separately from query latency, and investigate any query error
or result mismatch before using the timings.

## MatrixOne Scenario Runner

[`matrixone-scenario-runner/`](matrixone-scenario-runner/) 是一个独立的 MatrixOne
用户场景运行平台。它将 scheduler 与场景 app 分离，支持手动、定时和事件触发，
并将运行状态和结构化结果保存到 MatrixOne。

部署说明已放到组件目录统一维护：

- [设计、配置与 Docker Compose 部署](matrixone-scenario-runner/README.md)
- [Kubernetes / Helm 部署](matrixone-scenario-runner/charts/matrixone-scenario-runner/README.md)
