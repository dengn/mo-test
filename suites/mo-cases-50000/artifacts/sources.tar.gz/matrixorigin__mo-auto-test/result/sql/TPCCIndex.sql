drop table if exists TPCCIndex;
create table if not exists TPCCIndex(
    action_id    bigint       not null,
    run_id       integer,
    db           varchar(20) default 'mo',
    sessionStart           timestamp,
    runMins           integer,
    loadWarehouses           integer,
    runWarehouses           integer,
    numSUTThreads           integer,
    limitTxnsPerMin           integer,
    TpmTOTAL      decimal(12,2)       not null,
    TpmC          decimal(12,2)       not null,
    TpmE          decimal(12,2)       not null,
    result        varchar(20),
    commit_id     varchar(20),
    remark        varchar(100),
  primary key (action_id, run_id, sessionStart)
);