drop table if exists SSBIndex;
create table if not exists SSBIndex(
    action_id    bigint       not null,
    caseN         varchar(50)   not null,
    q1_1           integer,
    q1_2           integer,
    q1_3           integer,
    q2_1           integer,
    q2_2           integer,
    q2_3           integer,
    q3_1           integer,
    q3_2           integer,
    q3_3           integer,
    q3_4          integer,
    q4_1          integer,
    q4_2          integer,
    q4_3          integer,
    starttime    timestamp,
    endtime      timestamp,
    result       varchar(10),
    commit_id    varchar(20),
    remark       varchar(100),
  primary key (action_id, caseN, starttime)
);