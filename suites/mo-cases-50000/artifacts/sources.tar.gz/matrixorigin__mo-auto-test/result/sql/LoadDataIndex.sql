drop table if exists LoadDataIndex;
create table if not exists LoadDataIndex(
    action_id    bigint       not null,
    caseN        varchar(50)   not null,
    cost         integer,
    result       varchar(10),
    starttime    timestamp(6),
    endtime      timestamp(6),
    commit_id    varchar(20),
    remark       varchar(100),
  primary key (action_id, caseN, starttime)
);