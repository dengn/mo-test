drop table if exists SysbenchIndex;
create table if not exists SysbenchIndex(
    action_id    bigint       not null,
    caseN         varchar(50)   not null,
    starttime    timestamp,
    endtime      timestamp,
    vuser       integer       not null,
    rt_max       integer       not null,
    rt_min       integer       not null,
    rt_avg       decimal(12,2)       not null,
    tps       integer       not null,
    qps       integer       not null,
    success       integer       not null,
    error       integer       not null,
    commit_id    varchar(20),
    remark       varchar(100),
  primary key (action_id,caseN,starttime,vuser)
);