drop table if exists TPCCIndexItem;
create table if not exists TPCCIndexItem(
    action_id    bigint       not null,
    run_id       integer  not null,
    sessionStart      timestamp      not null,
    ttype        varchar(20)  not null,
    elapsed         integer      not null,
    latency         integer      not null,
    rbk         integer      not null,
    commit_id    varchar(20),
    remark       varchar(100),
    index (action_id, run_id, sessionStart)
);