drop table if exists SysbenchIndexItem;
create table if not exists SysbenchIndexItem(
    action_id    bigint       not null,
    caseN         varchar(50)   not null,
    vuser       integer       not null,
    starttime     timestamp,
    updatetime    timestamp,
    rt_max       integer       not null,
    rt_min       integer       not null,
    rt_avg       decimal(12,2)       not null,
    tps       integer       not null,
    qps       integer       not null,
    success       integer       not null,
    error       integer       not null,
    remark       varchar(100),
  primary key (action_id, caseN, vuser, starttime,updatetime)
);