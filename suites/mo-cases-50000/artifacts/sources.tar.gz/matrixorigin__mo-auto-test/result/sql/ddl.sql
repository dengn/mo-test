drop table if exists SSBIndex;
create table if not exists SSBIndex(
    action_id    bigint       not null,
    caseN         varchar(50)   not null,
    q1_1           integer,
    q1_2           integer,
    q1_3           integer,
    q2_1           integer,
    q2_2           integer,
    q2_3           integer,
    q3_1           integer,
    q3_2           integer,
    q3_3           integer,
    q3_4          integer,
    q4_1          integer,
    q4_2          integer,
    q4_3          integer,
    starttime    timestamp,
    endtime      timestamp,
    result       varchar(10),
    commit_id    varchar(20),
    remark       varchar(100),
  primary key (action_id, caseN, starttime)
);

drop table if exists SSBIndexItem;
create table if not exists SSBIndexItem(
    action_id    bigint       not null,
    caseN        varchar(20)  not null,
    turn_id      integer      not null,
    query        varchar(10)  not null,
    cost         integer      not null,
    result       varchar(10)  not null,
    qresult      text,
    starttime    timestamp,
    remark       varchar(100),
  primary key (action_id,caseN,turn_id,starttime,query)
);


drop table if exists SysbenchIndex;
create table if not exists SysbenchIndex(
    action_id    bigint       not null,
    caseN         varchar(50)   not null,
    starttime    timestamp,
    endtime      timestamp,
    vuser       integer       not null,
    rt_max       integer       not null,
    rt_min       integer       not null,
    rt_avg       decimal(12,2)       not null,
    tps       integer       not null,
    qps       integer       not null,
    success       integer       not null,
    error       integer       not null,
    commit_id    varchar(20),
    remark       varchar(100),
  primary key (action_id,caseN,starttime,vuser)
);

drop table if exists SysbenchIndexItem;
create table if not exists SysbenchIndexItem(
    action_id    bigint       not null,
    caseN         varchar(50)   not null,
    vuser       integer       not null,
    starttime     timestamp,
    updatetime    timestamp,
    rt_max       integer       not null,
    rt_min       integer       not null,
    rt_avg       decimal(12,2)       not null,
    tps       integer       not null,
    qps       integer       not null,
    success       integer       not null,
    error       integer       not null,
    remark       varchar(100),
  primary key (action_id, caseN, vuser, starttime,updatetime)
);

drop table if exists TPCHIndex;
create table if not exists TPCHIndex(
    action_id    bigint       not null,
    caseN         varchar(50)   not null,
    QppH         decimal(12,2),
    QthH         decimal(12,2),
    QphH         decimal(12,2),
    q1           integer,
    q2           integer,
    q3           integer,
    q4           integer,
    q5           integer,
    q6           integer,
    q7           integer,
    q8           integer,
    q9           integer,
    q10          integer,
    q11          integer,
    q12          integer,
    q13          integer,
    q14          integer,
    q15          integer,
    q16          integer,
    q17          integer,
    q18          integer,
    q19          integer,
    q20          integer,
    q21          integer,
    q22          integer,
    starttime    timestamp,
    endtime      timestamp,
    result       varchar(10),
    commit_id    varchar(20),
    remark       varchar(100),
  primary key (action_id, caseN, starttime)
);

drop table if exists TPCHIndexItem;
create table if not exists TPCHIndexItem(
    action_id    bigint       not null,
    caseN        varchar(20)  not null,
    turn_id      integer      not null,
    query        varchar(10)  not null,
    cost         integer      not null,
    result       varchar(10)  not null,
    qresult      text,
    starttime    timestamp,
    remark       varchar(100),
  primary key (action_id,caseN,turn_id,starttime,query)
);

drop table if exists LoadDataIndex;
create table if not exists LoadDataIndex(
    action_id    bigint       not null,
    caseN        varchar(50)   not null,
    cost         integer,
    result       varchar(10),
    starttime    timestamp(6),
    endtime      timestamp(6),
    commit_id    varchar(20),
    remark       varchar(100),
  primary key (action_id, caseN, starttime)
);

drop table if exists TPCCIndex;
create table if not exists TPCCIndex(
    action_id    bigint       not null,
    run_id       integer,
    db           varchar(20) default 'mo',
    sessionStart           timestamp,
    runMins           integer,
    loadWarehouses           integer,
    runWarehouses           integer,
    numSUTThreads           integer,
    limitTxnsPerMin           integer,
    TpmTOTAL      decimal(12,2)       not null,
    TpmC          decimal(12,2)       not null,
    TpmE          decimal(12,2)       not null,
    result        varchar(20),
    commit_id     varchar(20),
    remark        varchar(100),
  primary key (action_id, run_id, sessionStart)
);

drop table if exists TPCCIndexItem;
create table if not exists TPCCIndexItem(
    action_id    bigint       not null,
    run_id       integer  not null,
    sessionStart      timestamp      not null,
    ttype        varchar(20)  not null,
    elapsed         integer      not null,
    latency         integer      not null,
    rbk         integer      not null,
    commit_id    varchar(20),
    remark       varchar(100),
    index (action_id, run_id, sessionStart)
);

