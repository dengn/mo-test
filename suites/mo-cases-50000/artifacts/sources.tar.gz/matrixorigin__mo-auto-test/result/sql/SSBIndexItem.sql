drop table if exists SSBIndexItem;
create table if not exists SSBIndexItem(
    action_id    bigint       not null,
    caseN        varchar(20)  not null,
    turn_id      integer      not null,
    query        varchar(10)  not null,
    cost         integer      not null,
    result       varchar(10)  not null,
    qresult      text,
    starttime    timestamp,
    remark       varchar(100),
  primary key (action_id,caseN,turn_id,starttime,query)
);