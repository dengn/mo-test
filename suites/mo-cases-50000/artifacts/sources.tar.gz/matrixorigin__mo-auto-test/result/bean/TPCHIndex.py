
class TPCHIndex:
    action_id = 0
    #run_id = 1
    case = ''
    QppH = 0
    QthH = 0
    QphH = 0
    q1 = 0
    q2 = 0
    q3 = 0
    q4 = 0
    q5 = 0
    q6 = 0
    q7 = 0
    q8 = 0
    q9 = 0
    q10 = 0
    q11 = 0
    q12 = 0
    q13 = 0
    q14 = 0
    q15 = 0
    q16 = 0
    q17 = 0
    q18 = 0
    q19 = 0
    q20 = 0
    q21 = 0
    q22 = 0
    starttime = ''
    endtime = '';
    result = 'PASS'
    commit_id = ''
    remark = ''
    qcost = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    qcount = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

    def __init__(self):
        self.qcost = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        self.qcount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    # def __init__(self,case, starttime,endtime,commit_id):
    #     self.case = case
    #     self.starttime = starttime
    #     self.endtime = endtime
    #     self.commit_id = commit_id

    def setActionId(self,action_id):
        self.action_id = action_id

    def getActionId(self):
        return self.action_id

    # def setRunId(self,run_id):
    #     self.run_id = run_id
    #
    # def getRunId(self):
    #     return self.run_id

    def setCase(self,case):
        self.case = case

    def getCase(self):
        return self.case

    def setResult(self,result):
        self.result = result

    def getResult(self):
        return self.result

    def setCommitId(self,commit_id):
        self.commit_id = commit_id

    def getCommitId(self):
        return self.commit_id

    def setRemark(self,remark):
        self.remark = remark

    def getRemark(self):
        return self.remark

    def setCost(self,q,time):
        if(q == 'q1'):
            self.q1 = time;
        if (q == 'q2'):
            self.q2 = time;
        if (q == 'q3'):
            self.q3 = time;
        if (q == 'q4'):
            self.q4 = time;
        if (q == 'q5'):
            self.q5 = time;
        if (q == 'q6'):
            self.q6 = time;
        if (q == 'q7'):
            self.q7 = time;
        if (q == 'q8'):
            self.q8 = time;
        if (q == 'q9'):
            self.q9 = time;
        if (q == 'q10'):
            self.q10 = time;
        if (q == 'q11'):
            self.q11 = time;
        if (q == 'q12'):
            self.q12 = time;
        if (q == 'q13'):
            self.q13 = time;
        if (q == 'q14'):
            self.q14 = time;
        if (q == 'q15'):
            self.q15 = time;
        if (q == 'q16'):
            self.q16 = time;
        if (q == 'q17'):
            self.q17 = time;
        if (q == 'q18'):
            self.q18 = time;
        if (q == 'q19'):
            self.q19 = time;
        if (q == 'q20'):
            self.q20 = time;
        if (q == 'q21'):
            self.q21 = time;
        if (q == 'q22'):
            self.q22 = time;

    def addCost(self,q,time):
        if(q == 'q1'):
            self.qcost[0] = self.qcost[0] + time;
            self.qcount[0] = self.qcount[0] + 1;
        if (q == 'q2'):
            self.qcost[1] = self.qcost[1] + time;
            self.qcount[1] = self.qcount[1] + 1;
        if (q == 'q3'):
            self.qcost[2] = self.qcost[2] + time;
            self.qcount[2] = self.qcount[2] + 1;
        if (q == 'q4'):
            self.qcost[3] = self.qcost[3] + time;
            self.qcount[3] = self.qcount[3] + 1;
        if (q == 'q5'):
            self.qcost[4] = self.qcost[4] + time;
            self.qcount[4] = self.qcount[4] + 1;
        if (q == 'q6'):
            self.qcost[5] = self.qcost[5] + time;
            self.qcount[5] = self.qcount[5] + 1;
        if (q == 'q7'):
            self.qcost[6] = self.qcost[6] + time;
            self.qcount[6] = self.qcount[6] + 1;
        if (q == 'q8'):
            self.qcost[7] = self.qcost[7] + time;
            self.qcount[7] = self.qcount[7] + 1;
        if (q == 'q9'):
            self.qcost[8] = self.qcost[8] + time;
            self.qcount[8] = self.qcount[8] + 1;
        if (q == 'q10'):
            self.qcost[9] = self.qcost[9] + time;
            self.qcount[9] = self.qcount[9] + 1;
        if (q == 'q11'):
            self.qcost[10] = self.qcost[10] + time;
            self.qcount[10] = self.qcount[10] + 1;
        if (q == 'q12'):
            self.qcost[11] = self.qcost[11] + time;
            self.qcount[11] = self.qcount[11] + 1;
        if (q == 'q13'):
            self.qcost[12] = self.qcost[12] + time;
            self.qcount[12] = self.qcount[12] + 1;
        if (q == 'q14'):
            self.qcost[13] = self.qcost[13] + time;
            self.qcount[13] = self.qcount[13] + 1;
        if (q == 'q15'):
            self.qcost[14] = self.qcost[14] + time;
            self.qcount[14] = self.qcount[14] + 1;
        if (q == 'q16'):
            self.qcost[15] = self.qcost[15] + time;
            self.qcount[15] = self.qcount[15] + 1;
        if (q == 'q17'):
            self.qcost[16] = self.qcost[16] + time;
            self.qcount[16] = self.qcount[16] + 1;
        if (q == 'q18'):
            self.qcost[17] = self.qcost[17] + time;
            self.qcount[17] = self.qcount[17] + 1;
        if (q == 'q19'):
            self.qcost[18] = self.qcost[18] + time;
            self.qcount[18] = self.qcount[18] + 1;
        if (q == 'q20'):
            self.qcost[19] = self.qcost[19] + time;
            self.qcount[19] = self.qcount[19] + 1;
        if (q == 'q21'):
            self.qcost[20] = self.qcost[20] + time;
            self.qcount[20] = self.qcount[20] + 1;
        if (q == 'q22'):
            self.qcost[21] = self.qcost[21] + time;
            self.qcount[21] = self.qcount[21] + 1;

    def average(self):
        for i in range(22):
            q = 'q' + str(i + 1)
            if self.qcount[i] == 0:
                continue
            time = self.qcost[i] / self.qcount[i]
            self.setCost(q,int(time))

    def setStarttime(self,starttime):
        self.starttime = starttime

    def getStarttime(self):
        return self.starttime

    def setEndtime(self,endtime):
        self.endtime = endtime

    def setQtpH(self,Qtph):
        self.QthH = Qtph

    def setQtpH(self,QppH):
        self.QppH = QppH

    def setQtpH(self,QphH):
        self.QphH = QphH

    def toString(self):
        return "{0},'{1}',{2},{3},{4},{5},{6},{7},{8}," \
               "{9},{10},{11},{12},{13},{14},{15},{16},{17},{18}," \
               "{19},{20},{21},{22},{23},{24},{25},{26},'{27}','{28}'," \
               "'{29}','{30}','{31}'"\
            .format(self.action_id,self.case,self.QppH,self.QthH,self.QphH,
                    self.q1,self.q2,self.q3,self.q4,self.q5,self.q6,self.q7,self.q8,self.q9,
                    self.q10,self.q11,self.q12,self.q13,self.q14,self.q15,self.q16,self.q17,self.q18,self.q19,
                    self.q20,self.q21,self.q22,self.starttime,self.endtime,self.result,self.commit_id,self.remark)

#tpch = TPCHIndex('TPCH_1G','fdsaf','fasfdsa','fdsafd')
#print(tpch.toString())