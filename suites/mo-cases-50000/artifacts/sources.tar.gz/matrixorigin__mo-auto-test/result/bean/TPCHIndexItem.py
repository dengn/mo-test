class TPCHIndexItem:
    action_id = 0
    case = ''
    turn_id = 1
    query = ''
    cost = 0;
    result = 'PASS'
    qresult = ''
    startTime = ''
    remark = ''

    def __init__(self):
        self.action_id = 0
        self.case = ''
        self.turn_id = 1
        self.query = ''
        self.cost = 0;
        self.result = 'PASS'
        self.qresult = ''
        self.startTime = ''
        self.remark = ''

    def setTurnId(self,turn_id):
        self.turn_id = turn_id

    def getTurnId(self):
        return self.turn_id

    def setCase(self,case):
        self.case = case

    def getCase(self):
        return self.case

    def setActionId(self,action_id):
        self.action_id = action_id

    def getActionId(self):
        return self.action_id

    def setRemark(self,remark):
        self.remark = remark

    def getRemark(self):
        return self.remark

    def setRunId(self,run_id):
        self.run_id = run_id

    def getRunId(self):
        return self.run_id

    def setQuery(self,query):
        self.query = query

    def setCost(self,cost):
        self.cost = cost

    def setResult(self,result):
        self.result = result

    def setQresult(self,qresult):
        self.qresult = qresult

    def setStartTime(self,startTime):
        self.startTime = startTime

    def getStartTime(self):
        return self.startTime

    def toString(self):
        return "{0},'{1}',{2},'{3}',{4},'{5}','{6}','{7}','{8}'".format(self.action_id,self.case,self.turn_id,self.query,self.cost,
                                                        self.result,self.qresult,self.startTime,self.remark)
