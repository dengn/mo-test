
class SSBIndex:
    action_id = 0
    #run_id = 1
    case = ''
    q1_1 = 0
    q1_2 = 0
    q1_3 = 0
    q2_1 = 0
    q2_2 = 0
    q2_3 = 0
    q3_1 = 0
    q3_2 = 0
    q3_3 = 0
    q3_4 = 0
    q4_1 = 0
    q4_2 = 0
    q4_3 = 0
    starttime = ''
    endtime = '';
    result = 'PASS'
    commit_id = ''
    remark = ''
    qname = ['1.1','1.2','1.3','2.1','2.2','2.3','3.1','3.2','3.3','3.4','4.1','4.2','4.3']
    qcost = [0,0,0,0,0,0,0,0,0,0,0,0,0]
    qcount = [0,0,0,0,0,0,0,0,0,0,0,0,0]

    def __init__(self):
        self.qname = ['1.1', '1.2', '1.3', '2.1', '2.2', '2.3', '3.1', '3.2', '3.3', '3.4', '4.1', '4.2', '4.3']
        self.qcost = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
        self.qcount = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

    def setActionId(self,action_id):
        self.action_id = action_id

    def getActionId(self):
        return self.action_id

    # def setRunId(self,run_id):
    #     self.run_id = run_id
    #
    # def getRunId(self):
    #     return self.run_id

    def setCase(self,case):
        self.case = case

    def getCase(self):
        return self.case

    def setResult(self,result):
        self.result = result

    def getResult(self):
        return self.result

    def setCommitId(self,commit_id):
        self.commit_id = commit_id

    def getCommitId(self):
        return self.commit_id

    def setRemark(self,remark):
        self.remark = remark

    def getRemark(self):
        return self.remark

    def setCost(self,q,time):
        if(q == 'q1.1'):
            self.q1_1 = time;
        if (q == 'q1.2'):
            self.q1_2 = time;
        if (q == 'q1.3'):
            self.q1_3 = time;
        if (q == 'q2.1'):
            self.q2_1 = time;
        if (q == 'q2.2'):
            self.q2_2 = time;
        if (q == 'q2.3'):
            self.q2_3 = time;
        if (q == 'q3.1'):
            self.q3_1 = time;
        if (q == 'q3.2'):
            self.q3_2 = time;
        if (q == 'q3.3'):
            self.q3_3 = time;
        if (q == 'q3.4'):
            self.q3_4 = time;
        if (q == 'q4.1'):
            self.q4_1 = time;
        if (q == 'q4.2'):
            self.q4_2 = time;
        if (q == 'q4.3'):
            self.q4_3 = time;

    def addCost(self,q,time):
        if(q == 'q1.1'):
            self.qcost[0] = self.qcost[0] + time;
            self.qcount[0] = self.qcount[0] + 1;
        if (q == 'q1.2'):
            self.qcost[1] = self.qcost[1] + time;
            self.qcount[1] = self.qcount[1] + 1;
        if (q == 'q1.3'):
            self.qcost[2] = self.qcost[2] + time;
            self.qcount[2] = self.qcount[2] + 1;
        if (q == 'q2.1'):
            self.qcost[3] = self.qcost[3] + time;
            self.qcount[3] = self.qcount[3] + 1;
        if (q == 'q2.2'):
            self.qcost[4] = self.qcost[4] + time;
            self.qcount[4] = self.qcount[4] + 1;
        if (q == 'q2.3'):
            self.qcost[5] = self.qcost[5] + time;
            self.qcount[5] = self.qcount[5] + 1;
        if (q == 'q3.1'):
            self.qcost[6] = self.qcost[6] + time;
            self.qcount[6] = self.qcount[6] + 1;
        if (q == 'q3.2'):
            self.qcost[7] = self.qcost[7] + time;
            self.qcount[7] = self.qcount[7] + 1;
        if (q == 'q3.3'):
            self.qcost[8] = self.qcost[8] + time;
            self.qcount[8] = self.qcount[8] + 1;
        if (q == 'q3.4'):
            self.qcost[9] = self.qcost[9] + time;
            self.qcount[9] = self.qcount[9] + 1;
        if (q == 'q4.1'):
            self.qcost[10] = self.qcost[10] + time;
            self.qcount[10] = self.qcount[10] + 1;
        if (q == 'q4.2'):
            self.qcost[11] = self.qcost[11] + time;
            self.qcount[11] = self.qcount[11] + 1;
        if (q == 'q4.3'):
            self.qcost[12] = self.qcost[12] + time;
            self.qcount[12] = self.qcount[12] + 1;

    def average(self):
        for i in range(13):
            q = 'q' + self.qname[i]
            if self.qcount[i] == 0:
                continue
            time = self.qcost[i] / self.qcount[i]
            self.setCost(q,int(time))

    def setStarttime(self,starttime):
        self.starttime = starttime

    def getStarttime(self):
        return self.starttime

    def setEndtime(self,endtime):
        self.endtime = endtime

    def toString(self):
        return "{0},'{1}',{2},{3},{4},{5},{6},{7},{8}," \
               "{9},{10},{11},{12},{13},{14},'{15}','{16}'," \
               "'{17}','{18}','{19}'"\
            .format(self.action_id,self.case,
                    self.q1_1,self.q1_2,self.q1_3,self.q2_1,self.q2_2,self.q2_3,self.q3_1,self.q3_2,self.q3_3,
                    self.q3_4,self.q4_1,self.q4_2,self.q4_3,self.starttime,self.endtime,self.result,self.commit_id,self.remark)
