
class VectorIndexItem:
    action_id = 0
    sessionStart = ''
    commit_id = ''
    remark = ''
    caseN = ''
    starttime = ''
    recall = 0
    totalduration = 0
    p95_time = 0
    qps = 0


    def __init__(self):
        self.action_id = 0
        self.startTime = ''
        self.commit_id = ''
        self.remark = ''
        self.caseN = ''
        self.recall = 0
        self.totalduration = 0
        self.p95_time = 0
        self.qps = 0

    def setActionId(self,action_id):
        self.action_id = action_id

    def getActionId(self):
        return self.action_id

    def setStartTime(self,startTime):
        self.startTime = startTime

    def getStartTime(self):
        return self.startTime

    def setP95time(self,p95_time):
        self.p95_time = p95_time

    def getP95time(self):
        return self.p95_time

    def setCommitId(self,commit_id):
        self.commit_id = commit_id

    def getCommitId(self):
        return self.commit_id

    def setRemark(self,remark):
        self.remark = remark

    def getRemark(self):
        return self.remark

    def setRecall(self,recall):
        self.recall = recall

    def getRecall(self):
        return self.recall

    def setTotalduration(self,totalduration):
        self.totalduration = totalduration

    def getTotalduration(self):
        return self.totalduration

    def setQPS(self,qps):
        self.qps = qps

    def getQPS(self):
        return self.qps

    def setCaseN(self,caseN):
        self.caseN = caseN

    def getCaseN(self):
        return self.caseN

    def toString(self):
        return "{0},'{1}','{2}','{3}',{4},{5},{6}," \
               "{7},'{8}'"\
            .format(self.action_id,
                    self.startTime,
                    self.commit_id,self.caseN,self.recall,self.totalduration,self.p95_time,self.qps,self.remark)
