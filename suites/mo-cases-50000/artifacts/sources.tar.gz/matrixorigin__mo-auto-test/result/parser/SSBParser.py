import os.path
import logging as log
from bean.SSBIndex import SSBIndex
from bean.SSBIndexItem import SSBIndexItem

ssbIndex = SSBIndex()
ssbIndexItems = []

def parseMeta(path):
    metaFile = path + '/.meta'
    if(not os.path.isfile(metaFile)):
        log.error("There is no .meta file in SSB result data[{0}], please check".format(path))
        return None

    meta = open(metaFile)
    metaItem = meta.readlines();

    if( metaItem[0] == None or metaItem[0] == ''):
        log.error("The content of  .meta file in SSB result data[{0} is incorrect, please check".format(metaFile))
        return None

    if (metaItem[1] == None or metaItem[1] == ''):
        log.error("The content of  .meta file in SSB result data[{0} is incorrect, please check".format(metaFile))
        return None

    if  (metaItem[2] == None or metaItem[2] == ''):
        log.error("The content of  .meta file in SSB result data[{0} is incorrect, please check".format(metaFile))
        return None

    if ( metaItem[3] == None or metaItem[3] == ''):
        log.error("The content of  .meta file in SSB result data[{0} is incorrect, please check".format(metaFile))
        return None


    ssbIndex.setCase(metaItem[0].rstrip())
    ssbIndex.setStarttime(metaItem[1].rstrip())
    ssbIndex.setEndtime(metaItem[2].rstrip())
    ssbIndex.setResult(metaItem[3].rstrip())

    costFile = path +'/cost.txt'
    if(os.path.isfile(costFile)):
        cost = open(costFile)
        queryCosts = cost.readlines()
        for query in queryCosts:
            if(query.startswith('turn')):
                continue
            item = query.split(" ")
            ssbIndex.setCost(item[0].rstrip(),(int)(item[1].rstrip()))
            if(item[2].rstrip() == '1'):
                ssbIndex.setResult('FAILED')
    return ssbIndex;

def parseDetail(path):
    costFile = path + '/cost.txt'
    if (os.path.isfile(costFile)):
        cost = open(costFile)
        queryCosts = cost.readlines()
        queryCosts.sort()

        #parse turn info
        turn = 1
        turnLine = queryCosts[len(queryCosts) - 1]
        if(turnLine.startswith('turn')):
            turnInfo = turnLine.split(" ")
            turn = int(turnInfo[1].rstrip())
            queryCosts.remove(turnLine)

        for query in queryCosts:
            ssbIndexItem = SSBIndexItem()
            ssbIndexItem.setActionId(ssbIndex.getActionId())
            ssbIndexItem.setStartTime(ssbIndex.getStarttime())
            ssbIndexItem.setCase(ssbIndex.getCase())
            ssbIndexItem.setTurnId(turn)
            ssbIndexItem.setRemark(ssbIndex.getRemark())
            try:
                item = query.split(" ")
                ssbIndexItem.setQuery(item[0])
                ssbIndexItem.setCost(int(item[1]))
                if (item[2].rstrip() == '1'):
                    ssbIndexItem.setResult('FAILED')
                else:
                    ssbIndexItem.setResult('PASS')
                ssbIndex.addCost(item[0],int(item[1]))
            except Exception as e:
                log.error("The cost file[{0}] is not well-formated,please check.".format(costFile) + e)
                return None
            #log.info("SSBIndexItem Record: {0}".format(ssbIndexItem.toString()))
            ssbIndexItems.append(ssbIndexItem)

    if (not os.path.isfile(costFile)):
        subFiles = os.listdir(path);
        subFiles.sort()
        for dir in subFiles:
            if(os.path.isdir(path + "/" + dir)):
                parseDetail(path + "/" + dir)

# aa = parseMeta();
# print(aa.toString())

