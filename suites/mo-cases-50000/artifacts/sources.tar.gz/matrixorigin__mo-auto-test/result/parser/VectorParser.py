import os.path
import logging as log
import shutil
from bean.VectorIndexItem import VectorIndexItem
import util.ConfigUtil as config
import datetime
import re

vectorIndexItems = []
VectorPath = config.getVectorResultPath()

def parseDetail_old(path):
    resultFile = path
    results_tmp_file = os.path.join('.temp/vector/report','results.csv')
    if (not os.path.isfile(resultFile)):
        log.error("There is no file in Vector result data[{0}], please check".format(path))
        return None
    os.system("tail -1 {0} > {1}".format(resultFile, results_tmp_file))
    CaseN = os.path.basename(resultFile)
    result = open(results_tmp_file)
    lines = result.readlines()
    for itemLine in lines:
        vectorIndexItem = VectorIndexItem()
        indexItems = itemLine.split(',')
        vectorIndexItem.setCaseN(CaseN.split('.')[0])
        vectorIndexItem.setRecall(str(indexItems[0].split(':')[1].strip()))
        vectorIndexItem.setTotalduration(str(indexItems[1].split(':')[1].strip()[:-1]))
        vectorIndexItem.setLatency(str(indexItems[2].split(':')[1].strip()))
        vectorIndexItem.setQPS(str(indexItems[3].split(':')[1].strip()))
        vectorIndexItem.setStartTime(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
        vectorIndexItems.append(vectorIndexItem)
    return vectorIndexItems

def parseDetail(path,action_id,commit_id,branch):
    resultFile = path
    if (not os.path.isfile(resultFile)):
        log.error("There is no file in Vector result data[{0}], please check".format(path))
        return None
    CaseN = os.path.basename(resultFile)
    result = open(resultFile)
    lines = result.readlines()
    vectorIndexItem = VectorIndexItem()
    linecount=0
    for itemLine in lines:
        if re.search(r'MatrixOne.*', itemLine):
            indexItems = itemLine.split(',')
            vectorIndexItem.setCaseN(CaseN.split('.')[0] + '_p' + indexItems[1].split('=')[1].split(')')[0])
            vectorIndexItem.setRecall(str(lines[linecount+2].split(':')[1].strip()))
            vectorIndexItem.setQPS(str(lines[linecount+9].split(':')[1].strip()))
            vectorIndexItem.setP95time(str(lines[linecount+11].split(':')[1].strip()))
            vectorIndexItem.setTotalduration(str(0))
            vectorIndexItem.setStartTime(str(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))
            vectorIndexItem.setActionId(action_id)
            vectorIndexItem.setCommitId(commit_id)
            vectorIndexItem.setRemark(branch)
            vectorIndexItems.append(vectorIndexItem.toString())
        linecount += 1
    return vectorIndexItems

# aa = parseMeta();
# print(aa.toString())

