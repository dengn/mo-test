import os.path
import logging as log
from bean.TPCHIndex import TPCHIndex
from bean.TPCHIndexItem import TPCHIndexItem

tpchIndex = TPCHIndex()
tpchIndexItems = []

def parseMeta(path):
    metaFile = path + '/.meta'
    if(not os.path.isfile(metaFile)):
        log.error("There is no .meta file in TPCH result data[{0}], please check".format(path))
        return None

    meta = open(metaFile)
    metaItem = meta.readlines();

    if( metaItem[0] == None or metaItem[0] == ''):
        log.error("The content of  .meta file in TPCH result data[{0} is incorrect, please check".format(metaFile))
        return None

    if (metaItem[1] == None or metaItem[1] == ''):
        log.error("The content of  .meta file in TPCH result data[{0} is incorrect, please check".format(metaFile))
        return None

    if  (metaItem[2] == None or metaItem[2] == ''):
        log.error("The content of  .meta file in TPCH result data[{0} is incorrect, please check".format(metaFile))
        return None

    if ( metaItem[3] == None or metaItem[3] == ''):
        log.error("The content of  .meta file in TPCH result data[{0} is incorrect, please check".format(metaFile))
        return None


    tpchIndex.setCase(metaItem[0].rstrip())
    tpchIndex.setStarttime(metaItem[1].rstrip())
    tpchIndex.setEndtime(metaItem[2].rstrip())
    tpchIndex.setResult(metaItem[3].rstrip())

    costFile = path +'/cost.txt'
    if(os.path.isfile(costFile)):
        cost = open(costFile)
        queryCosts = cost.readlines()
        for query in queryCosts:
            if(query.startswith('turn')):
                continue
            item = query.split(" ")
            tpchIndex.setCost(item[0].rstrip(),(int)(item[1].rstrip()))
            if(item[2].rstrip() == '1'):
                tpchIndex.setResult('FAILED')
    return tpchIndex;

def parseDetail(path):
    costFile = path + '/cost.txt'
    if (os.path.isfile(costFile)):
        cost = open(costFile)
        queryCosts = cost.readlines()
        queryCosts.sort()

        #parse turn info
        turn = 1
        turnLine = queryCosts[len(queryCosts) - 1]
        if(turnLine.startswith('turn')):
            turnInfo = turnLine.split(" ")
            turn = int(turnInfo[1].rstrip())
            queryCosts.remove(turnLine)

        for query in queryCosts:
            tpchIndexItem = TPCHIndexItem()
            tpchIndexItem.setActionId(tpchIndex.getActionId())
            tpchIndexItem.setStartTime(tpchIndex.getStarttime())
            tpchIndexItem.setCase(tpchIndex.getCase())
            tpchIndexItem.setTurnId(turn)
            tpchIndexItem.setRemark(tpchIndex.getRemark())
            try:
                item = query.split(" ")
                tpchIndexItem.setQuery(item[0])
                tpchIndexItem.setCost(int(item[1]))
                if (item[2].rstrip() == '1'):
                    tpchIndexItem.setResult('FAILED')
                else:
                    tpchIndexItem.setResult('PASS')
                tpchIndex.addCost(item[0],int(item[1]))
            except Exception as e:
                log.error("The cost file[{0}] is not well-formated,please check.".format(costFile) + e)
                return None
            #log.info("TPCHIndexItem Record: {0}".format(tpchIndexItem.toString()))
            tpchIndexItems.append(tpchIndexItem)

    if (not os.path.isfile(costFile)):
        subFiles = os.listdir(path);
        subFiles.sort()
        for dir in subFiles:
            if(os.path.isdir(path + "/" + dir)):
                parseDetail(path + "/" + dir)


# aa = parseMeta();
# print(aa.toString())

