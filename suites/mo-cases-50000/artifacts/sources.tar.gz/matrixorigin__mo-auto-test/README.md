# mo-auto-test

## Wiki-10M on TKE

Run **Wiki-10M On TKE** (`mo-wiki-10m-tke.yaml`) manually after the workflow
lands on main. Supply `Repo` (for example `aunjgr/matrixone`), a full lowercase
40-character `Commit_Id`, and `Wiki_Cases`: `l2_filter_threshold_pre` (default)
or `all` (six L2/pre/post combinations).

Two optional comparison controls retain the original concurrency-100,
local-DOP-off default:

| Input | Values | Default |
| --- | --- | --- |
| `Wiki_Local_DOP` | `off`, `on`, `both` | `off` |
| `Wiki_Concurrency` | `1`, `100`, `both` | `100` |

`on` sets `optimizer_hints='vectorLocalDOP=1'`; `off` explicitly sets
`vectorLocalDOP=0`. Other configured hints are preserved. The pinned benchmark
passes `cfg.env` into `--session-env-json` and applies it to each worker's
connection, including concurrency 1. The runner rejects a run if any worker
logs a session-initialization warning or the applied DOP hint is not confirmed.

The workflow reuses the existing image build and three-CN TKE deployment. It
loads the remote Wiki-10M CSV from COS, builds IVFFlat with 3,162 lists, and
runs 10,000 queries, top-10, twice per selected case/DOP/concurrency combination.
Setup and index training run only once per dispatch, even when either control
is `both`. DOP order is off/on in round 1 and on/off in round 2. All combinations
share server caches; these are measured passes, not controlled cold/warm phases.
`probe_limit=5` and `ivf_preload_entries=0` match the nightly workload.
The benchmark repository is pinned to
`0bae04528673d7756c4ee2478ac8e4e41f54df1b`.

Each attempt uses a run-specific namespace; cluster cleanup waits for the Wiki
job, including failures. Other benchmark suites are disabled. This is an
expensive remote build/load/index/benchmark run, with a 200-minute benchmark
job timeout. Existing TKE runners, registry and COS credentials are required.

Download the `wiki-10m-RUN_ID-ATTEMPT` artifact for setup output,
per-case/DOP/concurrency/round recall logs, target/benchmark revisions, server
version, pod placement, and
before/after resource samples. Log names include `dop-0`/`dop-1` and `c1`/`c100`.
The version-2 manifest records the requested axes, session settings and planned
run order; `run-matrix.tsv` is the execution schedule. Reports are artifacts
only; this entry point does not publish Wiki results into the nightly
performance baseline database.
Before/after `kubectl top` samples are **not** CPU-time or peak-RSS measurements.
Use the deployment's monitoring system when those acceptance metrics are needed.

For the exact-PRE/local-DOP comparison, run a pinned main SHA with DOP `off` and
concurrency `both` (A), then the PR SHA with both controls set to `both` (B=off,
C=on). This loads the full 10M dataset once per revision, not once per arm.
Use the same case selector and compare B versus A separately from C versus B.
The DOP setting is an opt-in hint, **not evidence that readers actually ran in
parallel**: verify representative execution plans and observed DOP separately.
Old revisions may ignore the hint, and eligible newer revisions can still
choose one reader because of cost or resource caps.

Compare the manifests and actual pod placements before comparing latency/QPS
and recall. The workflow serializes
its own runs without cancelling the active one; do not queue multiple pending
runs because GitHub concurrency can replace an older pending run.

The lightweight **Wiki-10M Contract** PR check runs offline validation without a
database, dataset, cluster or credentials. To run it locally (Python and PyYAML):

```sh
python3 script/tke/test_wiki_10m.py
bash -n script/tke/run_wiki_10m.sh
```
