#!/usr/bin/env python3

"""Render the MySQL CDC type-test DDL for an explicit table contract.

The upstream fixture contains commercial and currently out-of-scope table
shapes in one file.  Filtering only the Flink producer list is insufficient:
an out-of-scope DDL failure would still gate the general nightly.  This small
renderer keeps every database/session statement, and keeps a table statement
only when every referenced ``t_*`` fixture table belongs to the requested set.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path


TABLE_TOKEN = re.compile(r"\bt_[A-Za-z0-9_]+\b")
CREATE_TABLE = re.compile(
    r"\bcreate\s+table\s+(?:if\s+not\s+exists\s+)?"
    r"(?:`?[A-Za-z_][A-Za-z0-9_]*`?\.)?`?(t_[A-Za-z0-9_]+)`?",
    re.IGNORECASE | re.DOTALL,
)


def replace_unquoted_token(sql: str, source: str, target: str) -> str:
    """Replace an SQL identifier outside strings, identifiers and comments."""
    output: list[str] = []
    quote = ""
    escaped = False
    line_comment = False
    block_comment = False
    index = 0
    source_lower = source.lower()
    while index < len(sql):
        char = sql[index]
        following = sql[index + 1] if index + 1 < len(sql) else ""
        if line_comment:
            output.append(char)
            if char == "\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            output.append(char)
            if char == "*" and following == "/":
                output.append(following)
                block_comment = False
                index += 2
            else:
                index += 1
            continue
        if quote:
            output.append(char)
            if escaped:
                escaped = False
            elif char == "\\" and quote in ("'", '"'):
                escaped = True
            elif char == quote:
                if following == quote:
                    output.append(following)
                    index += 2
                    continue
                quote = ""
            index += 1
            continue
        if char in ("'", '"', "`"):
            quote = char
            output.append(char)
            index += 1
            continue
        if char == "#" or (char == "-" and following == "-"):
            line_comment = True
            output.append(char)
            if char == "-":
                output.append(following)
                index += 2
            else:
                index += 1
            continue
        if char == "/" and following == "*":
            block_comment = True
            output.extend((char, following))
            index += 2
            continue
        candidate = sql[index : index + len(source)]
        before = sql[index - 1] if index else ""
        after_index = index + len(source)
        after = sql[after_index] if after_index < len(sql) else ""
        if (
            candidate.lower() == source_lower
            and not (before.isalnum() or before == "_")
            and not (after.isalnum() or after == "_")
        ):
            output.append(target)
            index = after_index
            continue
        output.append(char)
        index += 1
    return "".join(output)


def split_statements(sql: str) -> list[str]:
    statements: list[str] = []
    start = 0
    quote = ""
    escaped = False
    line_comment = False
    block_comment = False
    index = 0
    while index < len(sql):
        char = sql[index]
        following = sql[index + 1] if index + 1 < len(sql) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
            index += 1
            continue
        if block_comment:
            if char == "*" and following == "/":
                block_comment = False
                index += 2
            else:
                index += 1
            continue
        if quote:
            if escaped:
                escaped = False
            elif char == "\\" and quote in ("'", '"'):
                escaped = True
            elif char == quote:
                # SQL escapes a quote by doubling it.
                if following == quote:
                    index += 2
                    continue
                quote = ""
            index += 1
            continue
        if char in ("'", '"', "`"):
            quote = char
        elif char == "#":
            line_comment = True
        elif char == "-" and following == "-":
            line_comment = True
            index += 1
        elif char == "/" and following == "*":
            block_comment = True
            index += 1
        elif char == ";":
            statement = sql[start : index + 1].strip()
            if statement:
                statements.append(statement)
            start = index + 1
        index += 1
    remainder = sql[start:].strip()
    if remainder:
        statements.append(remainder)
    if quote or block_comment:
        raise ValueError("unterminated quote or block comment in CDC DDL")
    return statements


def without_comments(sql: str) -> str:
    output: list[str] = []
    quote = ""
    escaped = False
    line_comment = False
    block_comment = False
    index = 0
    while index < len(sql):
        char = sql[index]
        following = sql[index + 1] if index + 1 < len(sql) else ""
        if line_comment:
            if char == "\n":
                line_comment = False
                output.append(char)
            index += 1
            continue
        if block_comment:
            if char == "*" and following == "/":
                block_comment = False
                output.append(" ")
                index += 2
            else:
                index += 1
            continue
        if quote:
            output.append(char)
            if escaped:
                escaped = False
            elif char == "\\" and quote in ("'", '"'):
                escaped = True
            elif char == quote:
                if following == quote:
                    output.append(following)
                    index += 2
                    continue
                quote = ""
            index += 1
            continue
        if char in ("'", '"', "`"):
            quote = char
            output.append(char)
        elif char == "#" or (char == "-" and following == "-"):
            line_comment = True
            if char == "-":
                index += 1
        elif char == "/" and following == "*":
            block_comment = True
            index += 1
        else:
            output.append(char)
        index += 1
    return "".join(output)


def render(sql: str, database: str, tables: set[str], dialect: str = "mysql") -> str:
    tables = {table.lower() for table in tables}
    emitted: list[str] = []
    created: set[str] = set()
    for statement in split_statements(sql.replace("__DB__", database)):
        executable = without_comments(statement)
        referenced = {table.lower() for table in TABLE_TOKEN.findall(executable)}
        if referenced and not referenced.issubset(tables):
            continue
        match = CREATE_TABLE.search(executable)
        if match:
            created.add(match.group(1).lower())
        if dialect == "matrixone":
            statement = replace_unquoted_token(
                statement, "utf8mb4_0900_ai_ci", "utf8mb4_general_ci"
            )
        emitted.append(statement)
    missing = sorted(tables - created)
    if missing:
        raise ValueError(f"requested CDC tables are absent from DDL: {','.join(missing)}")
    return "\n\n".join(emitted) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--database", required=True)
    parser.add_argument("--tables", required=True)
    parser.add_argument("--dialect", choices=("mysql", "matrixone"), default="mysql")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", args.database):
        raise ValueError("unsafe CDC database identifier")
    tables = set(args.tables.split(","))
    if not tables or any(
        not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]{0,63}", table)
        for table in tables
    ):
        raise ValueError("unsafe CDC table contract")
    print(
        render(
            args.input.read_text(encoding="utf-8"),
            args.database,
            tables,
            dialect=args.dialect,
        ),
        end="",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
