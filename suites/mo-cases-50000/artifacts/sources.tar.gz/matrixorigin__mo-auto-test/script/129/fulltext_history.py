#!/usr/bin/env python3
"""Validate one retained FULLTEXT2 artifact and publish structured history."""

import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence, Tuple

import pymysql
import yaml


PARSERS = ("ngram", "gojieba")
SCENARIOS = (
    "natural_short",
    "natural_normal",
    "natural_mixed",
    "boolean_must",
    "bm25_bow",
)
QUERY_MODES = {
    "natural_short": "natural-language",
    "natural_normal": "natural-language",
    "natural_mixed": "natural-language",
    "boolean_must": "boolean-must",
    "bm25_bow": "bm25-bag-of-words",
}
SESSION_VARIABLES = {
    "experimental_fulltext2_index": "1",
    "ft2_relevancy_algorithm": "BM25",
    "fulltext_bloom_filter_pushdown": "1",
}
MEASUREMENT_CONTRACT_VERSION = "fulltext2-positional-v1"
BACKFILL_ACTION_ID = 32265088926
TARGET_DATABASE = "test_nightly"
TRANSIENT_MYSQL_CODES = {1062, 1205, 1213, 2002, 2003, 2006, 2013}
REPOSITORY_ROOT = Path(__file__).resolve().parents[2]
VERIFIER = REPOSITORY_ROOT / "script" / "fulltext_ngram" / "verify_regression_result.py"


class HistoryError(RuntimeError):
    """The artifact or publication contract is invalid."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise HistoryError(message)


def read_regular_text(path: Path) -> str:
    require(path.is_file() and not path.is_symlink(), f"required file is missing or indirect: {path}")
    return path.read_text(encoding="utf-8")


def read_tsv(path: Path, required_columns: Sequence[str]) -> List[Dict[str, str]]:
    require(path.is_file() and not path.is_symlink(), f"required TSV is missing or indirect: {path}")
    with path.open(encoding="utf-8", newline="") as source:
        reader = csv.DictReader(source, delimiter="\t")
        columns = reader.fieldnames or []
        missing = [column for column in required_columns if column not in columns]
        require(not missing, f"{path.name} is missing columns: {','.join(missing)}")
        return list(reader)


def parse_key_values(path: Path) -> Dict[str, str]:
    values: Dict[str, str] = {}
    for line in read_regular_text(path).splitlines():
        key, separator, value = line.partition("=")
        if separator and key and key.replace("_", "").isalnum():
            require(key not in values, f"duplicate key {key!r} in {path.name}")
            values[key] = value
    return values


def required_value(values: Mapping[str, str], key: str, source: str) -> str:
    value = values.get(key, "")
    require(bool(value), f"{source} is missing {key}")
    return value


def parse_positive_int(value: str, label: str, *, allow_zero: bool = False) -> int:
    require(value.isdigit(), f"{label} is not an unsigned integer")
    parsed = int(value)
    require(parsed >= 0 if allow_zero else parsed > 0, f"{label} is out of range")
    return parsed


def parse_decimal(value: str, label: str, *, allow_zero: bool = True) -> Decimal:
    try:
        parsed = Decimal(value)
    except InvalidOperation as error:
        raise HistoryError(f"{label} is not numeric") from error
    require(parsed.is_finite(), f"{label} is not finite")
    require(parsed >= 0 if allow_zero else parsed > 0, f"{label} is out of range")
    require(parsed.as_tuple().exponent >= -6, f"{label} has more than six decimal places")
    require(parsed <= Decimal("99999999999999.999999"), f"{label} exceeds DECIMAL(20,6)")
    return parsed


def require_hash(value: str, label: str) -> str:
    require(len(value) == 64, f"{label} is not a SHA-256 digest")
    try:
        bytes.fromhex(value)
    except ValueError as error:
        raise HistoryError(f"{label} is not a SHA-256 digest") from error
    return value.lower()


def require_commit(value: str, label: str) -> str:
    require(len(value) == 40, f"{label} is not a full Git commit")
    try:
        bytes.fromhex(value)
    except ValueError as error:
        raise HistoryError(f"{label} is not a full Git commit") from error
    return value.lower()


def normalize_artifact_root(path: Path) -> Tuple[Path, Path]:
    require(not path.is_symlink(), f"artifact root is indirect: {path}")
    root = path.resolve()
    require(root.is_dir(), f"artifact root is missing: {root}")
    if (root / "slot-a").is_dir():
        require(not (root / "slot-a").is_symlink(), "retained slot-a directory is indirect")
        return root, root / "slot-a"
    require(root.name == "slot-a", "artifact must contain the retained slot-a directory")
    return root.parent, root


def parse_manifest(path: Path) -> Dict[str, Any]:
    try:
        payload = json.loads(read_regular_text(path))
    except json.JSONDecodeError as error:
        raise HistoryError(f"invalid JSON manifest: {path}") from error
    require(isinstance(payload, dict), f"manifest is not an object: {path}")
    return payload


def parse_run_timezone(started_at: str) -> Tuple[datetime, timezone]:
    try:
        local_time = started_at[:-6]
        offset_text = started_at[-6:]
        require(
            len(started_at) > 6
            and offset_text[0] in "+-"
            and offset_text[3] == ":"
            and offset_text[1:3].isdigit()
            and offset_text[4:6].isdigit(),
            "run manifest started_at has no timezone offset",
        )
        parsed_local = datetime.strptime(
            local_time,
            "%Y-%m-%dT%H:%M:%S.%f" if "." in local_time else "%Y-%m-%dT%H:%M:%S",
        )
        offset_hours = int(offset_text[1:3])
        offset_remainder = int(offset_text[4:6])
        require(
            offset_hours <= 23 and offset_remainder <= 59,
            "run manifest started_at offset is out of range",
        )
        offset_minutes = offset_hours * 60 + offset_remainder
        if offset_text[0] == "-":
            offset_minutes = -offset_minutes
        run_timezone = timezone(timedelta(minutes=offset_minutes))
        parsed = parsed_local.replace(tzinfo=run_timezone)
    except ValueError as error:
        raise HistoryError("run manifest started_at is not ISO-8601") from error
    return parsed.astimezone(timezone.utc).replace(tzinfo=None), run_timezone


def parse_scenario_time(value: str, label: str, run_timezone: timezone) -> datetime:
    try:
        parsed = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
    except ValueError as error:
        raise HistoryError(f"{label} is not a supported scenario timestamp") from error
    return parsed.replace(tzinfo=run_timezone).astimezone(timezone.utc).replace(tzinfo=None)


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def sha256_json(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def find_hardware_value(run_manifest: Path, label: str) -> str:
    prefix = f"{label}:"
    for line in read_regular_text(run_manifest).splitlines():
        if line.startswith(prefix):
            value = line[len(prefix) :].strip()
            require(bool(value), f"run manifest has an empty {label}")
            return value
    raise HistoryError(f"run manifest is missing {label}")


def relative_evidence_path(
    artifact_base: Path, value: str, parser: str, suffix: str
) -> str:
    source = PurePosixPath(value)
    parts = source.parts
    try:
        results_index = parts.index("results")
    except ValueError as error:
        raise HistoryError(f"{parser} {suffix} path is outside retained results") from error
    relative = PurePosixPath("slot-a", *parts[results_index:])
    require(".." not in relative.parts, f"{parser} {suffix} path contains traversal")
    expected_prefix = PurePosixPath(
        "slot-a", "results", "fulltext-parser-regression", parser, "mo"
    )
    require(
        relative.parts[: len(expected_prefix.parts)] == expected_prefix.parts,
        f"{parser} {suffix} path is outside its retained parser directory",
    )
    local = artifact_base.joinpath(*relative.parts)
    try:
        local.resolve().relative_to(artifact_base.resolve())
    except ValueError as error:
        raise HistoryError(f"{parser} {suffix} path escapes the artifact") from error
    require(local.is_file() and not local.is_symlink(), f"retained {suffix} is missing: {relative}")
    return str(relative)


def rerun_verifier(
    result_dir: Path,
    matrixone_commit: str,
    mo_load_commit: str,
    mo_auto_test_commit: str,
    data_sha256: str,
) -> None:
    command = [
        sys.executable,
        str(VERIFIER),
        "--result-dir",
        str(result_dir),
        "--matrixone-commit",
        matrixone_commit,
        "--mo-load-commit",
        mo_load_commit,
        "--mo-auto-test-commit",
        mo_auto_test_commit,
        "--data-sha256",
        data_sha256,
        "--allow-relocated-query-packs",
    ]
    completed = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        universal_newlines=True,
        check=False,
    )
    require(
        completed.returncode == 0
        and completed.stdout.strip()
        == "PASS: formal FULLTEXT2 ngram/gojieba evidence is complete",
        "the retained artifact did not pass the current FULLTEXT2 verifier",
    )


def prepare_payload(args: argparse.Namespace) -> Dict[str, Any]:
    require(args.release_safe == "true", "FULLTEXT2 release_safe must be true")
    require(0 < args.action_id <= 18446744073709551615, "Actions run ID is out of range")
    if args.mode == "backfill":
        require(
            args.action_id == BACKFILL_ACTION_ID,
            f"backfill is restricted to Actions run {BACKFILL_ACTION_ID}",
        )
    require(0 < args.run_attempt <= 4294967295, "run attempt is out of range")
    expected_run_id = f"gh-{args.action_id}-{args.run_attempt}-fulltext"
    require(args.artifact_name == f"129-fulltext-{args.action_id}-{args.run_attempt}", "artifact name differs from the Actions run identity")
    require(
        args.run_url == f"https://github.com/matrixorigin/mo-auto-test/actions/runs/{args.action_id}",
        "run URL differs from the Actions run identity",
    )

    artifact_base, slot_root = normalize_artifact_root(args.artifact_root)
    result_dir = slot_root / "results" / "fulltext-parser-regression"
    run_manifest_path = slot_root / "meta" / "run-manifest.txt"
    run_manifest = parse_key_values(run_manifest_path)
    subject = parse_key_values(slot_root / "meta" / "fulltext-subject.txt")
    require(required_value(run_manifest, "run_id", "run manifest") == expected_run_id, "artifact run_id differs from the Actions run identity")
    require(required_value(run_manifest, "slot", "run manifest") == "a", "FULLTEXT2 history only accepts Slot A")
    require(required_value(run_manifest, "admission_mode", "run manifest") == "service-only", "FULLTEXT2 admission mode is not service-only")
    require(required_value(run_manifest, "profile_mode", "run manifest") == "disabled", "profiled FULLTEXT2 results cannot enter the formal series")

    manifests = {
        parser: parse_manifest(result_dir / parser / "mo" / "manifest.json")
        for parser in PARSERS
    }
    for parser, manifest in manifests.items():
        require(manifest.get("parser") == parser, f"{parser} manifest parser differs")
        require(manifest.get("schema_version") == 2, f"{parser} manifest schema version differs")
        require(manifest.get("index_type") == "fulltext2", f"{parser} manifest is not FULLTEXT2")
        require(manifest.get("position_free") is False, f"{parser} manifest is not positional")
        require(manifest.get("explain_marker") == "fulltext2_search", f"{parser} manifest plan marker differs")
        require(manifest.get("session_variables") == SESSION_VARIABLES, f"{parser} manifest session variables differ")
        profile = manifest.get("profile")
        require(isinstance(profile, dict) and profile.get("enabled") is False, f"{parser} manifest enables profiling")

    reference = manifests["ngram"]
    shared_fields = (
        "matrixone_commit",
        "mo_auto_test_commit",
        "mo_load_commit",
        "data_rows",
        "data_sha256",
        "database",
        "table",
    )
    for field in shared_fields:
        require(
            manifests["gojieba"].get(field) == reference.get(field),
            f"parser manifests disagree on {field}",
        )

    matrixone_commit = require_commit(str(reference.get("matrixone_commit", "")), "MatrixOne commit")
    mo_auto_test_commit = require_commit(str(reference.get("mo_auto_test_commit", "")), "mo-auto-test commit")
    mo_load_commit = require_commit(str(reference.get("mo_load_commit", "")), "mo-load commit")
    data_sha256 = require_hash(str(reference.get("data_sha256", "")), "data hash")
    data_rows = parse_positive_int(str(reference.get("data_rows", "")), "data rows")
    require(required_value(run_manifest, "mo_commit", "run manifest") == matrixone_commit, "run manifest MatrixOne commit differs")
    require(required_value(run_manifest, "regression_commit", "run manifest") == mo_auto_test_commit, "run manifest mo-auto-test commit differs")
    require(required_value(subject, "mo_load_commit", "FULLTEXT subject") == mo_load_commit, "FULLTEXT subject mo-load commit differs")
    require(required_value(subject, "corpus_sha256", "FULLTEXT subject") == data_sha256, "FULLTEXT subject corpus hash differs")

    rerun_verifier(result_dir, matrixone_commit, mo_load_commit, mo_auto_test_commit, data_sha256)
    require(
        read_regular_text(result_dir / "verification.txt").strip()
        == "PASS: formal FULLTEXT2 ngram/gojieba evidence is complete",
        "retained verification status is not PASS",
    )

    started_at_utc, run_timezone = parse_run_timezone(required_value(run_manifest, "started_at", "run manifest"))
    summary_columns = (
        "run_id", "engine", "parser", "scenario", "query_mode", "top_k",
        "concurrency", "query_count", "query_sha256", "start", "end",
        "wall_seconds", "success", "errors", "actual_qps", "p50_ms",
        "p75_ms", "p90_ms", "p99_ms", "cpu_samples", "memory_samples",
        "avg_cpu_pct", "max_cpu_pct", "avg_rss_gib", "max_rss_gib",
        "client_exit_status", "result", "client_log", "resource_log",
        "index_type", "position_free", "profiled", "profile_status",
    )
    summary_rows = read_tsv(result_dir / "summary.tsv", summary_columns)
    require(len(summary_rows) == 10, "summary must contain exactly ten scenarios")
    expected_matrix = {(parser, scenario) for parser in PARSERS for scenario in SCENARIOS}
    actual_matrix = {(row["parser"], row["scenario"]) for row in summary_rows}
    require(actual_matrix == expected_matrix, "summary parser/scenario matrix differs")

    scenarios: List[Dict[str, Any]] = []
    for row in summary_rows:
        parser = row["parser"]
        scenario = row["scenario"]
        label = f"{parser}/{scenario}"
        require(row["engine"] == "mo", f"{label} engine differs")
        require(row["query_mode"] == QUERY_MODES[scenario], f"{label} query mode differs")
        require(row["index_type"] == "fulltext2" and row["position_free"] == "false", f"{label} index contract differs")
        require(row["profiled"] == "false" and row["profile_status"] == "DISABLED", f"{label} profile contract differs")
        concurrency = parse_positive_int(row["concurrency"], f"{label} concurrency")
        top_k = parse_positive_int(row["top_k"], f"{label} top-k")
        require(concurrency == 10 and top_k == 100, f"{label} dimensions differ from the formal contract")
        query_count = parse_positive_int(row["query_count"], f"{label} query count")
        query_sha256 = require_hash(row["query_sha256"], f"{label} query hash")
        manifest_pack = manifests[parser].get("query_packs", {}).get(scenario, {})
        require(manifest_pack.get("query_count") == query_count, f"{label} query count differs from manifest")
        require(manifest_pack.get("sha256") == query_sha256, f"{label} query hash differs from manifest")
        error_count = parse_positive_int(row["errors"], f"{label} errors", allow_zero=True)
        client_exit = int(row["client_exit_status"])
        require(error_count == 0 and client_exit == 0, f"{label} has an error or failed client")
        require(row["result"].upper() in {"PASS", "SUCCESS", "SUCCEED"}, f"{label} result is not successful")
        plan_path = result_dir / parser / "mo" / f"mo_preflight_{scenario}_plan.txt"
        require("fulltext2_search" in read_regular_text(plan_path), f"{label} plan marker is missing")
        scenario_start = parse_scenario_time(row["start"], f"{label} start", run_timezone)
        scenario_end = parse_scenario_time(row["end"], f"{label} end", run_timezone)
        require(scenario_end >= scenario_start, f"{label} ends before it starts")
        p50 = parse_decimal(row["p50_ms"], f"{label} P50")
        p75 = parse_decimal(row["p75_ms"], f"{label} P75")
        p90 = parse_decimal(row["p90_ms"], f"{label} P90")
        p99 = parse_decimal(row["p99_ms"], f"{label} P99")
        require(p50 <= p75 <= p90 <= p99, f"{label} latency percentiles are not monotonic")
        avg_cpu = parse_decimal(row["avg_cpu_pct"], f"{label} average CPU")
        max_cpu = parse_decimal(row["max_cpu_pct"], f"{label} maximum CPU")
        avg_rss = parse_decimal(row["avg_rss_gib"], f"{label} average RSS")
        max_rss = parse_decimal(row["max_rss_gib"], f"{label} maximum RSS")
        require(avg_cpu <= max_cpu, f"{label} average CPU exceeds its maximum")
        require(avg_rss <= max_rss, f"{label} average RSS exceeds its maximum")
        scenarios.append(
            {
                "action_id": args.action_id,
                "run_attempt": args.run_attempt,
                "parser": parser,
                "scenario": scenario,
                "concurrency": concurrency,
                "top_k": top_k,
                "scenario_run_id": row["run_id"],
                "query_mode": row["query_mode"],
                "query_count": query_count,
                "query_sha256": query_sha256,
                "started_at_utc": scenario_start,
                "completed_at_utc": scenario_end,
                "wall_seconds": parse_decimal(row["wall_seconds"], f"{label} wall time", allow_zero=False),
                "success_count": parse_positive_int(row["success"], f"{label} success"),
                "error_count": error_count,
                "actual_qps": parse_decimal(row["actual_qps"], f"{label} QPS", allow_zero=False),
                "p50_ms": p50,
                "p75_ms": p75,
                "p90_ms": p90,
                "p99_ms": p99,
                "cpu_samples": parse_positive_int(row["cpu_samples"], f"{label} CPU samples"),
                "memory_samples": parse_positive_int(row["memory_samples"], f"{label} memory samples"),
                "avg_cpu_pct": avg_cpu,
                "max_cpu_pct": max_cpu,
                "avg_rss_gib": avg_rss,
                "max_rss_gib": max_rss,
                "client_exit_status": client_exit,
                "result_status": row["result"].upper(),
                "plan_marker": "fulltext2_search",
                "plan_verified": 1,
                "client_log_path": relative_evidence_path(artifact_base, row["client_log"], parser, "client log"),
                "resource_log_path": relative_evidence_path(artifact_base, row["resource_log"], parser, "resource log"),
            }
        )
    scenarios.sort(key=lambda item: (item["parser"], item["scenario"]))

    index_columns = (
        "engine", "parser", "index", "rows", "duration_seconds", "status",
        "index_type", "position_free", "ddl_duration_seconds",
        "ready_wait_seconds", "ready_probe_count",
    )
    index_rows = read_tsv(result_dir / "index_build.tsv", index_columns)
    require(len(index_rows) == 2 and {row["parser"] for row in index_rows} == set(PARSERS), "index timing must contain exactly two parsers")
    builds: List[Dict[str, Any]] = []
    for row in index_rows:
        parser = row["parser"]
        require(row["engine"] == "mo" and row["index_type"] == "fulltext2", f"{parser} index engine differs")
        require(row["position_free"] == "false", f"{parser} index is not positional")
        require(row["status"] == "READY", f"{parser} index is not READY")
        require(row["index"] == manifests[parser].get("index_name"), f"{parser} index name differs")
        require(parse_positive_int(row["rows"], f"{parser} index rows") == data_rows, f"{parser} index row count differs")
        builds.append(
            {
                "action_id": args.action_id,
                "run_attempt": args.run_attempt,
                "parser": parser,
                "index_name": row["index"],
                "data_rows": data_rows,
                "build_duration_seconds": parse_decimal(row["duration_seconds"], f"{parser} build time", allow_zero=False),
                "ddl_duration_seconds": parse_decimal(row["ddl_duration_seconds"], f"{parser} DDL time", allow_zero=False),
                "ready_wait_seconds": parse_decimal(row["ready_wait_seconds"], f"{parser} ready wait"),
                "ready_probe_count": parse_positive_int(row["ready_probe_count"], f"{parser} ready probes"),
                "ready_status": "READY",
                "lifecycle_after_queries": "ABSENT" if parser == "ngram" else "PRESENT",
            }
        )
    builds.sort(key=lambda item: item["parser"])

    query_contract = {
        parser: {
            scenario: {
                "count": manifests[parser]["query_packs"][scenario]["query_count"],
                "sha256": manifests[parser]["query_packs"][scenario]["sha256"],
            }
            for scenario in SCENARIOS
        }
        for parser in PARSERS
    }
    contract = {
        "measurement_contract_version": MEASUREMENT_CONTRACT_VERSION,
        "host": "mo-129",
        "hardware": {
            "architecture": find_hardware_value(run_manifest_path, "Architecture"),
            "cpu_count": parse_positive_int(find_hardware_value(run_manifest_path, "CPU(s)"), "CPU count"),
            "model_name": find_hardware_value(run_manifest_path, "Model name"),
        },
        "slot": {
            "name": "a",
            "cpuset_cpus": required_value(run_manifest, "cpuset_cpus", "run manifest"),
            "cpuset_mems": required_value(run_manifest, "cpuset_mems", "run manifest"),
            "mo_memory": required_value(run_manifest, "mo_memory", "run manifest"),
            "mo_gomemlimit": required_value(run_manifest, "mo_gomemlimit", "run manifest"),
        },
        "dataset": {"rows": data_rows, "sha256": data_sha256},
        "source_queries_sha256": require_hash(required_value(subject, "queries_sha256", "FULLTEXT subject"), "source query hash"),
        "parsers": list(PARSERS),
        "scenarios": list(SCENARIOS),
        "dimensions": {"concurrency": 10, "top_k": 100},
        "query_packs": query_contract,
        "session_variables": SESSION_VARIABLES,
        "index_type": "fulltext2",
        "position_free": False,
        "profile_mode": "disabled",
        "plan_marker": "fulltext2_search",
    }
    contract_hash = sha256_json(contract)
    completed_at_utc = max(item["completed_at_utc"] for item in scenarios)
    run = {
        "action_id": args.action_id,
        "run_attempt": args.run_attempt,
        "fulltext_run_id": expected_run_id,
        "started_at_utc": started_at_utc,
        "completed_at_utc": completed_at_utc,
        "performance_series": f"fulltext2-129-positional-v1-{contract_hash}",
        "contract_hash": contract_hash,
        "measurement_contract_version": MEASUREMENT_CONTRACT_VERSION,
        "performance_contract_json": canonical_json(contract),
        "matrixone_commit": matrixone_commit,
        "mo_auto_test_commit": mo_auto_test_commit,
        "mo_load_commit": mo_load_commit,
        "mo_binary_sha256": require_hash(required_value(run_manifest, "mo_binary_sha256", "run manifest"), "MatrixOne binary hash"),
        "mo_load_jar_sha256": require_hash(required_value(subject, "mo_load_jar_sha256", "FULLTEXT subject"), "mo-load jar hash"),
        "jieba_dict_manifest_sha256": require_hash(required_value(run_manifest, "jieba_dict_manifest_sha256", "run manifest"), "jieba dictionary hash"),
        "data_sha256": data_sha256,
        "queries_sha256": contract["source_queries_sha256"],
        "data_rows": data_rows,
        "profile_mode": "disabled",
        "slot_name": "a",
        "cpuset_cpus": contract["slot"]["cpuset_cpus"],
        "cpuset_mems": contract["slot"]["cpuset_mems"],
        "mo_memory": contract["slot"]["mo_memory"],
        "mo_gomemlimit": contract["slot"]["mo_gomemlimit"],
        "verification_status": "PASS",
        "release_safe": 1,
        "artifact_name": args.artifact_name,
        "run_url": args.run_url,
    }
    canonical_payload = {
        "run": {key: serialize_for_hash(value) for key, value in run.items()},
        "index_builds": [serialize_mapping_for_hash(item) for item in builds],
        "scenario_metrics": [serialize_mapping_for_hash(item) for item in scenarios],
    }
    run["canonical_payload_hash"] = sha256_json(canonical_payload)
    return {"run": run, "index_builds": builds, "scenario_metrics": scenarios}


def serialize_for_hash(value: Any) -> Any:
    if isinstance(value, Decimal):
        return format(value, "f")
    if isinstance(value, datetime):
        return value.isoformat(timespec="microseconds") + "Z"
    require(not isinstance(value, float) or math.isfinite(value), "payload contains a non-finite float")
    return value


def serialize_mapping_for_hash(values: Mapping[str, Any]) -> Dict[str, Any]:
    return {key: serialize_for_hash(value) for key, value in values.items()}


RUN_COLUMNS = (
    "action_id", "run_attempt", "fulltext_run_id", "started_at_utc",
    "completed_at_utc", "performance_series", "contract_hash",
    "measurement_contract_version", "performance_contract_json",
    "matrixone_commit", "mo_auto_test_commit", "mo_load_commit",
    "mo_binary_sha256", "mo_load_jar_sha256", "jieba_dict_manifest_sha256",
    "data_sha256", "queries_sha256", "data_rows", "profile_mode", "slot_name",
    "cpuset_cpus", "cpuset_mems", "mo_memory", "mo_gomemlimit",
    "verification_status", "release_safe", "artifact_name", "run_url",
    "canonical_payload_hash",
)
INDEX_COLUMNS = (
    "action_id", "run_attempt", "parser", "index_name", "data_rows",
    "build_duration_seconds", "ddl_duration_seconds", "ready_wait_seconds",
    "ready_probe_count", "ready_status", "lifecycle_after_queries",
)
SCENARIO_COLUMNS = (
    "action_id", "run_attempt", "parser", "scenario", "concurrency", "top_k",
    "scenario_run_id", "query_mode", "query_count", "query_sha256",
    "started_at_utc", "completed_at_utc", "wall_seconds", "success_count",
    "error_count", "actual_qps", "p50_ms", "p75_ms", "p90_ms", "p99_ms",
    "cpu_samples", "memory_samples", "avg_cpu_pct", "max_cpu_pct",
    "avg_rss_gib", "max_rss_gib", "client_exit_status", "result_status",
    "plan_marker", "plan_verified", "client_log_path", "resource_log_path",
)


def load_database_config(path: Path) -> Dict[str, Any]:
    payload = yaml.safe_load(read_regular_text(path))
    require(isinstance(payload, dict), "database config is not a mapping")
    database = payload.get("DBInfo")
    require(isinstance(database, dict), "DBInfo in database config is not a mapping")
    for key in ("host", "port", "user", "password", "database"):
        require(key in database and str(database[key]) != "", f"DBInfo is missing {key}")
    require(database["database"] == TARGET_DATABASE, f"publisher refuses database {database['database']!r}")
    return database


def connect_database(config: Mapping[str, Any]) -> Any:
    return pymysql.connect(
        host=config["host"],
        port=int(config["port"]),
        user=config["user"],
        password=config["password"],
        database=config["database"],
        charset="utf8mb4",
        autocommit=False,
        connect_timeout=10,
        read_timeout=30,
        write_timeout=30,
    )


def insert_mapping(cursor: Any, table: str, columns: Sequence[str], values: Mapping[str, Any]) -> None:
    placeholders = ",".join(["%s"] * len(columns))
    cursor.execute(
        f"INSERT INTO {table} ({','.join(columns)}) VALUES ({placeholders})",
        [values[column] for column in columns],
    )


def verify_persisted(cursor: Any, payload: Mapping[str, Any]) -> None:
    run = payload["run"]
    cursor.execute(
        "SELECT canonical_payload_hash FROM FulltextRun WHERE action_id=%s AND run_attempt=%s",
        (run["action_id"], run["run_attempt"]),
    )
    row = cursor.fetchone()
    require(row is not None and row[0] == run["canonical_payload_hash"], "persisted FULLTEXT2 payload hash differs")
    for table, expected in (("FulltextIndexBuild", 2), ("FulltextScenarioMetric", 10)):
        cursor.execute(
            f"SELECT COUNT(*) FROM {table} WHERE action_id=%s AND run_attempt=%s",
            (run["action_id"], run["run_attempt"]),
        )
        count = cursor.fetchone()
        require(count is not None and int(count[0]) == expected, f"persisted {table} row count differs")


def publish_once(connection: Any, payload: Mapping[str, Any]) -> str:
    run = payload["run"]
    try:
        connection.begin()
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT canonical_payload_hash FROM FulltextRun WHERE action_id=%s AND run_attempt=%s FOR UPDATE",
                (run["action_id"], run["run_attempt"]),
            )
            existing = cursor.fetchone()
            if existing is not None:
                require(existing[0] == run["canonical_payload_hash"], "existing FULLTEXT2 run has a conflicting payload hash")
                verify_persisted(cursor, payload)
                connection.commit()
                return "NOOP"
            insert_mapping(cursor, "FulltextRun", RUN_COLUMNS, run)
            for build in payload["index_builds"]:
                insert_mapping(cursor, "FulltextIndexBuild", INDEX_COLUMNS, build)
            for scenario in payload["scenario_metrics"]:
                insert_mapping(cursor, "FulltextScenarioMetric", SCENARIO_COLUMNS, scenario)
            verify_persisted(cursor, payload)
        connection.commit()
        with connection.cursor() as cursor:
            verify_persisted(cursor, payload)
        return "PASS"
    except BaseException:
        try:
            connection.rollback()
        except BaseException:
            pass
        raise


def is_transient_mysql_error(error: BaseException) -> bool:
    if isinstance(error, (ConnectionResetError, TimeoutError)):
        return True
    if isinstance(error, (pymysql.err.OperationalError, pymysql.err.IntegrityError)) and error.args:
        return error.args[0] in TRANSIENT_MYSQL_CODES
    return False


def publish_with_retry(
    config: Mapping[str, Any],
    payload: Mapping[str, Any],
    connector: Callable[[Mapping[str, Any]], Any] = connect_database,
    sleeper: Callable[[float], None] = time.sleep,
) -> str:
    last_error: Optional[BaseException] = None
    for attempt in range(1, 4):
        connection = None
        try:
            connection = connector(config)
            return publish_once(connection, payload)
        except BaseException as error:
            last_error = error
            if not is_transient_mysql_error(error) or attempt == 3:
                raise
            sleeper(float(2 ** (attempt - 1)))
        finally:
            if connection is not None:
                try:
                    connection.close()
                except BaseException:
                    pass
    assert last_error is not None
    raise last_error


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    parser.add_argument("--artifact-root", required=True, type=Path)
    parser.add_argument("--artifact-name", required=True)
    parser.add_argument("--action-id", required=True, type=int)
    parser.add_argument("--run-attempt", required=True, type=int)
    parser.add_argument("--run-url", required=True)
    parser.add_argument("--release-safe", required=True, choices=("true", "false"))
    parser.add_argument("--mode", choices=("nightly", "backfill"), default="nightly")
    parser.add_argument("--config", type=Path)
    parser.add_argument("--dry-run", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    payload: Optional[Dict[str, Any]] = None
    try:
        payload = prepare_payload(args)
        run = payload["run"]
        if args.dry_run:
            result = "DRY_RUN_PASS"
        else:
            require(args.config is not None, "database config is required outside dry-run")
            result = publish_with_retry(load_database_config(args.config), payload)
        print(
            f"FULLTEXT2_HISTORY={result} run={args.action_id}/{args.run_attempt} "
            f"series={run['performance_series']} rows=1/2/10 "
            f"payload_hash={run['canonical_payload_hash']}"
        )
        return 0
    except (HistoryError, ValueError, KeyError, TypeError, pymysql.MySQLError, OSError):
        series = payload["run"]["performance_series"] if payload is not None else "unavailable"
        print(
            f"FULLTEXT2_HISTORY=FAIL run={args.action_id}/{args.run_attempt} "
            f"series={series} rows=0/0/0",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
