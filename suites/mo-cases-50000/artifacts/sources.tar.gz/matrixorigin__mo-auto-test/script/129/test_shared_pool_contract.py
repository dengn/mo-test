#!/usr/bin/env python3

from pathlib import Path

import yaml
from plan_shared_workflow import TOKENS


root = Path(__file__).resolve().parents[2]
workflow_root = root / ".github" / "workflows"


def load(name: str) -> dict[str, object]:
    with (workflow_root / name).open(encoding="utf-8") as stream:
        value = yaml.load(stream, Loader=yaml.BaseLoader)
    assert isinstance(value, dict)
    return value


shared = load("mo-binary-search-on-129-new.yaml")
inputs = shared["on"]["workflow_dispatch"]["inputs"]
assert len(inputs) <= 10
assert inputs["Test_list"]["type"] == "string"
assert inputs["Test_list"]["description"] == (
    f"Comma-separated workloads: {','.join(TOKENS)}"
)
assert "Repo" not in inputs
for case_input in (
    "SSB_TEST_LIST",
    "TPCH_TEST_LIST",
    "TPCC_TEST_LIST",
    "SYSBENCH_TEST_LIST",
    "DDL_TEST_LIST",
    "LOADDATA_TEST_LIST",
):
    assert case_input in inputs
assert inputs["TPCH_TURNS"]["type"] == "string"
assert inputs["TPCH_TURNS"]["default"] == ""
assert inputs["After_Run"]["options"] == [
    "cleanup",
    "keep-1h",
    "keep-2h",
    "keep-4h",
    "keep-8h",
]
execute = shared["jobs"]["execute"]
assert execute["runs-on"] == ["self-hosted", "Linux", "X64", "mo-srv-129-shared"]
assert execute["env"]["BM129_REQUESTED_SLOT"] == "${{ matrix.slot_policy }}"
assert execute["strategy"]["matrix"]["include"] == (
    "${{ fromJSON(needs.preflight.outputs.execution_plan) }}"
)
steps = execute["steps"]
step_names = [step.get("name") for step in steps if isinstance(step, dict)]
resolve = next(step for step in shared["jobs"]["preflight"]["steps"] if step.get("id") == "resolve")
assert "resolve_exact_git_ref.sh" in resolve["run"]
plan = next(step for step in shared["jobs"]["preflight"]["steps"] if step.get("id") == "plan")
assert "plan_shared_workflow.py" in plan["run"]
assert plan["env"]["TPCC_TEST_LIST"] == "${{ inputs.TPCC_TEST_LIST }}"
assert plan["env"]["TPCH_TURNS"] == "${{ inputs.TPCH_TURNS }}"
assert "TPCH_TURNS must be blank" in plan["run"]
assert plan["env"]["AFTER_RUN"] == "${{ inputs.After_Run }}"
assert execute["env"]["BM129_TPCH_TURNS"] == "${{ matrix.tpch_turns }}"
assert step_names.index("Arm independent exact-owner shared watchdog") < step_names.index(
    "Acquire any free half-host Slot"
)
for tool_step in (
    "Checkout immutable TPCC client",
    "Checkout immutable TPCH client",
    "Checkout immutable BVT runner",
    "Checkout immutable SSB client",
    "Checkout immutable Sysbench client",
    "Checkout immutable Vector client",
    "Checkout immutable Concurrent client",
    "Checkout immutable MO CDC tool",
    "Checkout immutable full-text client",
    "Record token-specific tools",
):
    assert step_names.index(tool_step) < step_names.index(
        "Arm independent exact-owner shared watchdog"
    )
assert step_names.index("Exact shared cleanup and Slot release") < step_names.index(
    "Stop shared watchdog after exact Lease absence"
)
assert step_names.index("Stop shared watchdog after exact Lease absence") < step_names.index(
    "Upload bounded shared evidence"
)
assert step_names.index("Upload bounded shared evidence") < step_names.index(
    "Enforce terminal safety"
)
cleanup = next(step for step in steps if step.get("id") == "cleanup")
assert "always()" in cleanup["if"]
assert "cleanup_shared_slot.sh" in cleanup["run"]
acquire = next(step for step in steps if step.get("name") == "Acquire any free half-host Slot")
assert "wait_and_acquire_shared_slot.sh" in acquire["run"]
recheck = next(
    step for step in steps if step.get("name") == "Recheck the local admission window before using 129"
)
assert '"$BM129_TPCH_TURNS"' in recheck["run"]
build = next(
    step
    for step in steps
    if step.get("name") == "Build MatrixOne inside the assigned CPU and NUMA budget"
)
assert "run_shared_build.sh" in build["run"]
assert "make -C" not in build["run"]
arm = next(
    step for step in steps if step.get("name") == "Arm independent exact-owner shared watchdog"
)
assert "start_shared_watchdog.sh" in arm["run"]
assert "TOOL_REPO_TOKEN" in arm["env"]["BM129_WATCHDOG_GITHUB_TOKEN"]
assert "steps.shared_case.outcome == 'success'" in next(
    step for step in steps if step.get("name") == "Keep healthy MO for bounded SQL debugging"
)["if"]
stop_watchdog = next(
    step for step in steps if step.get("name") == "Stop shared watchdog after exact Lease absence"
)
assert "always()" in stop_watchdog["if"]
assert "stop_shared_watchdog.sh" in stop_watchdog["run"]

script_root = root / "script" / "129"
start_source = (script_root / "start_shared_watchdog.sh").read_text(encoding="utf-8")
watch_source = (script_root / "watch_shared.sh").read_text(encoding="utf-8")
stop_source = (script_root / "stop_shared_watchdog.sh").read_text(encoding="utf-8")
build_worker_source = (script_root / "run_shared_build_worker.sh").read_text(
    encoding="utf-8"
)
assert start_source.index("systemd-run") < start_source.index('sudo test -f "$armed_file"')
assert watch_source.index('mv -- "$armed_tmp" "$armed_file"') < watch_source.index(
    "while true; do"
)
assert "/attempts/$github_run_attempt" in watch_source
assert '"$GITHUB_RUN_ATTEMPT"' in start_source
assert '${BM129_FAMILY_ID}' in start_source
assert '${BM129_FAMILY_ID}' in stop_source
assert stop_source.index("shared-assert-absent") < stop_source.index("systemctl stop")
assert build_worker_source.index(" assert ") < build_worker_source.index(
    'build make -C "$BM129_MO_SOURCE" build'
)

legacy = load("mo-binary-search-on-129-once.yaml")
assert set(legacy["jobs"]) == {"disabled"}
assert legacy["jobs"]["disabled"]["runs-on"] == "ubuntu-latest"

consumer_files = set()
for path in workflow_root.iterdir():
    if not path.is_file() or path.suffix not in {".yml", ".yaml"}:
        continue
    text = path.read_text(encoding="utf-8")
    if "mo-srv-129" in text:
        consumer_files.add(path.name)
    if path.name != "reuse_regression_test_128.yaml" and "mo-srv-129" in text:
        assert "reuse_regression_test_128.yaml" not in text, path
assert consumer_files == {
    "branch-nightly-regression-new.yml",
    "mo-binary-search-on-129-new.yaml",
}

contract = (workflow_root / "129-family-contract.yml").read_text(encoding="utf-8")
for name in (
    "mo-binary-search-on-129-new.yaml",
    "mo-binary-search-on-129-once.yaml",
):
    assert contract.count(name) >= 2

print("PASS: the shared workflow has capacity two, bounded multi-case input, and no legacy bypass.")
