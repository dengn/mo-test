#!/usr/bin/env python3

from __future__ import annotations

import argparse
import contextlib
import importlib.util
import io
import stat
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import yaml


MODULE_PATH = Path(__file__).with_name("performance_result_gate.py")
REPOSITORY_ROOT = MODULE_PATH.parents[2]
PROCESSOR_PATH = REPOSITORY_ROOT / "result" / "Processor.py"
SPEC = importlib.util.spec_from_file_location("performance_result_gate", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
GATE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = GATE
SPEC.loader.exec_module(GATE)


class FakeCursor:
    def __init__(
        self,
        current: int | None,
        history: tuple[tuple[int, int], ...],
        update_rowcount: int = 1,
    ) -> None:
        self.current = current
        self.history = history
        self.rows: list[tuple[object, ...]] = []
        self.current_sql = ""
        self.history_sql = ""
        self.updates: list[tuple[str, list[object]]] = []
        self.update_rowcount = update_rowcount
        self.rowcount = 0

    def __enter__(self) -> "FakeCursor":
        return self

    def __exit__(self, *_args: object) -> None:
        return None

    def execute(self, sql: str, params: list[object]) -> None:
        if sql.startswith("update "):
            self.updates.append((sql, params))
            self.rows = []
            self.rowcount = self.update_rowcount
            return
        if "action_id = %s" in sql:
            self.current_sql = sql
            self.rows = (
                [(self.current, "2026-08-13 01:00:00")]
                if self.current is not None
                else []
            )
        else:
            self.history_sql = sql
            self.rows = [
                (action_id, value, f"2026-08-{12-index:02d} 01:00:00")
                for index, (action_id, value) in enumerate(self.history)
            ]

    def fetchone(self) -> tuple[object, ...] | None:
        return self.rows[0] if self.rows else None

    def fetchall(self) -> list[tuple[object, ...]]:
        return self.rows


class FakeConnection:
    def __init__(
        self,
        current: int | None,
        history: tuple[tuple[int, int], ...],
        update_rowcount: int = 1,
    ) -> None:
        self.fake_cursor = FakeCursor(current, history, update_rowcount)
        self.committed = False

    def cursor(self) -> FakeCursor:
        return self.fake_cursor

    def close(self) -> None:
        return None

    def commit(self) -> None:
        self.committed = True


class PerformanceResultGateTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary_directory.name)
        self.config = self.root / "config.yml"
        self.config.write_text(
            yaml.safe_dump(
                {
                    "DBInfo": {
                        "host": "performance-db",
                        "port": 3306,
                        "user": "collector",
                        "password": "secret",
                        "database": "results",
                    },
                    "FilePath": {"TPCC": "/old/report"},
                }
            ),
            encoding="utf-8",
        )

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def test_configure_preserves_db_and_secures_runtime_config(self) -> None:
        new_report = self.root / "input" / "tpcc" / "report"
        args = argparse.Namespace(
            config=str(self.config),
            isolation_root=str(self.root / "unselected"),
            path=[f"TPCC={new_report}"],
        )
        self.assertEqual(GATE.configure(args), 0)
        configured = yaml.safe_load(self.config.read_text(encoding="utf-8"))
        self.assertEqual(configured["DBInfo"]["host"], "performance-db")
        self.assertEqual(configured["FilePath"]["TPCC"], str(new_report.resolve()))
        self.assertEqual(
            set(configured["FilePath"]), set(GATE.LEGACY_FILE_PATH_KEYS)
        )
        self.assertEqual(
            configured["FilePath"]["FULLTEXT"],
            str((self.root / "unselected" / "fulltext").resolve()),
        )
        self.assertEqual(stat.S_IMODE(self.config.stat().st_mode), 0o600)

    def test_configured_contract_imports_the_unmodified_legacy_processor(self) -> None:
        args = argparse.Namespace(
            config=str(self.config),
            isolation_root=str(self.root / "unselected"),
            path=[f"SSB={self.root / 'ssb-report'}"],
        )
        self.assertEqual(GATE.configure(args), 0)
        result = subprocess.run(
            [
                sys.executable,
                str(PROCESSOR_PATH),
                "12345",
                "abcdef123456-a1",
                "NOOP",
                "main",
            ],
            cwd=self.root,
            text=True,
            capture_output=True,
            check=False,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def run_gate(
        self,
        current: int | None,
        history: tuple[tuple[int, int], ...],
        *,
        mode: str = "enforce",
        update_rowcount: int = 1,
    ) -> int:
        output = self.root / "result.tsv"
        args = argparse.Namespace(
            config=str(self.config),
            family="tpcc",
            action_id="12345",
            commit_id="abcdef123456-a2",
            branch="main",
            output=str(output),
            mode=mode,
        )
        captured = io.StringIO()
        connection = FakeConnection(current, history, update_rowcount)
        with (
            mock.patch.object(
                GATE.pymysql,
                "connect",
                return_value=connection,
            ),
            contextlib.redirect_stdout(captured),
        ):
            result = GATE.check(args)
        self.assertTrue(output.is_file())
        self.assertEqual(stat.S_IMODE(output.stat().st_mode), 0o644)
        self.last_output = output.read_text(encoding="utf-8")
        self.last_log = captured.getvalue()
        self.last_connection = connection
        self.assertNotIn("Decimal(", self.last_log)
        self.assertTrue(connection.committed)
        return result

    def test_current_rows_within_threshold_pass(self) -> None:
        # Duplicate rows from one old action count as one baseline run.
        self.assertEqual(
            self.run_gate(
                80,
                (
                    (1005, 100),
                    (1005, 1),
                    (1004, 90),
                    (1003, 80),
                    (1002, 70),
                    (1001, 60),
                    (999, 1),
                ),
            ),
            0,
        )
        self.assertIn("\t80\t5\t[100, 90, 80, 70, 60]\t25%\tPASS\n", self.last_output)
        self.assertIn("baseline_median=80", self.last_log)
        self.assertIn(
            "order by sessionStart desc limit 100",
            self.last_connection.fake_cursor.history_sql,
        )

    def test_regression_against_five_run_median_fails_and_is_quarantined(self) -> None:
        self.assertEqual(
            self.run_gate(
                60,
                ((1005, 110), (1004, 105), (1003, 100), (1002, 95), (1001, 20)),
            ),
            1,
        )
        self.assertIn("\t100\t5\t[110, 105, 100, 95, 20]\t25%\tFAIL\n", self.last_output)
        self.assertTrue(self.last_connection.fake_cursor.updates)
        self.assertEqual(
            self.last_connection.fake_cursor.updates[0][1][0], "PERF_FAIL"
        )

    def test_provisional_regression_requests_retry_without_failing_lane(self) -> None:
        self.assertEqual(
            self.run_gate(
                60,
                ((1005, 110), (1004, 105), (1003, 100), (1002, 95), (1001, 20)),
                mode="provisional",
            ),
            0,
        )
        self.assertIn("\tRETRY_REQUIRED\n", self.last_output)
        self.assertEqual(
            self.last_connection.fake_cursor.updates[0][1][0], "PERF_RETRY"
        )

    def test_quarantine_must_update_exactly_one_row(self) -> None:
        with self.assertRaisesRegex(RuntimeError, "updated 0"):
            self.run_gate(
                60,
                ((1005, 110), (1004, 105), (1003, 100), (1002, 95), (1001, 90)),
                mode="provisional",
                update_rowcount=0,
            )

    def test_new_topology_series_bootstraps_without_history(self) -> None:
        self.assertEqual(self.run_gate(70, ()), 0)
        self.assertIn("\tWARMUP\n", self.last_output)

    def test_confirmation_warmup_is_inconclusive_but_non_blocking(self) -> None:
        self.assertEqual(self.run_gate(70, (), mode="confirmation"), 0)
        self.assertIn("\tWARMUP\n", self.last_output)
        self.assertIn("INCONCLUSIVE:", self.last_log)
        self.assertFalse(self.last_connection.fake_cursor.updates)

    def test_fewer_than_five_history_samples_are_warmup(self) -> None:
        self.assertEqual(
            self.run_gate(
                1,
                ((1004, 100), (1003, 99), (1002, 98), (1001, 97)),
            ),
            0,
        )
        self.assertIn("\t-\t4\t[100, 99, 98, 97]\t25%\tWARMUP\n", self.last_output)
        self.assertIn("history_samples=4/5", self.last_log)

    def test_bimodal_history_is_not_reported_as_a_product_regression(self) -> None:
        self.assertEqual(
            self.run_gate(
                1,
                ((1005, 100), (1004, 100), (1003, 70), (1002, 70), (1001, 70)),
            ),
            0,
        )
        self.assertIn(
            "\t70\t5\t[100, 100, 70, 70, 70]\t25%\tUNSTABLE_BASELINE\n",
            self.last_output,
        )
        self.assertIn("relative_iqr=", self.last_log)
        self.assertFalse(self.last_connection.fake_cursor.updates)

    def test_confirmation_with_unstable_history_fails_as_inconclusive(self) -> None:
        self.assertEqual(
            self.run_gate(
                1,
                ((1005, 100), (1004, 100), (1003, 70), (1002, 70), (1001, 70)),
                mode="confirmation",
            ),
            1,
        )
        self.assertIn("\tUNSTABLE_BASELINE\n", self.last_output)
        self.assertIn("INCONCLUSIVE:", self.last_log)
        self.assertFalse(self.last_connection.fake_cursor.updates)

    def test_stale_same_action_without_current_attempt_commit_fails(self) -> None:
        self.assertEqual(self.run_gate(None, ((1001, 100), (999, 90))), 1)

    def test_ssb_uses_the_real_clone_series_names(self) -> None:
        predicates = [metric.predicates for metric in GATE.ssb_metrics()]
        self.assertEqual(
            predicates,
            [
                (("caseN", "SSB_CLONE_1"),),
                (("caseN", "SSB_CLONE_10"),),
                (("caseN", "SSB_CLONE_100"),),
            ],
        )


if __name__ == "__main__":
    unittest.main()
