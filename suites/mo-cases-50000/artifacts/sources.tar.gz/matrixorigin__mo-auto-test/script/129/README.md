# 129 Main Family Nightly

This directory implements the resource-isolated nightly campaign for host 129.
The public entry point is
`.github/workflows/branch-nightly-regression-new.yml`.

## Execution topology

The workflow resolves one exact MatrixOne commit from GitHub, builds MatrixOne,
`mo_br`, and `mo_cdc` once (and builds `mo-tool` for the weekly profile), freezes
the binaries as one immutable artifact, and then starts two independent lane Jobs:

| Lane | NUMA / logical CPUs | Cases | Ports |
| --- | --- | --- | --- |
| Slot A / TP | node 0, `0,2,...,26,32,34,...,58` | TPCC, Sysbench, Scenario | `26001/26060` |
| Slot B / AP | node 1, `1,3,...,27,33,35,...,59` | SSB, TPCH, SIFT128 (lists 500/1000/2000/4000), GIST960 (lists 500/1000/2000/4000) | `27001/27060` |

Each lane owns one MatrixOne generation and reuses its `mo-data` across its
serial cases. Slot A hands its lease to Compatibility after TP completes;
Compatibility then runs Backup, MO CDC, and MySQL CDC with a fresh MatrixOne
generation for every case while Slot B may continue independently.

Family correctness and resource terminal state are separate contracts. A TP
case failure still leaves an auditable red Family result, but Compatibility may
continue when exact cleanup publishes `handoff_safe=true`. Slot B,
Compatibility, and an optional TPCC confirmation publish `release_safe=true`
only after the controller completes the exact fenced transition. `lanes-only`
releases both slots and never publishes a Compatibility handoff.

`full` is the optimized Daily product gate, `weekly` restores heavyweight
Sysbench and legacy CDC/checkpoint coverage, and `pilot` validates routing and
lifecycle with bounded small cases. Pilot evidence is never written into a
formal performance series.

## Host and resource contract

The campaign is host-exclusive relative to other host-129 nightly campaigns,
but it does not use the Stability or Chaos runner labels. It installs a second
repository runner, `mo-nightly-129-ap` / `mo-srv-129-ap`, so Slot A and Slot B
can execute concurrently without consuming those runner pools.

Before admission, the campaign:

1. creates an owner-bound host reservation;
2. records the host `oom_kill` counter and both lane memory fail counters;
3. identifies every host-native `mo-service` by PID, start time, executable,
   command line, and cgroup;
4. sends TERM and, only after bounded waiting and identity revalidation, KILL to
   the same surviving PID;
5. rechecks `MemAvailable`, topology, ports, datasets, images, and disk space.

It never uses `pkill` and never kills container-scoped MatrixOne processes by
name.

`bm129a.slice` and `bm129b.slice` are top-level cgroup-v1 parents shared by the
lane's Docker containers and transient systemd client unit. Each parent is
limited to 96 GiB, 28 logical CPUs, zero swap expansion, and a bounded task
count. Normal lanes budget 84 GiB for MatrixOne and 12 GiB for clients.
Compatibility budgets 56 GiB for MatrixOne, 24 GiB for owned clients/source
MySQL, and 8 GiB for Kafka. The host keeps a 32 GiB reserve.

Any increment in host `oom_kill`, either aggregate lane `memory.failcnt`, an MO
OOM/restart outside an explicitly planned Vector boundary, a missed result, or
an incomplete cleanup fails the campaign.

## Ownership and cancellation

The authoritative state is root-owned under:

```text
/run/mo-nightly-regression-129
/var/lib/mo-nightly-regression-129
```

Retained case data and evidence are stored under:

```text
/data3/mo-benchmark-runs/gh-<run-id>-<attempt>-<generation>/slot-<a|b>
```

Every lease has an unguessable fencing token. Every managed container carries
the exact host, slot, run, attempt, owner, and token labels. Cleanup stops only
the registered transient systemd unit and containers matching that generation.
Stopped Nightly data is retained until the next admitted campaign janitor
verifies it is no longer active and removes the exact owned directory.

An independent root-owned watchdog observes the GitHub run. If the run becomes
terminal before normal cleanup, it revokes the exact leases, stops the exact
registered units and labeled containers, frees their networks and ports, and
then removes the campaign fence. A failure to prove ownership remains
fail-closed for operator inspection.

The full non-pilot campaign transfers the trailing JSONBench, ClickBench,
AgentLogsBench, and TSBS phase to the same watchdog before any reusable workflow
starts. Their Compose projects, temporary image labels, MatrixOne source trees,
and runtime/data directories include the caller run ID and attempt. The pinned
TSBS callee also places the exact resource owner and Compose project in the job
environment, so every workload shell, converter, and database client inherits a
host-auditable process identity even while running from the shared workspace.
The watchdog repeatedly scans and terminates only that exact process generation
before removing runtime data or releasing the fence. Each stage must publish an
independent `release_safe=true` proof before ownership can move forward. Normal
release requires all four proofs plus a locked host-side absence audit;
cancellation or a lost runner leaves the watchdog able to stop only those
deterministic resources. Any ambiguous stop or cleanup retains the campaign
fence.

Manual dispatch also exposes `Run_Mode=benchmark`. It resolves `Branch` (a
MatrixOne branch, tag, or full SHA) once, reserves the host without building the
Family subject, and runs JSONBench 100M followed by ClickBench against that same
immutable commit, followed by AgentLogsBench 10M. `Run_Mode=full` keeps the
complete Family and appends the same ordered benchmark tail; the `pilot` profile
remains the bounded wiring-only exception and does not schedule heavyweight
benchmarks. Benchmark-only admission uses the single-workload 128GiB memory
floor; full campaigns retain the concurrent A/B 220GiB floor. Benchmark and
dashboard failures are reported without failing an otherwise healthy campaign,
while a missing cleanup proof remains a hard safety failure.

Before either benchmark tail, the prepare job provisions the persistent
`/data4/pengzhen/mo-benchmark-table-dumps` root as a setgid directory owned by
the shared `docker` group. This lets the generic campaign runner and the
repository-level benchmark runner reuse the same fixed-dataset table dumps.

## Shared on-demand pool V1

`mo-binary-search-on-129-new.yaml` exposes two equal half-host capacities. The
two runner processes are only GitHub execution capacity: `bm129-slot.sh` is the
single host resource authority and atomically assigns Slot A or B. A shared run
cannot choose ports, CPUs, NUMA placement, Docker names, or a second Slot. The
Daily campaign reservation fences new shared admission and can start only after
both Slot leases are absent.

For an `acquire-any` request, an unleased Slot is admissible only when both of
its reserved ports are free and it has no running 129-labeled containers. If
the preferred Slot fails one of those read-only checks, the controller tries
the sibling before publishing any Lease. It never stops or adopts the foreign
listener/container; when neither Slot is admissible, the bounded caller retry
remains fail-closed.

Admission also reserves the new Slot's 96 GiB entitlement, the 32 GiB host
reserve, and any unused entitlement of an already leased sibling against the
current `MemAvailable`. This accounts for unowned host pressure without
double-counting memory the sibling already uses. The Lease and durable owner
manifest record the host `oom_kill` and selected Slot `memory.failcnt`
baselines. Exact cleanup must stop owned resources and then prove both counters
unchanged before publishing the Slot free; a counter increase retains the
Lease for operator audit instead of certifying a potentially OOM-polluted run.

Before `acquire-any`, the Job starts one root-owned transient
`bm129-shared-watchdog-<run>-<attempt>-<family>.service`. The watchdog durably publishes
an `armed` acknowledgement before the workflow may publish a Lease. It binds
the GitHub run, local cleanup deadline, shared run ID, and the Lease's exact
fencing token. Normal `always()` cleanup and this independent service both call
the same token-fenced `shared-cleanup`; the controller lock decides the only
valid generation and a concurrent loser must prove exact absence. The workflow
stops the watchdog only after a locked
`shared-assert-absent` check. Runner loss, hard cancellation, or a killed
finalizer therefore leaves the root-owned watchdog in charge.

The immutable workload-tool checkouts finish before admission. After acquire,
the MatrixOne build first registers the same deterministic generation unit used
by later MO/case phases, then runs `make` inside that transient service, the
Slot aggregate slice, its CPU affinity, and NUMA binding. A terminal run cannot
release the Lease while this build unit remains active: exact cleanup must stop
the unit's complete control group and prove it inactive first. The in-unit
worker revalidates the Lease token before `make`, so a cleanup that wins the
register-to-start race prevents the build from starting. The collected unit
name is safely reused by the same generation for later phases; a different
generation derives a different name and token.

The lifecycle is `ACTIVE -> REVOKING -> absent`. Every GitHub poll, host lock,
Docker/systemd cleanup, and Job has a finite timeout. A terminal GitHub run or
the local hard deadline starts exact cleanup. A failed or ambiguous cleanup
keeps the Lease and retries; it never signals an unknown unit/container and
never publishes the Slot free. The watchdog remains armed across the
terminal-before-acquire crash cut until either the normal finalizer proves no
Lease exists or the local deadline closes the window.

Successful shared cleanup removes the exact run directory, owner manifest, and
empty generation parents. If the process crashes after Lease removal but before
that metadata removal, `prune_owned_runs.sh` accepts the exact absent run path,
rechecks leases, host markers, containers, and systemd state, then tombstones
and removes the orphan manifest. Thus both active work and durable registry
growth are bounded.

The shared entry exposes the legacy on-demand case set: MO-only, balanced BVT,
TPCC/SSB/TPCH/Sysbench, load-data, vector, CDC/MySQL CDC, concurrent DDL,
scenario, checkpoint dump, and full-text parser regression. Each selector is
routed through the same exact-SHA build, half-host Lease, bounded execution,
and exact cleanup contract. MySQL CDC uses its required Slot A profile; BVT is
split into two independently fenced groups so the two runner capacities can
finish it in parallel. CDC generations are always cleaned and cannot be kept.

`Test_list` accepts one or more comma-separated workloads. For example,
`tpcc,tpch` creates two independently leased Jobs. Subcases use the matching
input: `Test_list=tpcc` plus
`TPCC_TEST_LIST=tpcc10.10,tpcc10.100` runs both TPCC cells in one Slot and
reuses the 10-warehouse load. `After_Run=cleanup` is the default; `keep-1h`,
`keep-2h`, `keep-4h`, and `keep-8h` retain only a healthy final MO and are
still truncated by the local Daily fence. Keep is limited to one top-level
workload so retained Jobs cannot occupy both Slots while later selections wait.

To roll back, first disable shared dispatch, wait for or
exactly clean all shared leases, verify no shared watchdog unit remains, and
only then remove the shared adapter. Never roll back the controller while a
shared generation is active or `REVOKING`; an uncertain generation stays
fail-closed for operator diagnosis.

## Compatibility contract

- Backup uses the frozen `mo_br` binary and validates restored TPCC data plus a
  real TPCC workload.
- MO CDC uses deterministic database and table lifecycle assertions.
- MySQL CDC starts a fresh, owned MySQL 8.4 process from a new datadir, runs the
  deterministic DB1 snapshot and DB2 incremental operation-ledger oracles, and
  owns its Kafka/Flink processes in the same Slot A aggregate resource parent.
- The Daily MySQL CDC gate excludes partition fixtures because they are outside
  the current product scope. The weekly profile explicitly restores the legacy
  partition tables and mixed DML coverage for compatibility.
- The weekly compatibility profile also runs the legacy MO CDC TPCC, full/no-full
  and split-snapshot, fan-out, large-lineitem DML, and 43-table DDL cases, then
  runs the complete checkpoint-dump regression against the same fresh MO.

All tools and datasets are referenced through 129-specific verified paths.
Performance results use separate A/B half-host and sibling-free Slot A series.
The effective series binds static host topology, cgroup-v1 limits, cpuset/NUMA,
MO configuration, immutable tool revisions, and a name/size dataset manifest.
No 128 path, port, CPU list, or baseline is reused implicitly.

A performance decision requires five prior same-contract samples. High-IQR
history is reported as `UNSTABLE_BASELINE`, not a product regression. A
sibling-free confirmation reports `WARMUP` as inconclusive but non-blocking so
it can seed the five-sample baseline; it never presents that result as a
confirmed pass. `UNSTABLE_BASELINE` remains inconclusive and fails closed.

## Validation

The path-scoped `129 Family Contract` workflow runs on GitHub-hosted Ubuntu and
never touches host 129. The `test_*.sh` and `test_*.py` files cover lease/handoff crash boundaries,
watchdog recovery, exact compatibility scope, cgroup/OOM admission, result
evaluation, retention, semantic oracles, performance history selection, and
visible case reporting. Run them together with `bash -n`, Python compilation,
ShellCheck error severity, and `actionlint` before changing the scheduled
workflow.

## FULLTEXT2 performance history

The formal positional FULLTEXT2 lane retains complete raw evidence as the
`129-fulltext-<run>-<attempt>` Actions artifact for 30 days. After the workload
and exact Slot A cleanup both pass, a separate `FULLTEXT2 history publish` job
downloads that artifact, runs the current verifier again, and writes one run,
two index-build rows, and ten scenario rows to the existing `test_nightly`
database. The publisher never runs DDL and refuses any other database name.

`result/sql/FulltextHistory.sql` is the reviewed, non-destructive MySQL 5.7
migration. Apply it once before enabling publication; running it again is safe.
The structured history is retained indefinitely. It records hashes and
artifact/run links, but not raw SQL, plans, logs, or manifest JSON.

Only run `32265088926` is eligible for the initial backfill. Validate it before
opening a transaction:

```bash
python3 script/129/fulltext_history.py \
  --artifact-root /path/to/129-fulltext-32265088926-1 \
  --artifact-name 129-fulltext-32265088926-1 \
  --action-id 32265088926 --run-attempt 1 \
  --run-url https://github.com/matrixorigin/mo-auto-test/actions/runs/32265088926 \
  --release-safe true --mode backfill --dry-run
```

After review, repeat without `--dry-run` and pass `--config` with the protected
host performance configuration. Identical publication is a no-op; a conflicting
payload fails without overwriting history. Useful read-only queries are:

```sql
SELECT action_id, run_attempt, completed_at_utc, performance_series,
       matrixone_commit, canonical_payload_hash
FROM FulltextRun
ORDER BY completed_at_utc DESC;

SELECT r.completed_at_utc, m.parser, m.scenario, m.actual_qps,
       m.p50_ms, m.p90_ms, m.p99_ms
FROM FulltextScenarioMetric AS m
JOIN FulltextRun AS r USING (action_id, run_attempt)
WHERE r.performance_series = ?
ORDER BY r.completed_at_utc, m.parser, m.scenario;
```

This first version is collection-only. It does not make a regression decision;
a baseline policy can be designed after at least five scheduled samples exist
for the same performance series.
