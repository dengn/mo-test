#!/usr/bin/env python3

from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("filter_mysql_cdc_ddl.py")
SPEC = importlib.util.spec_from_file_location("filter_mysql_cdc_ddl", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
FILTER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = FILTER
SPEC.loader.exec_module(FILTER)


class FilterMysqlCdcDdlTest(unittest.TestCase):
    DDL = """
    create database if not exists __DB__;
    use __DB__;
    -- supported fixture
    create table __DB__.t_numeric_types(id bigint primary key, v int);
    create table __DB__.t_partition_range(id bigint, d date)
      partition by range(year(d)) (partition p0 values less than (2026));
    alter table __DB__.t_numeric_types add index idx_v(v);
    alter table __DB__.t_partition_range add index idx_d(d);
    """

    def test_excludes_every_statement_referencing_an_unplanned_table(self) -> None:
        output = FILTER.render(self.DDL, "cdc_run", {"t_numeric_types"})
        self.assertIn("create database if not exists cdc_run", output.lower())
        self.assertIn("create table cdc_run.t_numeric_types", output.lower())
        self.assertIn("alter table cdc_run.t_numeric_types", output.lower())
        self.assertNotIn("t_partition_range", output)

    def test_missing_planned_table_fails_closed(self) -> None:
        with self.assertRaisesRegex(ValueError, "absent from DDL"):
            FILTER.render(self.DDL, "cdc_run", {"t_unknown"})

    def test_semicolons_inside_strings_do_not_split_statements(self) -> None:
        ddl = "create table __DB__.t_string_types(id int, v varchar(8) default ';');"
        output = FILTER.render(ddl, "cdc_run", {"t_string_types"})
        self.assertEqual(output.count(";"), 2)

    def test_table_matching_is_case_insensitive_and_comments_do_not_expand_scope(self) -> None:
        ddl = """
        -- t_partition_range is deliberately out of scope.
        CREATE TABLE __DB__.T_NUMERIC_TYPES(id bigint primary key);
        """
        output = FILTER.render(ddl, "cdc_run", {"t_numeric_types"})
        self.assertIn("create table cdc_run.t_numeric_types", output.lower())

    def test_matrixone_dialect_normalizes_only_unquoted_mysql8_collation(self) -> None:
        ddl = """
        -- utf8mb4_0900_ai_ci must stay unchanged in comments.
        create table __DB__.t_string_types(
          id bigint primary key,
          note varchar(64) default 'utf8mb4_0900_ai_ci',
          value varchar(64) collate utf8mb4_0900_ai_ci
        ) default collate=utf8mb4_0900_ai_ci;
        """
        mysql = FILTER.render(ddl, "cdc_run", {"t_string_types"}, dialect="mysql")
        matrixone = FILTER.render(
            ddl, "cdc_run", {"t_string_types"}, dialect="matrixone"
        )
        self.assertEqual(mysql.count("utf8mb4_0900_ai_ci"), 4)
        self.assertEqual(matrixone.count("utf8mb4_general_ci"), 2)
        self.assertEqual(matrixone.count("utf8mb4_0900_ai_ci"), 2)


if __name__ == "__main__":
    unittest.main()
