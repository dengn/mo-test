#!/usr/bin/env python3

from __future__ import annotations

import importlib.util
import io
import json
import re
import sys
import unittest
from pathlib import Path


MODULE_PATH = Path(__file__).with_name("ivfflat_include_ca10m_repair_validation.py")
SPEC = importlib.util.spec_from_file_location("ivfflat_ca10m_validation", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
VALIDATION = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = VALIDATION
SPEC.loader.exec_module(VALIDATION)


class FakeCursor:
    def __init__(self) -> None:
        self.rows: list[tuple[str]] = []

    def execute(self, query: str, _params: tuple[object, ...]) -> None:
        match = re.search(r"LIMIT (\d+) BY RANK", query)
        assert match is not None
        self.rows = [(f"id-{index}", "source", 0) for index in range(int(match.group(1)))]

    def fetchall(self) -> list[tuple[str]]:
        return self.rows


class PlanCursor:
    def __init__(self, plans: list[str]) -> None:
        self.plans = plans
        self.rows: list[tuple[str]] = []

    def execute(self, _query: str, _params: tuple[object, ...]) -> None:
        self.rows = [(self.plans.pop(0),)]

    def fetchall(self) -> list[tuple[str]]:
        return self.rows


class ProtocolTest(unittest.TestCase):
    def test_query_projects_the_include_columns(self) -> None:
        query = VALIDATION.sql("include", "filter_bucket < 1", 10)
        self.assertIn("SELECT md5_id, source_type, filter_bucket", query)
        self.assertIn("mode=include", query)

    def test_query_rejects_rows_outside_the_requested_filter(self) -> None:
        cursor = FakeCursor()
        cursor.rows = [("id-1", "source", 10)]
        cursor.execute = lambda _query, _params: None  # type: ignore[method-assign]
        with self.assertRaisesRegex(RuntimeError, "filter_bucket=10"):
            VALIDATION.execute(cursor, "SELECT", "[0.0]", 1)

    def test_one_warmup_precedes_three_measured_rounds_for_every_cell(self) -> None:
        stream = io.StringIO()
        cold, cold_times, measured, times = VALIDATION.run_query_protocol(
            FakeCursor(), stream, "include", "[0.0]")
        events = [json.loads(line) for line in stream.getvalue().splitlines()]

        cells = len(VALIDATION.FILTERS) * len(VALIDATION.KS)
        warmup_events = [event for event in events if event["phase"] == "warmup"]
        measured_events = [event for event in events if event["phase"] == "measured"]
        self.assertEqual(len(warmup_events), cells)
        self.assertEqual(len(measured_events), cells * 3)
        self.assertTrue(all(event["cold_start"] for event in warmup_events))
        self.assertEqual({event["round"] for event in measured_events}, {1, 2, 3})
        first_measured = next(index for index, event in enumerate(events)
                              if event["phase"] == "measured")
        self.assertTrue(all(event["phase"] == "warmup"
                            for event in events[:first_measured]))
        self.assertEqual(set(cold), set(measured))
        self.assertEqual(set(cold), set(cold_times))
        self.assertEqual(set(measured), set(times))
        self.assertTrue(all(len(executions) == 3 for executions in measured.values()))
        for key, executions in measured.items():
            self.assertEqual(len(cold[key]), key[2])
            self.assertTrue(all(len(ids) == key[2] for ids in executions))

    def test_approximate_baselines_do_not_fail_exact_cardinality_gate(self) -> None:
        self.assertEqual(
            VALIDATION.exact_cardinality_failures(
                "pre", "1%", 10, ["one"], [["one"], []]),
            [],
        )
        failures = VALIDATION.exact_cardinality_failures(
            "include", "1%", 10, ["one"], [["one"], []])
        self.assertEqual(
            [(failure["phase"], failure["rows"]) for failure in failures],
            [("warmup", [1]), ("measured", [1, 0])],
        )

    def test_include_plan_requires_direct_index_filter_path(self) -> None:
        VALIDATION.require_candidate_plan("include", "Vector Index Scan\nIndex Filter")
        with self.assertRaisesRegex(RuntimeError, "direct Index Filter"):
            VALIDATION.require_candidate_plan("include", "Vector Index Scan")
        with self.assertRaisesRegex(RuntimeError, "direct Index Filter"):
            VALIDATION.require_candidate_plan(
                "include", "Vector Index Scan\nIndex Filter\nJoin")

    def test_plan_polling_waits_for_index_readiness(self) -> None:
        cells = len(VALIDATION.FILTERS) * len(VALIDATION.KS)
        cursor = PlanCursor(
            ["Table Scan"]
            + ["Vector Index Scan\nIndex Filter"] * cells
        )
        stream = io.StringIO()
        old_sleep = VALIDATION.time.sleep
        try:
            VALIDATION.time.sleep = lambda _seconds: None
            VALIDATION.wait_for_candidate_plans(
                cursor, stream, "include_index", "include", "[0.0]"
            )
        finally:
            VALIDATION.time.sleep = old_sleep
        events = [json.loads(line) for line in stream.getvalue().splitlines()]
        self.assertEqual(events[0]["readiness_attempt"], 1)
        self.assertEqual(len(events), cells + 1)
        self.assertTrue(all(event["readiness_attempt"] == 2 for event in events[1:]))


if __name__ == "__main__":
    unittest.main()
