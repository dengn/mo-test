#!/usr/bin/env python3

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import io
from contextlib import redirect_stdout
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import unittest


MODULE_PATH = Path(__file__).with_name("connector_family.py")
SPEC = importlib.util.spec_from_file_location("connector_family", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
connector = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(connector)


class ConnectorFamilyContractTest(unittest.TestCase):
    def test_mongodb_image_preparation_is_pinned_and_fail_closed(self) -> None:
        runner = MODULE_PATH.with_name("run_connector_family.sh").read_text()
        # Exercise the real preparation functions without systemd or a Docker daemon.
        functions = runner[runner.index("require_reviewed_image_id() {"):
                           runner.index("require_reviewed_iceberg_image_ids() {")]
        constants = "\n".join(line for line in runner.splitlines()
                              if line.startswith("readonly mongodb_"))
        for scenario in ("alias", "cached", "source", "pull", "bad-alias",
                         "bad-source", "pull-failed", "tag-failed"):
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory() as tmp:
                calls = Path(tmp) / "calls"
                script = constants + "\n" + functions + r'''
timeout() { shift 3; "$@"; }
docker() {
  printf '%s\n' "$*" >>"$CALLS"
  if [[ "$1 $2" == 'image inspect' ]]; then
    local ref="${@: -1}"
    if [[ "$*" == *'--format'* ]]; then
      if [[ "$SCENARIO" == bad-* ]]; then echo sha256:wrong;
      else echo "$mongodb_local_image_id"; fi
    elif [[ "$ref" == "$mongodb_local_image" ]]; then
      [[ "$SCENARIO" == alias || "$SCENARIO" == bad-alias || -f "$CALLS.tagged" ]]
    elif [[ "$ref" == "$mongodb_local_image_id" ]]; then
      [[ "$SCENARIO" == cached || "$SCENARIO" == tag-failed ]]
    else
      [[ "$SCENARIO" == source || "$SCENARIO" == bad-source ]]
    fi
  elif [[ "$1" == pull ]]; then
    [[ "$SCENARIO" != pull-failed ]]
  elif [[ "$1 $2" == 'image tag' ]]; then
    [[ "$SCENARIO" != tag-failed ]] || return 1
    touch "$CALLS.tagged"
  else return 99; fi
}
ensure_reviewed_mongodb_image
'''
                result = subprocess.run(["bash", "-c", script], capture_output=True,
                                        text=True, env={**os.environ, "SCENARIO": scenario,
                                                        "CALLS": str(calls)})
                expected_success = scenario in ("alias", "cached", "source", "pull")
                self.assertEqual(result.returncode == 0, expected_success, result.stderr)
                commands = calls.read_text().splitlines()
                pulls = [line for line in commands if line.startswith("pull ")]
                self.assertEqual(len(pulls), int(scenario in ("pull", "pull-failed")))
                if pulls:
                    self.assertRegex(pulls[0], r"^pull mongo@sha256:[0-9a-f]{64}$")
                tags = [line for line in commands if line.startswith("image tag ")]
                self.assertEqual(bool(tags), scenario in ("cached", "source", "pull", "tag-failed"))

    def test_single_case_plan_and_finalization(self) -> None:
        for selected in connector.CASES:
            with self.subTest(case=selected), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                args = connector.parser().parse_args([
                    "plan", "--case", selected, "--matrixone-commit", "a" * 40,
                    "--run-id", "123", "--run-attempt", "1",
                    "--output", str(root / "connector-plan.json"),
                ])
                connector.build_plan(args)
                plan = connector.validate_plan(connector.load_json(args.output))
                self.assertEqual(plan["selected_target_refs"], [connector.CASE_TARGETS[selected]])
                final = argparse.Namespace(root=root, family_cleanup_safe="true")
                with self.assertRaises(connector.ContractError):
                    connector.finalize(final)  # A selected case must actually run.
                evidence = root / "evidence.txt"
                evidence.write_text("immutable subject and dependencies")
                record = argparse.Namespace(
                    root=root, case=selected, status="passed", exit_code=0,
                    cleanup_safe="true", started_at="2026-09-18T01:00:00Z",
                    completed_at="2026-09-18T01:05:00Z",
                    resource_owner=f"gh-123-1-connector-{selected}",
                    report_dir=root / "reports" / selected,
                    dependency_evidence=evidence, subject_binary=evidence,
                )
                connector.record(record)
                with redirect_stdout(io.StringIO()):
                    connector.finalize(final)
                results = connector.load_json(root / "connector-results.json")
                self.assertTrue(results["passed"])
                self.assertTrue(results["release_safe"])
                self.assertEqual([item["target_ref"] for item in results["results"]],
                                 [connector.CASE_TARGETS[selected]])
                record.case = "mongodb" if selected == "iceberg" else "iceberg"
                record.resource_owner = f"gh-123-1-connector-{record.case}"
                with self.assertRaisesRegex(connector.ContractError, "not selected"):
                    connector.record(record)
                final.family_cleanup_safe = "false"
                with redirect_stdout(io.StringIO()), self.assertRaises(connector.ContractError):
                    connector.finalize(final)

    def test_plan_rejects_empty_unknown_duplicate_and_reordered_targets(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / "plan.json"
            connector.build_plan(argparse.Namespace(
                matrixone_commit="a" * 40, run_id="123", run_attempt=1, output=output,
            ))
            plan = connector.load_json(output)
            targets = plan["selected_target_refs"]
            for invalid in ([], ["unknown"], [targets[0], targets[0]], targets[::-1]):
                with self.subTest(targets=invalid):
                    plan["selected_target_refs"] = invalid
                    unsigned = {key: value for key, value in plan.items() if key != "plan_digest"}
                    plan["plan_digest"] = connector.json_digest(unsigned)
                    with self.assertRaises(connector.ContractError):
                        connector.validate_plan(plan)

    def test_shell_runner_closes_both_owned_stacks_with_fake_tools(self) -> None:
        probes = []
        try:
            for port in (6001, 9000, 9001, 19120, 19121):
                probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                probes.append(probe)
                probe.bind(("127.0.0.1", port))
        except OSError:
            self.skipTest("fixed Iceberg ports are intentionally guarded and in use")
        finally:
            for probe in probes:
                probe.close()
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "matrixone"
            tools = root / "tools"
            results = root / "results"
            runtime = root / "runtime"
            (source / "etc/launch-minio-local").mkdir(parents=True)
            (source / "etc/launch-mongodb-local").mkdir(parents=True)
            tools.mkdir()
            (source / "etc/launch-minio-local/docker-compose.yml").write_text(
                """services:
  minio:
    image: minio/minio:RELEASE.2023-11-01T18-37-25Z
    container_name: mo-minio-local
    volumes:
      - ./mo-data/minio-data:/data
  nessie:
    image: ghcr.io/projectnessie/nessie:latest
    container_name: mo-nessie-local
  createbuckets:
    image: minio/mc:RELEASE.2023-10-30T18-43-32Z
    container_name: mo-minio-createbuckets
""",
                encoding="utf-8",
            )
            (source / "etc/launch-minio-local/launch.toml").write_text(
                """logservices = [
    "./etc/launch-minio-local/log.toml",
]
tnservices = [
    "./etc/launch-minio-local/tn.toml"
]
cnservices = [
    "./etc/launch-minio-local/cn.toml"
]
""",
                encoding="utf-8",
            )
            for config_name in ("log.toml", "tn.toml", "cn.toml"):
                (source / f"etc/launch-minio-local/{config_name}").write_text(
                    """data-dir = "./etc/launch-minio-local/mo-data"
[fileservice]
data-dir = "./etc/launch-minio-local/mo-data"
[fileservice.cache]
disk-path = "etc/launch-minio-local/mo-data/file-service-cache"
""",
                    encoding="utf-8",
                )
            (source / "etc/launch-mongodb-local/compose.yaml").write_text(
                "services:\n  mongo:\n"
                "    image: mongo@sha256:"
                "95a98776f273721a295b03098578b06bc10281bb56aa828c77e9f60ecc70b150\n",
                encoding="utf-8",
            )
            fake_make = tools / "make"
            fake_make.write_text(
                """#!/usr/bin/env bash
set -euo pipefail
case "$*" in
  *test-iceberg-e2e-local*)
    iceberg_tmp="$(mktemp -d "${TMPDIR%/}/mo-iceberg-e2e-local.XXXXXX")"
    printf 'fake Iceberg mo-service binary raw-token\n' >"$iceberg_tmp/mo-service"
    chmod 0755 "$iceberg_tmp/mo-service"
    install -d -m 0755 "$MO_ICEBERG_REPORT_DIR"
    printf '%s\n' '{"cases":[{"case_id":"ICE-CI-E2E-001","status":"passed"}]}' >"$MO_ICEBERG_REPORT_DIR/summary.json"
    for attempt in {1..100}; do
      if [[ -s "$BM129_CONNECTOR_RUNTIME_ROOT/gh-$GITHUB_RUN_ID-$GITHUB_RUN_ATTEMPT-connector-iceberg/mo-service.subject" ||
            -s "$MO_ICEBERG_REPORT_DIR/mo-service.subject" ]]; then break; fi
      sleep 0.05
    done
    [[ $attempt -lt 100 ]] || exit 2
    if [[ "${FAKE_SENSITIVE_REPORT:-}" == 1 ]]; then
      printf 'raw-token\n' >"$MO_ICEBERG_REPORT_DIR/unsafe.log"
    fi
    if grep -R -E '(AKIA[0-9A-Z]{16}|X-Amz-Signature=|AWSAccessKeyId=|raw-token|raw-secret-key)' "$MO_ICEBERG_REPORT_DIR" >/dev/null 2>&1; then
      echo 'report directory contains unredacted sensitive material' >&2
      exit 1
    fi
    rm -f -- "$iceberg_tmp/mo-service"
    rmdir "$iceberg_tmp"
    ;;
  *test-mongodb-e2e-local*)
    owned="$(mktemp -d /private/tmp/mo-mongodb-e2e.XXXXXX)"
    key_dir="$(mktemp -d "$PWD/../.mo-mongodb-key-source.XXXXXX")"
    printf 'fake secret\n' >"$key_dir/mongodb-keyfile"
    sleep 2
    printf 'fake MongoDB mo-service binary\n' >mo-service
    chmod 0755 mo-service
    install -d -m 0755 "$MO_MONGODB_REPORT_DIR"
    printf '%s\n' '{"status":"passed","cases":["scan"]}' >"$MO_MONGODB_REPORT_DIR/report.json"
    rm -f -- "$key_dir/mongodb-keyfile"
    if [[ "$(basename "$key_dir")" == .mo-mongodb-key-source.* ]]; then
      rmdir "$key_dir"
    fi
    rm -rf -- "$owned"
    ;;
  *) exit 2 ;;
esac
""",
                encoding="utf-8",
            )
            fake_make.chmod(0o755)
            fake_docker = tools / "docker"
            fake_docker.write_text(
                """#!/usr/bin/env bash
set -euo pipefail
if [[ "$*" == 'compose version' ]]; then exit 0; fi
if [[ "$*" == *'config --images' ]]; then
  if [[ "$*" == *iceberg-compose.yml* ]]; then
    printf '%s\n' \
      minio/minio:RELEASE.2023-11-01T18-37-25Z \
      ghcr.io/projectnessie/nessie:latest \
      minio/mc:RELEASE.2023-10-30T18-43-32Z
  else
    printf '%s\n' mo-nightly/mongo:95a98776f273
  fi
  exit 0
fi
case "$*" in
  'image inspect --format {{.Id}} minio/minio:RELEASE.2023-11-01T18-37-25Z')
    printf '%s\n' 'sha256:c96851d33ed3e44e74ea869af7ec017daec8a19be118bcad7cdc5156c09cc2ed'; exit 0 ;;
  'image inspect --format {{.Id}} ghcr.io/projectnessie/nessie:latest')
    if [[ "${FAKE_BAD_NESSIE_ID:-}" == 1 ]]; then
      printf '%s\n' 'sha256:ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'
    else
      printf '%s\n' 'sha256:88ba04344968358d8b365b21b8d55127ba2b8ba8945f4e0cbe1c0e04243f4a4e'
    fi
    exit 0 ;;
  'image inspect --format {{.Id}} minio/mc:RELEASE.2023-10-30T18-43-32Z')
    printf '%s\n' 'sha256:d04e4ca1768a3b5ac2fb535606d36caea37d412e922d48122a454f3591fa9b9e'; exit 0 ;;
  'image inspect --format {{.Id}} mo-nightly/mongo:95a98776f273')
    printf '%s\n' 'sha256:91dcc14380635cc7184b14c4839d0e4cbb98ecc1ba92558b531dec565d8772df'; exit 0 ;;
esac
if [[ "$*" == image\\ inspect* ]]; then
  printf '%s\n' 'id=sha256:aaaaaaaa repo_digests=example.invalid/connector@sha256:bbbbbbbb'
  exit 0
fi
if [[ "$*" == *'down --volumes --remove-orphans' ]]; then exit 0; fi
if [[ "$*" == ps\\ -aq* || "$*" == network\\ ls* || "$*" == volume\\ ls* ]]; then exit 0; fi
exit 2
""",
                encoding="utf-8",
            )
            fake_docker.chmod(0o755)
            (tools / "sudo").write_text(
                "#!/usr/bin/env bash\nset -euo pipefail\nexec \"$@\"\n",
                encoding="utf-8",
            )
            (tools / "sudo").chmod(0o755)
            (tools / "systemctl").write_text(
                """#!/usr/bin/env bash
set -euo pipefail
case "${1:-}" in
  show)
    case "$*" in
      *'-p LoadState'*) printf 'loaded\n' ;;
      *'-p ActiveState'*) printf 'inactive\n' ;;
      *) exit 2 ;;
    esac
    ;;
  stop|reset-failed) ;;
  *) exit 2 ;;
esac
""",
                encoding="utf-8",
            )
            (tools / "systemctl").chmod(0o755)
            (tools / "systemd-run").write_text(
                """#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$@" >>"${SYSTEMD_RUN_LOG:?SYSTEMD_RUN_LOG is required}"
while (( $# > 0 )); do
  case "$1" in
    --unit|-p) shift 2 ;;
    --quiet|--pipe|--wait|--collect) shift ;;
    *) exec "$@" ;;
  esac
done
exit 2
""",
                encoding="utf-8",
            )
            (tools / "systemd-run").chmod(0o755)
            subprocess.run(["git", "init", "-q", str(source)], check=True)
            subprocess.run(
                ["git", "-C", str(source), "config", "user.email", "test@example.invalid"],
                check=True,
            )
            subprocess.run(
                ["git", "-C", str(source), "config", "user.name", "Connector Test"],
                check=True,
            )
            subprocess.run(["git", "-C", str(source), "add", "."], check=True)
            subprocess.run(
                ["git", "-C", str(source), "commit", "-qm", "fixture"], check=True
            )
            commit = subprocess.check_output(
                ["git", "-C", str(source), "rev-parse", "HEAD"], text=True
            ).strip()
            environment = {
                **os.environ,
                "PATH": f"{tools}:{os.environ['PATH']}",
                "BM129_CONNECTOR_SOURCE": str(source),
                "BM129_CONNECTOR_RESULT_ROOT": str(results),
                "BM129_CONNECTOR_RUNTIME_ROOT": str(runtime),
                "BM129_MATRIXONE_COMMIT": commit,
                "GITHUB_RUN_ID": "32989236595",
                "GITHUB_RUN_ATTEMPT": "2",
                "BM129_CONNECTOR_FAMILY_CLEANUP_SAFE": "true",
                "SYSTEMD_RUN_LOG": str(root / "systemd-run.log"),
            }
            runner = MODULE_PATH.with_name("run_connector_family.sh")
            bad_environment = {
                **environment,
                "BM129_CONNECTOR_RESULT_ROOT": str(root / "bad-results"),
                "BM129_CONNECTOR_RUNTIME_ROOT": str(root / "bad-runtime"),
                "GITHUB_RUN_ID": "32989236596",
                "FAKE_BAD_NESSIE_ID": "1",
                "SYSTEMD_RUN_LOG": str(root / "bad-systemd-run.log"),
            }
            bad_plan = subprocess.run(
                ["bash", str(runner), "plan"],
                cwd=source,
                env=bad_environment,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(bad_plan.returncode, 0, msg=bad_plan.stderr)
            bad_iceberg = subprocess.run(
                ["bash", str(runner), "iceberg"],
                cwd=source,
                env=bad_environment,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertNotEqual(bad_iceberg.returncode, 0)
            self.assertIn("image ID mismatch", bad_iceberg.stderr)
            self.assertFalse((root / "bad-systemd-run.log").exists())
            sensitive_environment = {
                **environment, "FAKE_SENSITIVE_REPORT": "1",
                "BM129_CONNECTOR_RESULT_ROOT": str(root / "sensitive-results"),
                "BM129_CONNECTOR_RUNTIME_ROOT": str(root / "sensitive-runtime"),
            }
            for command in ("plan", "iceberg"):
                sensitive = subprocess.run(["bash", str(runner), command],
                                           cwd=source, env=sensitive_environment,
                                           capture_output=True, text=True)
                if command == "plan":
                    self.assertEqual(sensitive.returncode, 0, sensitive.stderr)
                else:
                    self.assertNotEqual(sensitive.returncode, 0)
                    self.assertIn("unredacted sensitive material", sensitive.stderr)
            for command in ("plan", "iceberg", "mongodb", "cleanup", "finalize"):
                completed = subprocess.run(
                    ["bash", str(runner), command],
                    cwd=source,
                    env=environment,
                    text=True,
                    capture_output=True,
                    check=False,
                )
                self.assertEqual(
                    completed.returncode,
                    0,
                    msg=f"{command}: stdout={completed.stdout} stderr={completed.stderr}",
                )
                if command == "iceberg":
                    owner_runtime = (
                        runtime / "gh-32989236595-2-connector-iceberg"
                    )
                    config_root = owner_runtime / "mo-config"
                    data_root = owner_runtime / "mo-data"
                    for config_name in ("log.toml", "tn.toml", "cn.toml"):
                        rendered = (config_root / config_name).read_text(
                            encoding="utf-8"
                        )
                        self.assertIn(str(data_root), rendered)
                        self.assertNotIn("launch-minio-local/mo-data", rendered)
                    launch = (config_root / "launch.toml").read_text(
                        encoding="utf-8"
                    )
                    for config_name in ("log.toml", "tn.toml", "cn.toml"):
                        self.assertIn(str(config_root / config_name), launch)
                    self.assertFalse(
                        (source / "etc/launch-minio-local/mo-data").exists()
                    )
                    bind = (
                        f"BindReadOnlyPaths={config_root / 'launch.toml'}:"
                        f"{source / 'etc/launch-minio-local/launch.toml'}"
                    )
                    self.assertIn(
                        bind,
                        (root / "systemd-run.log").read_text(encoding="utf-8"),
                    )
                if command == "mongodb":
                    owner_runtime = (
                        runtime / "gh-32989236595-2-connector-mongodb"
                    )
                    mongo_bind = (
                        f"BindReadOnlyPaths={owner_runtime / 'mongodb-compose.yaml'}:"
                        f"{source / 'etc/launch-mongodb-local/compose.yaml'}"
                    )
                    self.assertIn(
                        mongo_bind,
                        (root / "systemd-run.log").read_text(encoding="utf-8"),
                    )
            iceberg = json.loads(
                (results / "cases/iceberg.json").read_text(encoding="utf-8")
            )
            expected_iceberg_digest = "sha256:" + hashlib.sha256(
                b"fake Iceberg mo-service binary raw-token\n"
            ).hexdigest()
            self.assertEqual(iceberg["subject_binary_digest"], expected_iceberg_digest)
            mongodb = json.loads(
                (results / "cases/mongodb.json").read_text(encoding="utf-8")
            )
            expected_mongodb_digest = "sha256:" + hashlib.sha256(
                b"fake MongoDB mo-service binary\n"
            ).hexdigest()
            self.assertEqual(mongodb["subject_binary_digest"], expected_mongodb_digest)
            final = json.loads(
                (results / "connector-results.json").read_text(encoding="utf-8")
            )
            self.assertTrue(final["passed"])
            self.assertTrue(final["release_safe"])
            self.assertEqual(list(runtime.iterdir()), [])

    def test_plan_cases_reports_and_final_result_are_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            connector.build_plan(
                argparse.Namespace(
                    matrixone_commit="a" * 40,
                    run_id="32989236595",
                    run_attempt=2,
                    output=root / "connector-plan.json",
                )
            )
            plan = json.loads(
                (root / "connector-plan.json").read_text(encoding="utf-8")
            )
            self.assertEqual(
                plan["selected_target_refs"],
                [connector.CASE_TARGETS[item] for item in connector.CASES],
            )
            self.assertRegex(plan["plan_digest"], r"^sha256:[0-9a-f]{64}$")

            reports = root / "reports"
            iceberg_report = reports / "iceberg"
            mongodb_report = reports / "mongodb"
            iceberg_report.mkdir(parents=True)
            mongodb_report.mkdir(parents=True)
            (iceberg_report / "summary.json").write_text(
                json.dumps(
                    {
                        "cases": [
                            {"case_id": "ICE-CI-E2E-001", "status": "passed"}
                        ]
                    }
                ),
                encoding="utf-8",
            )
            (mongodb_report / "report.json").write_text(
                json.dumps({"status": "passed", "cases": ["scan", "filter"]}),
                encoding="utf-8",
            )
            connector.verify_report(
                argparse.Namespace(case="iceberg", report_dir=iceberg_report)
            )
            connector.verify_report(
                argparse.Namespace(case="mongodb", report_dir=mongodb_report)
            )

            for selected, report in (
                ("iceberg", iceberg_report),
                ("mongodb", mongodb_report),
            ):
                dependency_evidence = report / "container-images.txt"
                dependency_evidence.write_text(
                    "image=example.invalid/test@sha256:" + "b" * 64 + "\n",
                    encoding="utf-8",
                )
                subject_binary = root / "mo-service"
                subject_binary.write_bytes(b"exact connector subject")
                connector.record(
                    argparse.Namespace(
                        root=root,
                        case=selected,
                        status="passed",
                        exit_code=0,
                        cleanup_safe="true",
                        started_at="2026-08-27T01:00:00Z",
                        completed_at="2026-08-27T01:05:00Z",
                        resource_owner=f"gh-32989236595-2-connector-{selected}",
                        report_dir=report,
                        dependency_evidence=dependency_evidence,
                        subject_binary=subject_binary,
                    )
                )

            unsafe_output = io.StringIO()
            with self.assertRaisesRegex(connector.ContractError, "unsafe case"):
                with redirect_stdout(unsafe_output):
                    connector.finalize(
                        argparse.Namespace(root=root, family_cleanup_safe="false")
                    )
            self.assertEqual(unsafe_output.getvalue(), "release_safe=false\n")
            unsafe_results = json.loads(
                (root / "connector-results.json").read_text(encoding="utf-8")
            )
            self.assertFalse(unsafe_results["release_safe"])

            output = io.StringIO()
            with redirect_stdout(output):
                connector.finalize(
                    argparse.Namespace(root=root, family_cleanup_safe="true")
                )
            self.assertEqual(output.getvalue(), "release_safe=true\n")
            results = json.loads(
                (root / "connector-results.json").read_text(encoding="utf-8")
            )
            self.assertTrue(results["passed"])
            self.assertTrue(results["release_safe"])
            self.assertEqual(len(results["results"]), 2)
            self.assertEqual(results["run"], {"id": "32989236595", "attempt": 2})

    def test_plan_digest_owner_and_timestamps_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            plan_path = root / "connector-plan.json"
            connector.build_plan(
                argparse.Namespace(
                    matrixone_commit="c" * 40,
                    run_id="700",
                    run_attempt=3,
                    output=plan_path,
                )
            )
            tampered = json.loads(plan_path.read_text(encoding="utf-8"))
            tampered["matrixone_commit"] = "d" * 40
            with self.assertRaisesRegex(connector.ContractError, "digest mismatch"):
                connector.validate_plan(tampered)

            report = root / "reports/iceberg"
            report.mkdir(parents=True)
            dependency_evidence = report / "container-images.txt"
            dependency_evidence.write_text("image=example.invalid/iceberg:1\n")
            subject_binary = report / "mo-service.subject"
            subject_binary.write_bytes(b"exact subject")
            common = {
                "root": root,
                "case": "iceberg",
                "status": "passed",
                "exit_code": 0,
                "cleanup_safe": "true",
                "started_at": "2026-08-27T02:00:00Z",
                "completed_at": "2026-08-27T02:01:00Z",
                "report_dir": report,
                "dependency_evidence": dependency_evidence,
                "subject_binary": subject_binary,
            }
            with self.assertRaisesRegex(connector.ContractError, "plan attempt"):
                connector.record(
                    argparse.Namespace(
                        **common,
                        resource_owner="gh-700-4-connector-iceberg",
                    )
                )
            reversed_time = dict(common)
            reversed_time["completed_at"] = "2026-08-27T01:59:59Z"
            with self.assertRaisesRegex(connector.ContractError, "precedes"):
                connector.record(
                    argparse.Namespace(
                        **reversed_time,
                        resource_owner="gh-700-3-connector-iceberg",
                    )
                )

    def test_rendered_iceberg_compose_removes_global_ownership(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "compose.yml"
            output = root / "rendered.yml"
            source.write_text(
                """services:
  minio:
    image: minio/minio:RELEASE.2023-11-01T18-37-25Z
    container_name: mo-minio-local
    volumes:
      - ./mo-data/minio-data:/data
  nessie:
    image: ghcr.io/projectnessie/nessie:latest
    container_name: mo-nessie-local
  createbuckets:
    image: minio/mc:RELEASE.2023-10-30T18-43-32Z
    container_name: mo-minio-createbuckets
""",
                encoding="utf-8",
            )
            data_root = root / "owned-minio-data"
            connector.render_iceberg(
                argparse.Namespace(
                    source=source, output=output, data_root=data_root
                )
            )
            rendered = output.read_text(encoding="utf-8")
            self.assertNotIn("container_name:", rendered)
            self.assertNotIn("./mo-data/minio-data", rendered)
            self.assertIn(f"- {data_root}:/data", rendered)
            self.assertEqual(rendered.count("pull_policy: never"), 3)
            self.assertRegex(
                rendered,
                r"image: ghcr\.io/projectnessie/nessie:latest\n\s+pull_policy: never",
            )

    def test_rendered_mongodb_compose_uses_reviewed_local_image(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "compose.yaml"
            output = root / "rendered.yaml"
            digest = "a" * 64
            source.write_text(
                f"services:\n  mongo:\n    image: mongo@sha256:{digest}\n",
                encoding="utf-8",
            )
            connector.render_mongodb(
                argparse.Namespace(
                    source=source,
                    output=output,
                    source_image=f"mongo@sha256:{digest}",
                    local_image="mo-nightly/mongo:aaaaaaaaaaaa",
                )
            )
            rendered = output.read_text(encoding="utf-8")
            self.assertNotIn(f"mongo@sha256:{digest}", rendered)
            self.assertIn("image: mo-nightly/mongo:aaaaaaaaaaaa", rendered)
            self.assertEqual(output.stat().st_mode & 0o777, 0o600)

    def test_invalid_owner_and_nonpassing_oracle_fail_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            report = Path(temporary)
            (report / "report.json").write_text(
                json.dumps({"status": "failed", "cases": ["scan"]}),
                encoding="utf-8",
            )
            with self.assertRaises(connector.ContractError):
                connector.verify_report(
                    argparse.Namespace(case="mongodb", report_dir=report)
                )
            self.assertEqual(connector.report_outcome("mongodb", report), "failed")
            with self.assertRaises(connector.ContractError):
                connector.owner("mo-mongodb-global", "mongodb")


if __name__ == "__main__":
    unittest.main()
