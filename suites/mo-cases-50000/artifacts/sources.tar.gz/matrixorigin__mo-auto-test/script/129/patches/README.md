# 129 compatibility tool patches

The 129 Family campaign builds its Flink CDC runtime from the exact local
baseline commit recorded by the workflow, then applies the patches in this
directory before running the tool's Maven test suite and packaging the frozen
subject artifact.

`flink-cdc-bit-representations.patch` carries the deterministic type-conversion
fixes exposed by the 129 MySQL CDC ledger. It converts Debezium `BIT(n)` values
represented as `Boolean` or `byte[]`, preserves fractional microseconds for
`TIME`, and retains the final 999 milliseconds at the upper `DATETIME` bound.
The previous fallback converted `Boolean.TRUE` to zero, dropped `TIME`
fractions, and clamped `9999-12-31 23:59:59.999999` to a `.000xxx` value. The
patch intentionally covers both consumer implementations and adds focused unit
tests for the active pipeline conversion helpers.

The configured upstream remotes for the host copy are no longer available on
GitHub, so the campaign records all of the following in its immutable artifact:

- the exact unmodified baseline commit;
- the complete applied patch;
- the patch SHA-256;
- hashes for every packaged Flink CDC runtime file.

Remove the patch only after the same fix is present in a reachable, immutable
upstream revision and the workflow has been moved to that revision.
