#!/usr/bin/env python3

from __future__ import annotations

import copy
import csv
import hashlib
import importlib.util
import json
import os
import shutil
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import pymysql


MODULE_PATH = Path(__file__).with_name("fulltext_history.py")
SPEC = importlib.util.spec_from_file_location("fulltext_history", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
history = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(history)

MATRIXONE_COMMIT = "1" * 40
AUTO_TEST_COMMIT = "2" * 40
MO_LOAD_COMMIT = "3" * 40
DATA_HASH = "4" * 64
SOURCE_QUERY_HASH = "5" * 64
MO_BINARY_HASH = "6" * 64
JIEBA_HASH = "7" * 64
JAR_HASH = "8" * 64
VERIFICATION_PASS = "PASS: formal FULLTEXT2 ngram/gojieba evidence is complete\n"


def write_tsv(path: Path, columns: list[str], rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=columns, delimiter="\t", lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def build_fixture(root: Path, action_id: int = history.BACKFILL_ACTION_ID) -> SimpleNamespace:
    attempt = 1
    artifact_name = f"129-fulltext-{action_id}-{attempt}"
    artifact = root / artifact_name
    slot = artifact / "slot-a"
    meta = slot / "meta"
    result = slot / "results" / "fulltext-parser-regression"
    meta.mkdir(parents=True)
    result.mkdir(parents=True)
    (meta / "run-manifest.txt").write_text(
        "\n".join(
            (
                "started_at=2026-08-19T22:53:03+08:00",
                f"run_id=gh-{action_id}-{attempt}-fulltext",
                "slot=a",
                "admission_mode=service-only",
                "profile_mode=disabled",
                "cpuset_cpus=0,2,4,6",
                "cpuset_mems=0",
                "mo_memory=84GiB",
                "mo_gomemlimit=76GiB",
                f"mo_commit={MATRIXONE_COMMIT}",
                f"regression_commit={AUTO_TEST_COMMIT}",
                f"mo_binary_sha256={MO_BINARY_HASH}",
                f"jieba_dict_manifest_sha256={JIEBA_HASH}",
                "Architecture: x86_64",
                "CPU(s): 64",
                "Model name: Intel(R) Xeon(R) Silver 4314 CPU @ 2.40GHz",
                "",
            )
        ),
        encoding="utf-8",
    )
    (meta / "fulltext-subject.txt").write_text(
        "\n".join(
            (
                f"mo_load_commit={MO_LOAD_COMMIT}",
                f"mo_load_jar_sha256={JAR_HASH}",
                f"corpus_sha256={DATA_HASH}",
                f"queries_sha256={SOURCE_QUERY_HASH}",
                "",
            )
        ),
        encoding="utf-8",
    )
    (result / "verification.txt").write_text(VERIFICATION_PASS, encoding="utf-8")
    (result / "ngram_drop_show_create.txt").write_text("no ngram index\n", encoding="utf-8")
    (result / "ngram_drop_show_index.txt").write_text("no ngram index\n", encoding="utf-8")

    lifecycle_columns = ["stage", "parser", "status"]
    lifecycle_rows = [
        {"stage": "validate_sessions", "parser": "all", "status": "ENABLED"},
        {"stage": "reset_database", "parser": "all", "status": "DROPPED"},
        {"stage": "validate_index", "parser": "ngram", "status": "PRESENT"},
        {"stage": "validate_rows_after_ngram", "parser": "all", "status": "2303643"},
        {"stage": "drop_index", "parser": "ngram", "status": "DROPPED"},
        {"stage": "validate_deletion", "parser": "ngram", "status": "ABSENT"},
        {"stage": "validate_index", "parser": "gojieba", "status": "PRESENT"},
        {"stage": "validate_rows_after_gojieba", "parser": "all", "status": "2303643"},
    ]
    write_tsv(result / "index_lifecycle.tsv", lifecycle_columns, lifecycle_rows)

    index_columns = [
        "engine", "parser", "scale", "database", "table", "index", "rows",
        "duration_seconds", "status", "index_type", "position_free",
        "ddl_duration_seconds", "ready_wait_seconds", "ready_probe_count",
    ]
    index_rows = []
    summary_rows = []
    summary_columns = [
        "run_id", "engine", "parser", "scenario", "query_mode", "database",
        "table", "top_k", "concurrency", "query_count", "query_sha256",
        "start", "end", "wall_seconds", "success", "errors", "actual_qps",
        "p50_ms", "p75_ms", "p90_ms", "p99_ms", "cpu_samples",
        "memory_samples", "avg_cpu_pct", "max_cpu_pct", "avg_rss_gib",
        "max_rss_gib", "client_exit_status", "result", "client_log",
        "resource_log", "index_type", "position_free", "profiled",
        "profile_status", "profile_dir",
    ]
    for parser_index, parser in enumerate(history.PARSERS):
        parser_root = result / parser / "mo"
        packs_root = parser_root / "query-packs"
        packs_root.mkdir(parents=True)
        query_packs = {}
        for scenario_index, scenario in enumerate(history.SCENARIOS):
            pack = packs_root / f"{scenario}.txt"
            pack_bytes = f"select '{parser}/{scenario}';\n".encode("utf-8")
            pack.write_bytes(pack_bytes)
            query_hash = hashlib.sha256(pack_bytes).hexdigest()
            query_packs[scenario] = {
                "path": f"/data3/old/results/fulltext-parser-regression/{parser}/mo/query-packs/{scenario}.txt",
                "query_count": 1,
                "sha256": query_hash,
            }
            (parser_root / f"mo_preflight_{scenario}_plan.txt").write_text(
                "Node: fulltext2_search\n", encoding="utf-8"
            )
            client_log = parser_root / f"{parser}_{scenario}.log"
            resource_log = parser_root / f"{parser}_{scenario}_resource.log"
            client_log.write_text("client evidence\n", encoding="utf-8")
            resource_log.write_text("resource evidence\n", encoding="utf-8")
            minute = parser_index * 10 + scenario_index
            summary_rows.append(
                {
                    "run_id": f"mo_{parser}_{scenario}",
                    "engine": "mo",
                    "parser": parser,
                    "scenario": scenario,
                    "query_mode": history.QUERY_MODES[scenario],
                    "database": "fulltext_parser_regression_230w",
                    "table": "documents_230w",
                    "top_k": "100",
                    "concurrency": "10",
                    "query_count": "1",
                    "query_sha256": query_hash,
                    "start": f"2026-08-19 23:{minute:02d}:00",
                    "end": f"2026-08-19 23:{minute:02d}:01",
                    "wall_seconds": "1",
                    "success": "10",
                    "errors": "0",
                    "actual_qps": "10.0",
                    "p50_ms": "1.0",
                    "p75_ms": "2.0",
                    "p90_ms": "3.0",
                    "p99_ms": "4.0",
                    "cpu_samples": "1",
                    "memory_samples": "1",
                    "avg_cpu_pct": "100.0",
                    "max_cpu_pct": "110.0",
                    "avg_rss_gib": "40.0",
                    "max_rss_gib": "41.0",
                    "client_exit_status": "0",
                    "result": "SUCCEED",
                    "client_log": f"/data3/old/results/fulltext-parser-regression/{parser}/mo/{client_log.name}",
                    "resource_log": f"/data3/old/results/fulltext-parser-regression/{parser}/mo/{resource_log.name}",
                    "index_type": "fulltext2",
                    "position_free": "false",
                    "profiled": "false",
                    "profile_status": "DISABLED",
                    "profile_dir": "",
                }
            )
        index_name = f"documents_230w_fts_fulltext2_{parser}"
        manifest = {
            "schema_version": 2,
            "index_type": "fulltext2",
            "position_free": False,
            "parser": parser,
            "matrixone_commit": MATRIXONE_COMMIT,
            "mo_load_commit": MO_LOAD_COMMIT,
            "mo_auto_test_commit": AUTO_TEST_COMMIT,
            "data_rows": 2303643,
            "data_sha256": DATA_HASH,
            "database": "fulltext_parser_regression_230w",
            "table": "documents_230w",
            "index_name": index_name,
            "index_ddl": f"CREATE FULLTEXT2 INDEX {index_name}",
            "explain_marker": "fulltext2_search",
            "session_variables": history.SESSION_VARIABLES,
            "profile": {"enabled": False},
            "query_packs": query_packs,
        }
        (parser_root / "manifest.json").write_text(
            json.dumps(manifest, sort_keys=True), encoding="utf-8"
        )
        index_rows.append(
            {
                "engine": "mo",
                "parser": parser,
                "scale": "230w",
                "database": "fulltext_parser_regression_230w",
                "table": "documents_230w",
                "index": index_name,
                "rows": "2303643",
                "duration_seconds": "10.5",
                "status": "READY",
                "index_type": "fulltext2",
                "position_free": "false",
                "ddl_duration_seconds": "9.5",
                "ready_wait_seconds": "1.0",
                "ready_probe_count": "1",
            }
        )
    write_tsv(result / "index_build.tsv", index_columns, index_rows)
    write_tsv(result / "summary.tsv", summary_columns, summary_rows)
    return SimpleNamespace(
        artifact_root=artifact,
        artifact_name=artifact_name,
        action_id=action_id,
        run_attempt=attempt,
        run_url=f"https://github.com/matrixorigin/mo-auto-test/actions/runs/{action_id}",
        release_safe="true",
        mode="backfill" if action_id == history.BACKFILL_ACTION_ID else "nightly",
        config=None,
        dry_run=True,
    )


class FulltextHistoryParserTest(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def prepare(self) -> dict[str, object]:
        return history.prepare_payload(build_fixture(self.root))

    def test_valid_artifact_is_exact_1_2_10_and_utc(self) -> None:
        payload = self.prepare()
        self.assertEqual(len(payload["index_builds"]), 2)
        self.assertEqual(len(payload["scenario_metrics"]), 10)
        self.assertEqual(str(payload["run"]["started_at_utc"]), "2026-08-19 14:53:03")
        self.assertEqual(str(payload["scenario_metrics"][0]["started_at_utc"]), "2026-08-19 15:14:00")
        self.assertEqual(len(payload["run"]["canonical_payload_hash"]), 64)
        self.assertNotIn(MATRIXONE_COMMIT, payload["run"]["performance_contract_json"])

    def test_run_timezone_accepts_fractional_positive_and_negative_offsets(self) -> None:
        positive, _ = history.parse_run_timezone("2026-08-19T22:53:03.123456+08:00")
        negative, _ = history.parse_run_timezone("2026-08-19T06:53:03-08:00")
        self.assertEqual(str(positive), "2026-08-19 14:53:03.123456")
        self.assertEqual(str(negative), "2026-08-19 14:53:03")

    def test_run_timezone_rejects_missing_or_invalid_offset(self) -> None:
        for value in (
            "2026-08-19T22:53:03",
            "2026-08-19T22:53:03Z",
            "2026-08-19T22:53:03+24:00",
            "2026-08-19T22:53:03+12:60",
        ):
            with self.subTest(value=value), self.assertRaises(history.HistoryError):
                history.parse_run_timezone(value)

    def test_verifier_reads_relocated_artifact_not_live_host_path(self) -> None:
        args = build_fixture(self.root)
        manifest_path = args.artifact_root / "slot-a/results/fulltext-parser-regression/ngram/mo/manifest.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        outside_root = self.root / "mutable-host"
        outside_root.mkdir()
        outside = outside_root / "natural_short.txt"
        outside.write_text("different live-host bytes\n", encoding="utf-8")
        manifest["query_packs"]["natural_short"]["path"] = str(outside)
        manifest_path.write_text(json.dumps(manifest, sort_keys=True), encoding="utf-8")
        payload = history.prepare_payload(args)
        self.assertEqual(len(payload["scenario_metrics"]), 10)

    def test_missing_parser_is_rejected(self) -> None:
        args = build_fixture(self.root)
        shutil.rmtree(args.artifact_root / "slot-a/results/fulltext-parser-regression/gojieba")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_missing_scenario_is_rejected(self) -> None:
        args = build_fixture(self.root)
        summary = args.artifact_root / "slot-a/results/fulltext-parser-regression/summary.tsv"
        lines = summary.read_text(encoding="utf-8").splitlines()
        summary.write_text("\n".join(lines[:-1]) + "\n", encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_query_hash_mismatch_is_rejected(self) -> None:
        args = build_fixture(self.root)
        summary = args.artifact_root / "slot-a/results/fulltext-parser-regression/summary.tsv"
        text = summary.read_text(encoding="utf-8")
        lines = text.splitlines()
        fields = lines[1].split("\t")
        fields[10] = "a" * 64
        lines[1] = "\t".join(fields)
        summary.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_error_count_is_rejected(self) -> None:
        args = build_fixture(self.root)
        summary = args.artifact_root / "slot-a/results/fulltext-parser-regression/summary.tsv"
        text = summary.read_text(encoding="utf-8")
        summary.write_text(text.replace("\t10\t0\t10.0\t", "\t10\t1\t10.0\t", 1), encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_non_finite_metric_is_rejected(self) -> None:
        args = build_fixture(self.root)
        summary = args.artifact_root / "slot-a/results/fulltext-parser-regression/summary.tsv"
        text = summary.read_text(encoding="utf-8")
        summary.write_text(text.replace("\t10.0\t1.0\t", "\tNaN\t1.0\t", 1), encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_missing_metric_column_is_rejected(self) -> None:
        args = build_fixture(self.root)
        summary = args.artifact_root / "slot-a/results/fulltext-parser-regression/summary.tsv"
        lines = summary.read_text(encoding="utf-8").splitlines()
        header = lines[0].split("\t")
        position = header.index("actual_qps")
        lines = ["\t".join(row[:position] + row[position + 1 :]) for row in (line.split("\t") for line in lines)]
        summary.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_wrong_plan_is_rejected(self) -> None:
        args = build_fixture(self.root)
        plan = args.artifact_root / "slot-a/results/fulltext-parser-regression/ngram/mo/mo_preflight_natural_short_plan.txt"
        plan.write_text("table_scan\n", encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_client_failure_is_rejected(self) -> None:
        args = build_fixture(self.root)
        summary = args.artifact_root / "slot-a/results/fulltext-parser-regression/summary.tsv"
        text = summary.read_text(encoding="utf-8")
        summary.write_text(text.replace("\t0\tSUCCEED\t", "\t1\tSUCCEED\t", 1), encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_incomplete_lifecycle_is_rejected(self) -> None:
        args = build_fixture(self.root)
        lifecycle = args.artifact_root / "slot-a/results/fulltext-parser-regression/index_lifecycle.tsv"
        lines = lifecycle.read_text(encoding="utf-8").splitlines()
        lifecycle.write_text("\n".join(lines[:-1]) + "\n", encoding="utf-8")
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_release_unsafe_is_rejected(self) -> None:
        args = build_fixture(self.root)
        args.release_safe = "false"
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_run_attempt_mismatch_is_rejected(self) -> None:
        args = build_fixture(self.root)
        args.run_attempt = 2
        with self.assertRaisesRegex(
            history.HistoryError,
            "artifact name differs from the Actions run identity",
        ):
            history.prepare_payload(args)

    def test_backfill_is_restricted_to_verified_run(self) -> None:
        args = build_fixture(self.root, action_id=32253479591)
        args.mode = "backfill"
        with self.assertRaises(history.HistoryError):
            history.prepare_payload(args)

    def test_transient_failure_retries_three_times(self) -> None:
        payload = self.prepare()
        connection = object()
        connector = mock.Mock(side_effect=[
            pymysql.err.OperationalError(2003, "temporary"),
            pymysql.err.OperationalError(2013, "temporary"),
            connection,
        ])
        with mock.patch.object(history, "publish_once", return_value="PASS") as publish:
            result = history.publish_with_retry({}, payload, connector=connector, sleeper=lambda _: None)
        self.assertEqual(result, "PASS")
        self.assertEqual(connector.call_count, 3)
        publish.assert_called_once_with(connection, payload)

    def test_transient_failure_stops_after_three_attempts(self) -> None:
        payload = self.prepare()
        connector = mock.Mock(side_effect=pymysql.err.OperationalError(2003, "temporary"))
        with self.assertRaises(pymysql.err.OperationalError):
            history.publish_with_retry({}, payload, connector=connector, sleeper=lambda _: None)
        self.assertEqual(connector.call_count, 3)

    def test_database_name_is_fail_closed(self) -> None:
        config = self.root / "config.yml"
        config.write_text(
            "DBInfo:\n  host: example.invalid\n  port: 3306\n  user: tester\n"
            "  password: secret-value\n  database: mobenbase\n",
            encoding="utf-8",
        )
        with self.assertRaises(history.HistoryError):
            history.load_database_config(config)


class FulltextHistoryMySQL57Test(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        host = os.environ.get("FULLTEXT_HISTORY_MYSQL57_HOST")
        if not host:
            raise unittest.SkipTest("FULLTEXT_HISTORY_MYSQL57_HOST is not configured")
        cls.connection_args = {
            "host": host,
            "port": int(os.environ.get("FULLTEXT_HISTORY_MYSQL57_PORT", "3306")),
            "user": "root",
            "password": os.environ.get("FULLTEXT_HISTORY_MYSQL57_PASSWORD", "history-test"),
            "charset": "utf8mb4",
            "autocommit": True,
        }
        admin = pymysql.connect(**cls.connection_args)
        with admin.cursor() as cursor:
            cursor.execute("CREATE DATABASE IF NOT EXISTS test_nightly CHARACTER SET utf8mb4")
        admin.close()
        cls.db_config = dict(cls.connection_args, database="test_nightly")
        migration = (history.REPOSITORY_ROOT / "result/sql/FulltextHistory.sql").read_text(encoding="utf-8")
        statements = [statement.strip() for statement in migration.split(";") if statement.strip()]
        for _ in range(2):
            connection = pymysql.connect(**cls.db_config)
            with connection.cursor() as cursor:
                for statement in statements:
                    cursor.execute(statement)
            connection.close()

    def setUp(self) -> None:
        connection = pymysql.connect(**self.db_config)
        with connection.cursor() as cursor:
            cursor.execute("DELETE FROM FulltextScenarioMetric")
            cursor.execute("DELETE FROM FulltextIndexBuild")
            cursor.execute("DELETE FROM FulltextRun")
        connection.close()
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)
        self.payload = history.prepare_payload(build_fixture(self.root))

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def connect(self) -> object:
        return pymysql.connect(**dict(self.db_config, autocommit=False))

    def test_transaction_and_duplicate_noop(self) -> None:
        connection = self.connect()
        self.assertEqual(history.publish_once(connection, self.payload), "PASS")
        connection.close()
        connection = self.connect()
        self.assertEqual(history.publish_once(connection, self.payload), "NOOP")
        connection.close()

    def test_conflicting_payload_is_rejected(self) -> None:
        connection = self.connect()
        history.publish_once(connection, self.payload)
        connection.close()
        conflicting = copy.deepcopy(self.payload)
        conflicting["run"]["canonical_payload_hash"] = "f" * 64
        connection = self.connect()
        with self.assertRaises(history.HistoryError):
            history.publish_once(connection, conflicting)
        connection.close()

    def test_partial_insert_is_rolled_back(self) -> None:
        broken = copy.deepcopy(self.payload)
        broken["index_builds"][0]["parser"] = None
        connection = self.connect()
        with self.assertRaises(pymysql.MySQLError):
            history.publish_once(connection, broken)
        connection.close()
        connection = self.connect()
        with connection.cursor() as cursor:
            cursor.execute("SELECT COUNT(*) FROM FulltextRun")
            self.assertEqual(cursor.fetchone()[0], 0)
        connection.close()


if __name__ == "__main__":
    unittest.main(verbosity=2)
