#!/usr/bin/env python3

import importlib.util
import os
import tempfile
from pathlib import Path
from unittest import mock


module_path = Path(__file__).resolve().parents[1] / "test_backup_tpcc.py"
payload_path = Path(__file__).resolve().parent / "run_compat_backup_payload.sh"
spec = importlib.util.spec_from_file_location("test_backup_tpcc", module_path)
backup = importlib.util.module_from_spec(spec)
spec.loader.exec_module(backup)

payload = payload_path.read_text(encoding="utf-8")
driver_source = module_path.read_text(encoding="utf-8")
payload_lines = set(payload.splitlines())
assert "parser.add_argument('--lifecycle_controller', type=str, required=True" in driver_source
assert '--lifecycle_controller "$BM129_REGRESSION_SOURCE/script/129/compat_mo_control.sh"' in payload
assert "warmup=300" in payload
assert "interval=120" in payload
assert "incremental_count=3" in payload
assert "warmup=30" not in payload_lines
assert "interval=20" not in payload_lines
assert "incremental_count=1" not in payload_lines
for expected in (
    "  -e 's/^warehouses=.*/warehouses=100/' \\",
    "  -e 's/^terminals=.*/terminals=100/' \\",
    "  -e 's/^runTxnsPerTerminal=.*/runTxnsPerTerminal=0/' \\",
    "  -e 's/^runMins=.*/runMins=30/' \\",
    "grep -Fxq 'runMins=30' \"$tpcc_dir/props.mo\"",
):
    assert expected in payload


def counts(value="10"):
    return {table: value for table in backup.TPCC_TABLES}


source = counts()
restored = counts()
restored["bmsql_history"] = "8"
restored["bmsql_oorder"] = "9"
restored["bmsql_new_order"] = "7"
restored["bmsql_order_line"] = "9"

assert backup.validate_nonempty_counts(source, "complete")
missing = counts()
del missing["bmsql_stock"]
assert not backup.validate_nonempty_counts(missing, "missing")
zero = counts()
zero["bmsql_item"] = "0"
assert not backup.validate_nonempty_counts(zero, "zero")

# Online writer tables may differ from the final backup snapshot. Static data
# must still be exact.
assert backup.validate_matching_counts(
    source, restored, backup.STATIC_TPCC_TABLES, "static"
)
static_mismatch = dict(restored)
static_mismatch["bmsql_stock"] = "11"
assert not backup.validate_matching_counts(
    source, static_mismatch, backup.STATIC_TPCC_TABLES, "static mismatch"
)

# First restore and merge restore are from the same final backup chain.
merge = dict(restored)
assert backup.validate_matching_counts(restored, merge, backup.TPCC_TABLES, "merge")
merge["bmsql_order_line"] = "8"
assert not backup.validate_matching_counts(
    restored, merge, backup.TPCC_TABLES, "merge mismatch"
)

activity_before = counts()
activity_after = counts()
activity_after["bmsql_history"] = "11"
assert backup.validate_writer_activity(activity_before, activity_after)
assert not backup.validate_writer_activity(activity_before, counts())

# The host TPCC checkout is shared across phases. Only the known error-log
# prefix is removed before restored-MO verification; unrelated inputs survive.
with tempfile.TemporaryDirectory() as tpcc_root:
    original_tpcc_dir = backup.TPCC_DIR
    backup.TPCC_DIR = tpcc_root
    stale = Path(tpcc_root, "benchmarksql-error.log")
    rotated = Path(tpcc_root, "benchmarksql-error.log.previous")
    unrelated = Path(tpcc_root, "props.mo")
    stale.write_text("old failure\n", encoding="utf-8")
    rotated.write_text("older failure\n", encoding="utf-8")
    unrelated.write_text("input\n", encoding="utf-8")
    assert backup.clear_tpcc_error_logs()
    assert not stale.exists()
    assert not rotated.exists()
    assert unrelated.read_text(encoding="utf-8") == "input\n"

    # Preflight all candidates before deleting any: a matching special node
    # fails closed and preserves the ordinary log beside it.
    stale.write_text("must survive failed preflight\n", encoding="utf-8")
    fifo = Path(tpcc_root, "benchmarksql-error.log.fifo")
    os.mkfifo(fifo)
    assert not backup.clear_tpcc_error_logs()
    assert stale.read_text(encoding="utf-8") == "must survive failed preflight\n"
    assert fifo.exists()
    fifo.unlink()
    stale.unlink()

    # A fresh error created after cleanup is deliberately not swept: emulate
    # runVerify observing it and prove the current verification still fails.
    current = Path(tpcc_root, "benchmarksql-error.log")

    class FakeVerifyProcess:
        pid = 12345

        def __init__(self, *_args, **_kwargs):
            assert not current.exists()
            current.write_text("current failure\n", encoding="utf-8")

        def poll(self):
            return None

        def wait(self, timeout=None):
            return 0

    original_work_dir = backup.MO_WORK_DIR
    backup.MO_WORK_DIR = tpcc_root
    with (
        mock.patch.object(backup.subprocess, "Popen", FakeVerifyProcess),
        mock.patch.object(backup.time, "sleep"),
        mock.patch.object(backup.os, "killpg"),
        mock.patch.object(
            backup,
            "run_cmd",
            side_effect=lambda *_args, **_kwargs: (
                (1, "", "current benchmark error")
                if current.exists()
                else (0, "", "")
            ),
        ),
    ):
        assert not backup.run_tpcc_verify(1)
    assert current.exists()
    backup.MO_WORK_DIR = original_work_dir
    backup.TPCC_DIR = original_tpcc_dir

print("Backup legacy-online oracle harness passed.")
