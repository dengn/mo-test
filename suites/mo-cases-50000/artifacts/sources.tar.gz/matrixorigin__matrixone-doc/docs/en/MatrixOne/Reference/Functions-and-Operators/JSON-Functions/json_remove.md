---
title: "JSON_REMOVE()"
doc_type: reference
mysql_compat: full
differs_from_mysql: []
mo_only: false
since: v4.2.0
last_updated: 2026-08-26
llms_summary: "JSON_REMOVE(json, path...) removes one or more values at the specified JSON paths and returns the resulting document."
---

# JSON_REMOVE()

> JSON_REMOVE(json, path...) removes the values located at one or more JSON paths and returns the resulting document, leaving the original unchanged when a path does not exist.

## Description

`JSON_REMOVE(json, path [, path] ...)` removes data from a JSON document at the specified paths and returns the remaining document. When multiple paths are supplied, they are processed left to right.

If a path does not exist in the document, it is ignored and no error is raised. If the document or a path argument is `NULL`, the result is `NULL`.

## Syntax

```text
JSON_REMOVE(json, path [, path] ...)
```

## Arguments

| Argument | Description |
| --- | --- |
| `json` | The JSON document to modify. |
| `path` | One or more JSON path expressions identifying values to remove. |

## Return Value

Returns the JSON document with the specified values removed.

## Examples

```sql
DROP DATABASE IF EXISTS json_remove_demo;
CREATE DATABASE json_remove_demo;
USE json_remove_demo;

SELECT JSON_REMOVE('{"a":1,"b":2}', '$.a') AS removed_a;
SELECT JSON_REMOVE('["a", ["b", "c"], "d"]', '$[1]') AS removed_index_1;
SELECT JSON_REMOVE('{"a":1,"b":2,"c":3}', '$.a', '$.c') AS removed_two;

CREATE TABLE json_remove_users (id INT PRIMARY KEY, info JSON);
INSERT INTO json_remove_users (id, info) VALUES
    (1, '{"name":"Alice","age":30,"email":"alice@example.com"}');
UPDATE json_remove_users SET info = JSON_REMOVE(info, '$.email') WHERE id = 1;
SELECT * FROM json_remove_users ORDER BY id;

DROP DATABASE json_remove_demo;
```
