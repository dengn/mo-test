---
title: "JSON_PRETTY()"
doc_type: reference
mysql_compat: full
differs_from_mysql: []
mo_only: []
since: v4.1.0
last_updated: 2026-07-13
llms_summary: "JSON_PRETTY() prints a JSON value with indentation and newlines for human readability, or returns NULL if the argument is NULL."
---
# **JSON_PRETTY()**

> JSON_PRETTY() formats a JSON value with indentation and newlines to produce a more human-readable representation. It handles objects, arrays, scalars, and nested structures.

## Description

`JSON_PRETTY()` takes a JSON document and returns a pretty-printed string version. The output uses 4-space indentation for nested objects and arrays. Scalar values (numbers, strings, booleans, null) are printed without extra whitespace.

If the argument is `NULL`, the function returns `NULL`.

## Syntax

```
> JSON_PRETTY(json_val)
```

## Arguments

|  Arguments   | Description  |
|  ----  | ----  |
| json_val | Required. A JSON value (string, JSON column, or result of a JSON function). |

## Examples

```sql
DROP DATABASE IF EXISTS dbfuncs;
CREATE DATABASE dbfuncs;
USE dbfuncs;

-- Scalar values
SELECT JSON_PRETTY('123');
SELECT JSON_PRETTY('"hello"');
SELECT JSON_PRETTY('true');
SELECT JSON_PRETTY('null');

-- Arrays
SELECT JSON_PRETTY('[1,3,5]');
SELECT JSON_PRETTY('[]');
SELECT JSON_PRETTY('[1]');

-- Objects
SELECT JSON_PRETTY('{"a":"10","b":"15","x":"25"}');
SELECT JSON_PRETTY('{}');
SELECT JSON_PRETTY('{"key":"value"}');

-- NULL input
SELECT JSON_PRETTY(NULL);

-- Via JSON functions
SELECT JSON_PRETTY(JSON_ARRAY(1, 2, 3));
SELECT JSON_PRETTY(JSON_OBJECT('a', 1, 'b', 2));

-- Table usage
CREATE TABLE t1 (a VARCHAR(200));
INSERT INTO t1 VALUES ('[1,2,3]'), ('{"a":1}'), ('"hello"'), (NULL);
SELECT JSON_PRETTY(a) FROM t1;

DROP TABLE t1;
DROP DATABASE dbfuncs;
```
