---
title: "l2_distance_sq()"
doc_type: reference
mysql_compat: mo_only
differs_from_mysql: []
mo_only:
  - "Vector type and related distance/norm/clustering functions are MatrixOne extensions (compat doc: Data Types — \"MatrixOne supports vector types\")."
since: unknown
last_updated: 2026-10-10
llms_summary: "The l2_distance_sq() function returns the squared Euclidean distance between two vectors."
---
# **l2_distance_sq()**

> The `l2_distance_sq()` function returns the squared Euclidean distance between two vectors.

## **Function Description**

`l2_distance_sq()` returns the sum of the squared differences between corresponding elements of two vectors:

```
l2_distance_sq(a, b) = sum((a[i] - b[i])^2)
```

The result preserves the ordering of `l2_distance()` without calculating a square root, and can be used as a vector distance in nearest-neighbor queries.

## **Function syntax**

```
> SELECT l2_distance_sq(vector1, vector2) AS distance FROM table_name;
```

## **Examples**

<!-- validator-ignore-exec -->
```sql
create table vec_table(a int, b vecf32(3), c vecf64(3));
insert into vec_table values(1, "[1,2,3]", "[4,5,6]");
mysql> select l2_distance_sq(b, c) from vec_table;
+------------------------+
| l2_distance_sq(b, c)   |
+------------------------+
|                     27 |
+------------------------+
1 row in set (0.00 sec)
```

## **Restrictions**

The two input vectors must have the same dimension.
