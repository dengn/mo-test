---
title: "JSON_MERGE_PATCH()"
doc_type: reference
mysql_compat: full
differs_from_mysql: []
mo_only: false
since: v4.2.0
last_updated: 2026-08-26
llms_summary: "JSON_MERGE_PATCH(doc...) merges JSON documents per RFC 7396, where null values delete members and later objects overwrite earlier ones."
---

# JSON_MERGE_PATCH()

> JSON_MERGE_PATCH(doc...) merges two or more JSON documents following RFC 7396 semantics, in which a null value deletes a member and later objects overwrite earlier values.

## Description

`JSON_MERGE_PATCH(json [, json] ...)` merges the input documents from left to right using RFC 7396 merge-patch semantics:

- Object members from later documents replace earlier members with the same key.
- A member with a `null` value in a later document removes the corresponding member.
- Arrays and scalar values are replaced wholesale rather than combined.

This differs from `JSON_MERGE_PRESERVE()`, which combines duplicate keys and array elements instead of overwriting them.

## Syntax

```text
JSON_MERGE_PATCH(json [, json] ...)
```

## Arguments

| Argument | Description |
| --- | --- |
| `json` | Two or more JSON documents to merge. |

## Return Value

Returns the merged JSON document.

## Examples

```sql
DROP DATABASE IF EXISTS json_merge_patch_demo;
CREATE DATABASE json_merge_patch_demo;
USE json_merge_patch_demo;

SELECT JSON_MERGE_PATCH('{"a":1,"b":2}', '{"b":3,"c":4}') AS patched;
SELECT JSON_MERGE_PATCH('{"a":1,"b":2}', '{"b":null}') AS deleted_b;
SELECT JSON_MERGE_PATCH('{"a":{"x":1}}', '{"a":{"y":2}}') AS nested_patch;

DROP DATABASE json_merge_patch_demo;
```
