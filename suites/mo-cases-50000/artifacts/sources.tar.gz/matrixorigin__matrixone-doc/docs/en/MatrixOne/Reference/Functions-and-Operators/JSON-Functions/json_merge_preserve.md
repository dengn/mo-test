---
title: "JSON_MERGE_PRESERVE()"
doc_type: reference
mysql_compat: full
differs_from_mysql: []
mo_only: false
since: v4.2.0
last_updated: 2026-08-26
llms_summary: "JSON_MERGE_PRESERVE(doc...) merges JSON documents by preserving duplicate keys and array elements into combined arrays."
---

# JSON_MERGE_PRESERVE()

> JSON_MERGE_PRESERVE(doc...) merges two or more JSON documents by preserving duplicate keys and combining array elements, unlike JSON_MERGE_PATCH() which overwrites and deletes members.

## Description

`JSON_MERGE_PRESERVE(json [, json] ...)` merges the input documents from left to right while preserving all values:

- Object members with the same key are combined into an array of values.
- Arrays are concatenated.
- Scalar values that cannot be merged are combined into an array.

This is the MySQL-compatible merge behavior. Use `JSON_MERGE_PATCH()` when you want RFC 7396 overwrite-and-delete semantics instead.

## Syntax

```text
JSON_MERGE_PRESERVE(json [, json] ...)
```

## Arguments

| Argument | Description |
| --- | --- |
| `json` | Two or more JSON documents to merge. |

## Return Value

Returns the merged JSON document.

## Examples

```sql
DROP DATABASE IF EXISTS json_merge_preserve_demo;
CREATE DATABASE json_merge_preserve_demo;
USE json_merge_preserve_demo;

SELECT JSON_MERGE_PRESERVE('{"a":1,"b":2}', '{"a":3,"c":4}') AS merged;
SELECT JSON_MERGE_PRESERVE('[1,2]', '[true,false]') AS array_merge;
SELECT JSON_MERGE_PRESERVE('{"a":{"x":1}}', '{"a":{"y":2}}') AS nested_merge;

DROP DATABASE json_merge_preserve_demo;
```
