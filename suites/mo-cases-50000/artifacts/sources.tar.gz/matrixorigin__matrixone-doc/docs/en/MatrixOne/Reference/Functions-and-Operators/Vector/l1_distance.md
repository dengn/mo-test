---
title: "l1_distance()"
doc_type: reference
mysql_compat: mo_only
differs_from_mysql: []
mo_only:
  - "Vector type and related distance/norm/clustering functions are MatrixOne extensions (compat doc: Data Types — \"MatrixOne supports vector types\")."
since: unknown
last_updated: 2026-10-10
llms_summary: "The l1_distance() function returns the Manhattan distance between two vectors."
---
# **l1_distance()**

> The `l1_distance()` function returns the Manhattan distance between two vectors.

## **Function Description**

`l1_distance()` returns the sum of the absolute differences between corresponding elements of two vectors:

```
l1_distance(a, b) = sum(abs(a[i] - b[i]))
```

## **Function syntax**

```
> SELECT l1_distance(vector1, vector2) AS distance FROM table_name;
```

## **Examples**

<!-- validator-ignore-exec -->
```sql
create table vec_table(a int, b vecf32(3), c vecf64(3));
insert into vec_table values(1, "[1,2,3]", "[4,5,6]");
mysql> select l1_distance(b, c) from vec_table;
+-------------------+
| l1_distance(b, c) |
+-------------------+
|                 9 |
+-------------------+
1 row in set (0.00 sec)
```

## **Restrictions**

The two input vectors must have the same dimension.
