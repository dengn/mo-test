---
title: "ST_Disjoint()"
doc_type: reference
mysql_compat: partial
differs_from_mysql: ["Geodetic relationship predicates for SRID 4326 are not supported."]
mo_only: false
since: v4.0.0-rc3
last_updated: 2026-07-10
llms_summary: "Returns whether two geometries do not intersect."
---

# ST_Disjoint()

> Returns `1` when two geometries share no point.

## Syntax

```sql
ST_Disjoint(geom1, geom2)
```

Aliases: none.

## Arguments

`geom1` and `geom2` are `GEOMETRY` values.

## Return Value

Returns `BOOL`.

## Usage Notes

- `ST_Disjoint()` is the logical opposite of `ST_Intersects()` for the same pair.
- Both geometries must have the same SRID. Predicates are Cartesian (SRID 0), not geodetic SRID 4326 predicates.

## Examples

```sql
DROP DATABASE IF EXISTS geo_disjoint_demo;
CREATE DATABASE geo_disjoint_demo;
USE geo_disjoint_demo;

SELECT ST_Disjoint(ST_GeomFromText('POINT(0 0)'), ST_GeomFromText('POINT(5 5)')) AS points_disjoint;

DROP DATABASE geo_disjoint_demo;
```

## See Also

`ST_Intersects()`, `ST_Touches()`.
