---
title: "JSON_OVERLAPS()"
doc_type: reference
mysql_compat: full
differs_from_mysql: []
mo_only: false
since: v4.2.0
last_updated: 2026-08-26
llms_summary: "JSON_OVERLAPS(a, b) compares two JSON documents and returns 1 if they have any key-value pair or array element in common."
---

# JSON_OVERLAPS()

> JSON_OVERLAPS(a, b) compares two JSON documents and returns 1 when they share at least one key-value pair or array element, following MySQL's top-level overlap semantics.

## Description

`JSON_OVERLAPS(a, b)` returns `1` if the two JSON documents overlap, and `0` otherwise:

- Two arrays overlap if they share at least one common element.
- Two objects overlap if they share at least one common key-value pair.
- A scalar overlaps with an array if the scalar is equal to one of the array's elements; otherwise two scalars overlap only when they are equal.

Native SQL scalars (such as a bare integer or boolean) are not JSON documents and are rejected at binding; pass them as JSON strings or cast values instead.

## Syntax

```text
JSON_OVERLAPS(a, b)
```

## Arguments

| Argument | Description |
| --- | --- |
| `a` | The first JSON document (or JSON-compatible string). |
| `b` | The second JSON document (or JSON-compatible string). |

## Return Value

Returns `1` if the documents overlap and `0` otherwise. Returns `NULL` if either argument is `NULL`.

## Examples

```sql
DROP DATABASE IF EXISTS json_overlaps_demo;
CREATE DATABASE json_overlaps_demo;
USE json_overlaps_demo;

SELECT JSON_OVERLAPS('[1,3,5,7]', '[2,5,7]') AS overlap;
SELECT JSON_OVERLAPS('{"a":1,"d":10}', '{"d":10,"x":1}') AS obj_overlap;
SELECT JSON_OVERLAPS('true', 'false') AS scalar_overlap;

DROP DATABASE json_overlaps_demo;
```
