---
title: "JSON_TYPE()"
doc_type: reference
mysql_compat: full
differs_from_mysql: []
mo_only: []
since: v4.1.0
last_updated: 2026-07-13
llms_summary: "JSON_TYPE() returns a string indicating the type of a JSON value: OBJECT, ARRAY, INTEGER, DOUBLE, STRING, BOOLEAN, NULL, DATE, TIME, DATETIME, or BLOB."
---
# **JSON_TYPE()**

> JSON_TYPE() returns a string indicating the type of a JSON value. Possible return values include OBJECT, ARRAY, INTEGER, DOUBLE, STRING, BOOLEAN, NULL, DATE, TIME, DATETIME, and BLOB.

## Description

`JSON_TYPE()` inspects a JSON value and returns its type as a string. The function can distinguish JSON values that originate from typed SQL scalars, such as `DATE`, `TIME`, `DATETIME`, and `BLOB` (from `BINARY`/`VARBINARY`).

Type mapping:

| JSON value | Returned type |
|  ----  | ----  |
| JSON object | `OBJECT` |
| JSON array | `ARRAY` |
| JSON true/false | `BOOLEAN` |
| JSON null | `NULL` |
| Integer number | `INTEGER` |
| Floating-point or decimal number | `DOUBLE` |
| String | `STRING` |
| Typed DATE scalar | `DATE` |
| Typed TIME scalar | `TIME` |
| Typed DATETIME scalar | `DATETIME` |
| Typed BINARY/VARBINARY scalar | `BLOB` |

If the argument is `NULL`, the function returns `NULL`.

## Syntax

```
> JSON_TYPE(json_val)
```

## Arguments

|  Arguments   | Description  |
|  ----  | ----  |
| json_val | Required. A JSON value (string, JSON column, or result of a JSON function). |

## Examples

```sql
DROP DATABASE IF EXISTS dbfuncs;
CREATE DATABASE dbfuncs;
USE dbfuncs;

-- Basic JSON types
SELECT JSON_TYPE('{"a": 1}');
SELECT JSON_TYPE('[1, 2, 3]');
SELECT JSON_TYPE('42');
SELECT JSON_TYPE('3.14');
SELECT JSON_TYPE('"hello"');
SELECT JSON_TYPE('true');
SELECT JSON_TYPE('false');
SELECT JSON_TYPE('null');
SELECT JSON_TYPE(NULL);

-- Via JSON functions
SELECT JSON_TYPE(JSON_ARRAY(1, 2, 3));
SELECT JSON_TYPE(JSON_OBJECT('id', 1, 'name', 'carrot'));

-- Typed scalars via JSON_ARRAY + JSON_EXTRACT
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(CAST(3.14 AS DECIMAL(10,2))), '$[0]'));
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(CAST('2021-02-01' AS DATE)), '$[0]'));
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(CAST('11:11:11' AS TIME)), '$[0]'));
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(CAST('2021-02-01 11:11:11' AS DATETIME)), '$[0]'));
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(CAST('hello' AS BINARY(10))), '$[0]'));

-- Table-based example with all types
CREATE TABLE jtt (
    id INT,
    b BOOL, bi BIGINT, f FLOAT, d DOUBLE,
    d64 DECIMAL(10, 3), d128 DECIMAL(30, 10),
    c1 CHAR(1), vc VARCHAR(100), t TEXT,
    bin BINARY(10), vbin VARBINARY,
    td DATE, tt TIME, tdt DATETIME,
    ts TIMESTAMP, yr YEAR, uid UUID, js JSON,
    vf32 VECF32(3), e ENUM('a', 'b', 'c'), bitcol BIT
);
INSERT INTO jtt VALUES
(1, true, 11111111111111, 0.1, 0.2222222, 3.14, 3.14159265359,
 'a', 'vvvv', 'tttttttt',
 CAST('hello' AS BINARY(10)), CAST('world' AS VARBINARY),
 '2021-02-01', '11:11:11', '2021-02-01 11:11:11', '2022-01-01 01:02:03',
 2021,
 '550e8400-e29b-41d4-a716-446655440000',
 '{"a": 1, "b": [1, 2, 3], "c": {"d": "hello"}}',
 CAST('[1.0,2.0,3.0]' AS VECF32(3)), 'a', CAST(0 AS BIT))
;

-- JSON_TYPE on JSON column
SELECT id, JSON_TYPE(js) FROM jtt;

-- Typed scalars via JSON_ARRAY + JSON_EXTRACT for table columns
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(bi), '$[0]')) FROM jtt WHERE bi IS NOT NULL;
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(td), '$[0]')) FROM jtt WHERE td IS NOT NULL;
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(ts), '$[0]')) FROM jtt WHERE ts IS NOT NULL;
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(uid), '$[0]')) FROM jtt WHERE uid IS NOT NULL;
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(bin), '$[0]')) FROM jtt WHERE bin IS NOT NULL;
SELECT JSON_TYPE(JSON_EXTRACT(JSON_ARRAY(vbin), '$[0]')) FROM jtt WHERE vbin IS NOT NULL;

DROP TABLE jtt;
DROP DATABASE dbfuncs;
```
