---
title: "MBRDisjoint"
doc_type: reference
mysql_compat: partial
differs_from_mysql: []
mo_only: false
since: v4.0.0-rc3
last_updated: 2026-07-10
llms_summary: "Tests whether two geometry minimum bounding rectangles are disjoint."
---

# MBRDisjoint

## TL;DR

`MBRDisjoint` returns whether two geometry minimum bounding rectangles do not intersect.

## Syntax

```sql
MBRDisjoint(geom1, geom2)
```

## Arguments

`geom1` and `geom2` are `GEOMETRY` values.

## Return Value

Returns `BOOL`.

## Usage Notes

The comparison is based on minimum bounding rectangles, which can intersect even when the full geometries do not.

## Examples

```sql
DROP DATABASE IF EXISTS geo_mbrdisjoint_demo;
CREATE DATABASE geo_mbrdisjoint_demo;
USE geo_mbrdisjoint_demo;

SELECT MBRDisjoint(ST_GeomFromText('POLYGON((0 0,10 0,10 10,0 10,0 0))'), ST_GeomFromText('POLYGON((20 20,30 20,30 30,20 30,20 20))')) AS disjoint_mbr;

DROP DATABASE geo_mbrdisjoint_demo;
```

## See Also

[`MBRIntersects`](mbr-intersects.md), [`ST_Disjoint`](st-disjoint.md)
