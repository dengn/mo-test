# **Comparison Functions and Operators Overview**

| Name | Description|
|---|-----|
| [>](greater-than.md) | Greater than operator |
| [>=](greater-than-or-equal.md) | Greater than or equal operator |
| [<](less-than.md) | Less than operator |
| [<>,!=](not-equal.md) | Not equal operator |
| [<=](less-than-or-equal.md) | Less than or equal operator |
| [=](assign-equal.md) | Equal operator|
| [<=>](null-safe-equal.md) | NULL-safe equal operator|
| [BETWEEN ... AND ...](between.md) | Whether a value is within a range of values |
| [COALESCE](coalesce.md)|Return the first non-null value in a list|
| [GREATEST](function_greatest.md) | Return the largest value from a list |
| [IN()](in.md) | Whether a value is within a set of values |
| [IS](is.md) | Test a value against a boolean |
| [IS NOT](is-not.md) | Test a value against a boolean |
| [IS NOT NULL](is-not-null.md) | NOT NULL value test |
| [IS NULL](is-null.md) | NULL value test |
| [ISNULL](function_isnull.md) | NULL value test |
| [INTERVAL](function_interval.md) | Return the index of the largest threshold that is less than or equal to a value |
| [LIKE](like.md) | Simple pattern matching |
| [ILIKE](ilike.md) | Simple pattern matching. Same as LIKE. But it is not case sensitive. |
| [NOT BETWEEN ... AND ...](not-between.md) | Whether a value is not within a range of values |
| [NOT IN](not-in.md) | shorthand for multiple `XOR` conditions. |
| [LEAST](function_least.md) | Return the smallest value |
| [NOT LIKE](not-like.md) | Negation of simple pattern matching |

Comparison operations result in a value of `TRUE`, `FALSE`, or `NULL`. These operations work for both numbers and strings. Strings are automatically converted to numbers and numbers to strings as necessary.

The following relational comparison operators can be used to compare not only scalar operands, but row operands:

```
=  >  <  >=  <=  <>  !=
```

```{toctree}
:maxdepth: 2
:titlesonly:
:hidden:

> <greater-than>
>= <greater-than-or-equal>
< <less-than>
<>,!= <not-equal>
<= <less-than-or-equal>
= <assign-equal>
BETWEEN ... AND ... <between>
IN <in>
IS <is>
IS NOT <is-not>
IS NOT NULL <is-not-null>
IS NULL <is-null>
ILIKE <ilike>
ISNULL <function_isnull>
LIKE <like>
NOT BETWEEN ... AND ... <not-between>
NOT IN <not-in>
NOT LIKE <not-like>
COALESCE <coalesce>
Function_Interval <function_interval>

Function_Greatest <function_greatest>

Function_Least <function_least>

Function_Strcmp <function_strcmp>

Null Safe Equal <null-safe-equal>
```
