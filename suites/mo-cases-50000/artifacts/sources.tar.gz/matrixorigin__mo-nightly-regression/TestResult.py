from flask import Flask
from flask import render_template
from flask_bootstrap import Bootstrap
import pymysql

app = Flask(__name__)
bootstrap = Bootstrap(app)

host = '127.0.0.1'  # 数据库ip地址（本机地址）
user = 'root'  # 数据库用户
password = 'Welcome1!'  # 数据库连接密码
db = 'mobenbase'  # 数据库的名称

@app.route('/sysbench')
def sysbench():
    sql = "SELECT caseN,vuser,rt_max,rt_min,rt_avg,tps,qps,success,error,commit_id,DATE_FORMAT(starttime, '%Y-%m-%d') FROM SysbenchIndex where datediff(now(),starttime) < 3"
    conn = pymysql.connect(host=host, user=user, password=password, db=db, charset='utf8')
    cur = conn.cursor()
    cur.execute(sql)
    u = cur.fetchall()
    conn.close()
    return render_template('Sysbenchindex.html', u=u)


@app.route('/ssb')
def ssbTest():
    sql = "SELECT caseN,q1_1,q1_2,q1_3,q2_1,q2_2,q2_3,q3_1,q3_2,q3_3,q3_4,q4_1,q4_2,q4_3,commit_id,DATE_FORMAT(starttime, '%Y-%m-%d') FROM SSBIndex where datediff(now(),starttime) < 3"
    conn = pymysql.connect(host=host, user=user, password=password, db=db, charset='utf8')
    cur = conn.cursor()
    cur.execute(sql)
    u = cur.fetchall()
    conn.close()
    return render_template('SSBindex.html', u=u)


@app.route('/tpch')
def tpchTest():
    sql = "SELECT caseN,q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12,q13,q14,q15,q16,q17,q18,q19,q20,q21,q22,commit_id,DATE_FORMAT(starttime, '%Y-%m-%d') FROM TPCHIndex where datediff(now(),starttime) < 3"
    conn = pymysql.connect(host=host, user=user, password=password, db=db, charset='utf8')
    cur = conn.cursor()
    cur.execute(sql)
    u = cur.fetchall()
    conn.close()
    return render_template('TPCHindex.html', u=u)


@app.route('/tpcc')
def tpccTest():
    sql = "SELECT loadWarehouses,runWarehouses,TpmC,TpmTOTAL,commit_id,DATE_FORMAT(starttime, '%Y-%m-%d') FROM TPCCIndex where datediff(now(),starttime) < 3"
    conn = pymysql.connect(host=host, user=user, password=password, db=db, charset='utf8')
    cur = conn.cursor()
    cur.execute(sql)
    u = cur.fetchall()
    conn.close()
    return render_template('TPCCindex.html', u=u)


@app.route('/loaddata')
def loaddata():
    sql = "SELECT caseN,cost,commit_id,DATE_FORMAT(starttime, '%Y-%m-%d') FROM LoadDataIndex where datediff(now(),starttime) < 3"
    conn = pymysql.connect(host=host, user=user, password=password, db=db, charset='utf8')
    cur = conn.cursor()
    cur.execute(sql)
    u = cur.fetchall()
    conn.close()
    return render_template('LoaddataIndex.html', u=u)


if __name__ == '__main__':
    app.run(host="127.0.0.1", port=5002, debug=True)