# MatrixOne Nightly Regression

This repository contains MatrixOne nightly regression Workflows and their test
assets.

The read-only test fact inventory is documented in
[test-control/README.md](test-control/README.md). Start with either:

- [History Canary Snapshot](test-control/views/history-summary.md) — first formal,
  version-pinned MatrixOne/MinIO canary and its evidence dispositions;
- [Test Control Facts Refresh runs](https://github.com/matrixorigin/mo-nightly-regression/actions/workflows/test-control-refresh.yml) — choose the newest green default-branch Run for the complete Actions Dashboard; routine viewing does not require downloading the Artifact, while red partial/compact Runs remain diagnostic;
- [Checked-in Actions Dashboard baseline](test-control/views/actions-report.md) — the same validated report shape embedded in a successful Refresh Run;
- [Checked-in Global Summary baseline](test-control/views/global-summary.md) — reviewable, reproducible fallback that may be stale.

The checked-in views are:

- [History Canary Snapshot](test-control/views/history-summary.md)
- [Global Summary](test-control/views/global-summary.md)
- [Actions Dashboard](test-control/views/actions-report.md)
- [Test Portfolio](test-control/views/test-portfolio.md)
- [Recent Scheduled Runs](test-control/views/recent-runs.md)
- [Environment and Data](test-control/views/environment-and-data.md)
