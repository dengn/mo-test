# Vector returned-row and ordering checks

This focused follow-up extends the existing Wiki audit and MOTR P0 scenario.
The scope was approved in the user review: no new benchmark, large dataset,
workflow, query round, snapshot service, or MatrixOne kernel change.

## Missing proof and retained coverage

Wiki `l2_only` currently verifies sampled row identity but not returned order.
Its timed SELECT does not project distance. After the timed modes finish, read
the sampled base vectors, independently compute float32 L2, and check the
**original** result order. Do not sort the observations before checking them.
Accept ties and the existing scale/dimension-aware numeric tolerance. Compare
all earlier/later pairs (at most 45 at K=10), so several small adjacent
inversions cannot hide one larger inversion.

Label this `identity+order`, not returned-score verification or global Top-K
completeness. Filtered modes retain `identity+distance`. This does not establish
independent GT provenance, ANN recall correctness for unobserved queries, or
equivalence of every valid tied ANN result.

The existing P0 UPDATE moves row 4 out of its original Top-K. Keep that test:
it proves the old neighbor position is gone. Add a query near the new vector
`[4,0]`, using `[4.25,0]`, to return row 4 and verify its updated payload,
business version, embedding, and nonzero distance `0.25`. Compare against the
fixed inserted/updated values, not a second MO query used as the whole oracle.
Also check the inserted and post-delete returned rows. Assert that the actual
expanded SELECT uses a physical IVF index operator. This is autocommit DML
coverage, not a claim of full MVCC or snapshot-isolation verification.

## Ownership, cost, and delivery

- The Wiki base is a case-owned immutable logical fixture from query execution
  through the audit. Existing Family and Warm adapters already run the audit
  before cleanup. Merge may reorganize storage, but no case may update these
  rows between sampling and audit. Arbitrary concurrent writers are outside
  this contract; they would require separate snapshot-aware validation.
- Keep five sampled queries per mode/round and two formal rounds. The two
  only modes add at most 200 sampled row observations at K=10. Reuse base-row
  lookups by composite `(file_id,id)` across samples/modes, execute serially,
  and retain existing SQL and outer deadlines (default 300s, maximum 900s).
- Row count bounds do not bound physical vector-block reads/decompression.
  Report lookup/compute-phase duration and actual lookup count (diagnostic
  only, excluding input parsing and connection setup); a small local fixture
  does not certify the incremental cost on the 10M dataset.
- Extend the existing source-hash-fenced MOTR adapter and its expected output.
  The immutable tool manifest already includes that patch/installer and the
  Wiki audit/report code. No new baseline schema or capability registry.
- Update both audit consumers with the producer. Historical `identity-only`
  evidence remains readable under its old scope; it is insufficient for the
  new only-mode contract. Preserve observations, but do not admit incomplete
  or failed audits into a healthy performance baseline.

## Verification and boundaries

| Closure | Minimal evidence |
| --- | --- |
| Wiki ordering | Sorted/nonzero distances pass; inversions fail; ties/tolerance pass; cumulative inversions fail |
| Lookup and failure paths | Cross-mode cache reuse; missing/malformed vectors, SQL errors and timeout fail closed |
| P0 returned rows | Exact row count, new version, fields, embedding and distance; wrong fields/stale values fail |
| Actual index route | Expanded projection succeeds through IVF; plain-scan/query-text-only plans fail |
| Delivery | Immutable MOTR source/golden fences; idempotent installation and branch variants; existing wrapper and fingerprint tests |
| Consumers | New audit accepted, old scope not upgraded, degraded samples retain metrics, Warm selected-case support |

Use real small SQL fixtures for new projections and vector decoding, including
cleanup and same-instance rerun. Do not replace negative oracle tests with a
green Daily. Conversely, small local success is not a new multi-CN 10M
performance acceptance. Independent whole-GT verification and expanded
distributed #28943 row oracles remain separate work.
