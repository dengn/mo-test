# Wiki Vector Quality Gate — design review record

Date: 2026-09-17. Scope: PR #1696 as a complete cross-component feature.
Design: [v1](2026-09-17-wiki-vector-quality-gate-design.md).
Revision identity: the immutable commit containing these two documents, linked
from PR #1696; implementation reviewed for contract mapping is
`c47c711679080c27161f6488e333b550d4824d0d`, with merge-base
`2988fe729617f8f3635470378c841ac133a70c7d`.

## Phase and decision

This is an **author-side design assessment**, separate from implementation
approval. It does not impersonate an independent GitHub reviewer or backdate
design-first approval. The earlier
[review](https://github.com/matrixorigin/mo-nightly-regression/pull/1696#issuecomment-5715651903)
correctly identified a missing mandatory artifact, not a proven runtime defect.

Trigger: over 500 non-generated production/configuration lines, external
producer/consumer protocol changes, and persisted baseline eligibility across
Runner, Parser, Checker, Family publisher and Test Control. The #1691 design
excludes this quality-policy extension, so a PR-body summary is insufficient.

Initial author assessment: **PASS for the proposed bounded design**, with the
explicit limitations below. That documentation-only submission did not claim
external approval or resume implementation work while the design gate was paused.

### Subsequent review and targeted compatibility fix

[Design v1 was accepted](https://github.com/matrixorigin/mo-nightly-regression/pull/1696#issuecomment-5716530710)
at `a3a290f52958e2a84af6789bbf47d1a19487f2b1`. The following
[implementation review](https://github.com/matrixorigin/mo-nightly-regression/pull/1696#issuecomment-5716588679)
found one P2: unconditional six-mode legacy inventory rejected valid selected-mode
binary-search runs. It established no further blocker and retained the accepted
design limitations. Design approval and implementation approval remain distinct.

The focused fix derives expected legacy inventory from the existing selector,
passes that resolved workflow value to Checker, and preserves `all`/GPU/Family
completeness and per-present-mode quality quarantine. A CLI-level counterexample
failed for single/subset selections before the fix and passed afterward. The
same test runs the real Checker quality path with fake DB/log I/O and verifies
quarantine when selected quality fails, including when another mode is missing.
The updated design paragraph documents this compatibility clarification, not a
new quality policy or publication protocol. Final implementation approval awaits
review of the fix and its CI.

Targeted post-fix validation: 108 Python tests passed (15 Wiki quality tests,
including the real pinned evaluator and ten CLI selection scenarios; 73 Family
publisher; 13 result parser/validator; seven existing vector-policy tests).
Workflow delivery is asserted in the Wiki suite. Actionlint diagnostics for the
changed legacy workflow were identical before/after; no new diagnostic, not a
claim that this legacy file is globally lint-clean. `git diff --check` passed.
No workload, report database or cluster was started for this selector fix.

## Review decisions

| Concern from review | Design closure / accepted tradeoff |
| --- | --- |
| Producer through baseline, including unhappy paths | Sections 2–4 name each owner, summary/receipt binding, all-round checks, candidate commit point and separate legacy failure boundary. |
| Units and insufficient history | Section 3 fixes Wiki fractions and absolute 0.05 drop. Building samples are relative-baseline candidates, not absolute-quality or stable-performance claims. |
| GT semantics | `input_checked` checks structure/identity only. Independent GT provenance, payload correctness and l2_only distance recomputation are not claimed. |
| Historical rows and reruns | Section 4 isolates new Family series, excludes the current action and replaces same-action Family results atomically. No old row is retroactively certified. |
| Failed quarantine | Family failures remain private/ineligible; failed discard is covered by existing TTL repair. Legacy write-before-check is explicitly weaker: failed quarantine is a job error requiring scoped recovery, not a successful exclusion. No new legacy publication subsystem is proposed. |
| Compatibility | Family and Warm share the adapter; legacy CPU/GPU producers are pinned/enabled with their strict consumers. Other vector policies remain unchanged. GPU live behavior is not inferred from offline tests. |
| Ownership, bounds and rollback | Section 5 states exact pre/post hashes, maintainer ownership, manifest inputs, per-query and per-round bounds, unchanged outer deadlines and coordinated rollback. |
| Alternatives / cost | Section 6 rejects publisher-only checking and an extra exact-query campaign; keeps a version-fenced adapter instead of a service/fork platform. Timed checks have nonzero cost, hence series separation. |

Design acceptance specifically includes the documented legacy non-atomic
quarantine limitation and absence of an absolute Recall floor. A reviewer who
requires either guarantee should request a scoped design change; neither is
silently represented as already implemented. Nightly maintainers own report-DB
recovery, and Vector maintainers own future GT/minimum-Recall policy decisions.

Q1: no new cluster/SQL resources; temporary snapshots and candidate rows reuse
existing owners. Q2: fixed query work under unchanged finite round/job/DB bounds;
timeout is incomplete evidence. Q3: no per-query persisted row or new queue;
20 failure samples per round, fixed six-mode formal plan, existing candidate TTL.
Input memory remains proportional to the pinned input, not arbitrarily bounded
for attacker-supplied files. No new credentials, privileges or tenant routing.

## Evidence reuse and limits

| Evidence | Revision / result / what it proves |
| --- | --- |
| [Linux contracts](https://github.com/matrixorigin/mo-nightly-regression/actions/runs/35227195913/job/105221699618) | `c47c7116`, SUCCESS. Offline Runner/consumer contracts, not product throughput. |
| [Test Control Inventory](https://github.com/matrixorigin/mo-nightly-regression/actions/runs/35227195428/job/105221688950) | `c47c7116`, SUCCESS. Workflow/inventory compatibility. |
| Post-merge local validation | `c47c7116`: 287 Python tests (194 TKE, 13 result, 7 generic vector policy, 73 Test Control); six Linux shell harnesses; active-workflow actionlint and Test Control graph passed. |
| [Live six-mode acceptance](https://github.com/matrixorigin/mo-nightly-regression/actions/runs/35204196542/job/105164310358) | PR runtime scripts pinned to `8169eaaac29211a2c57d0613819c2d44213abff5`; all six modes, two rounds each, N=10,000; 12 complete receipts with zero query/connection errors. |
| [Performance publication](https://github.com/matrixorigin/mo-nightly-regression/actions/runs/35204196542/job/105179587116) | 12 QPS/Recall metrics recorded in the isolated debug series; `degraded` workload and `BASELINE_BUILDING`, not production baseline seeds or a performance-regression pass. |
| [Resource health](https://github.com/matrixorigin/mo-nightly-regression/actions/runs/35204196542/job/105179586983) / [cleanup](https://github.com/matrixorigin/mo-nightly-regression/actions/runs/35204196542/job/105179773516) | Successful resource check and exact cleanup for that acceptance run. |
| Artifact replay after merge | Same live six-mode artifacts accepted by `c47c7116` publisher `--validate-only`; no DB writes or cluster run. |

Live orchestration commit was `5dc04d8428e2fccd5b6e0e74138c1e417aa59da6` on
the temporary acceptance branch, with explicit runtime script checkouts above.
MO was Main `76e1a9bd9f75480ee76f686c43994f938a15a8d5`, not a 4.2 full campaign.
The native adapter, shared row checks, installer, Family IVF runner and parser
production inputs remain unchanged between that tested PR revision and
`c47c7116`; merged publisher behavior was replayed and tested locally/CI.

Documentation-only changes do not invalidate these semantic inputs. Reuse does
not prove a live legacy CPU/GPU campaign, independent GT correctness, #28943
consistency coverage, all-4.2 correctness or long-term baseline stability.

At this design submission, main advanced to `0453a3314f774151de6397c158f6ee4cb26042a8`
via #1702, adding the independent ANLI consistency case. That case is outside
this acceptance run; do not claim it was executed here. Integration review after
design acceptance must use the then-current base, rather than treating the
recorded merge-base as eternally current.

## Next review action

Design acceptance is now recorded above. Re-review the selected-mode correction
and its focused validation before implementation approval. No additional load
test is required to prove this selector/Checker boundary. The earlier live run
remains evidence for the unchanged native query and Family admission paths,
not evidence that selected-mode legacy checking had already worked.
