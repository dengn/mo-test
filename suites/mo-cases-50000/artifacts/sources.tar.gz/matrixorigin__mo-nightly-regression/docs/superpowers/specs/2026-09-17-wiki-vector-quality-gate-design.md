# Wiki Vector Quality Gate — v1

Date: 2026-09-17. Owner: PR #1696 author and Nightly/Vector maintainers.
Tracking: [PR #1696](https://github.com/matrixorigin/mo-nightly-regression/pull/1696),
[design review request](https://github.com/matrixorigin/mo-nightly-regression/pull/1696#issuecomment-5715651903).
Status: [v1 accepted at a3a290f5](https://github.com/matrixorigin/mo-nightly-regression/pull/1696#issuecomment-5716530710);
the selector clarification below addresses the subsequent implementation review.
See the separate
[design review record](2026-09-17-wiki-vector-quality-gate-design-review.md).
Implementation reference: `c47c711679080c27161f6488e333b550d4824d0d`.

This is a retrospective design submission, not a claim that approval preceded
the implementation. Implementation approval remains paused until the reviewer
accepts the exact version linked from the PR (v1 acceptance is linked above).
Design acceptance does not imply implementation or merge approval. This document extends, rather than
replaces, the [publication finalization design](2026-09-16-tke-family-performance-publication-finalization-design.md).
It owns the new quality policy and producer/consumer contract that design excludes.

## 1. Problem, scope and invariants

The same Wiki history/current Recall values could fail the legacy Checker but
pass Family's generic relative performance rule. A QPS summary also did not prove
that every query completed correctly. Checking only the last round hid earlier
errors. This proposal checks the existing workload, without additional queries,
loads, services, report tables or MatrixOne kernel changes.

Scope: Wiki 10M six modes (`l2_only`, `l2_filter`, `l2_filter_threshold`, each
`pre`/`post`), the shared Family/Warm adapter, legacy CPU/GPU Wiki producers,
Parser, Checker, Family publisher and existing Test Control receipt consumer.
Other ANN cases retain their existing policies, including QPS-only cases.

Invariants:

1. Missing/malformed evidence, query errors and a failed earlier formal round
   must not become a successful quality result because the final QPS is present.
2. Both formal rounds are checked; published performance remains the second
   round. No best-of selection or extra warm-up/repeatability campaign is added.
3. Family baseline admission requires valid producer evidence, the quality and
   performance gates, and the existing healthy-workload contract. Failed metrics
   remain observable without becoming healthy history.
4. Input validation is not independent GT certification or an absolute Recall
   guarantee. Historical comparison is not proof of correctness of every SQL row.
5. Producer and consumer revisions must be delivered together. An unknown
   evaluator version fails before queries rather than silently disabling checks.

Non-goals: a universal minimum Recall, independent recomputation of the 10M GT,
payload/transactional correctness, identical repeated ANN Top-K sets, new routing
proofs, and the separate #28943 multi-CN consistency workload. That workload is
owned by #1695/#1702, not by this six-mode acceptance evidence.

## 2. End-to-end ownership and failure contract

```text
pinned evaluator + checked adapter
  -> input validation before timing
  -> existing SELECT + returned-row checks
  -> native summary + WIKI_QUALITY per round
  -> Runner / Parser / Test Control observations
  -> shared Wiki quality function + performance gate
  -> Family candidate quarantine/promotion OR legacy Checker quarantine
```

| Owner / consumers | Contract |
| --- | --- |
| `install_wiki_quality.py` / all Wiki producers | Verify source hash, apply the bounded patch, verify output hash, install the shared checker. Installation is idempotent; unknown content is rejected. |
| `wiki_query_quality.py` / evaluator | Validate aligned inputs, check returned rows, aggregate counters on the main thread. Workers report through existing futures; no shared mutable counter in workers. |
| `run_family_ivf_recall_full.sh` / Family and Warm | Keep bounded prepare/query/cleanup, preserve producer exit status, validate receipts. No extra SQL is introduced by the quality patch. |
| `VectorParser.py` / Processor and Family | Persist final-round numeric observations; inspect all summaries/receipts and errors. `SUCCEED` means structurally checked, not historically compared. |
| `vector_checker.py` / legacy Checker and Family publisher | One Wiki quality policy, fraction units, both-round Recall comparison. |
| Family publisher / performance DB | Admit a consistent artifact snapshot, stage privately, compare, quarantine if necessary, then promote transactionally. |
| Legacy Checker / performance DB | Check archived receipts and mark evaluated quality failures `QUALITY_FAILED`; this older two-command path is not the Family transaction protocol. |
| `test-control/evidence_v2/runner_result.py` / Test Control | Retain per-round metrics and structured query/connection failures in the existing receipt. Do not invent the later historical verdict. |

Inputs: fixed-count fvecs/ivecs and mapping/filter files. Require positive N,
`1 <= K <= 10`, consistent finite query dimensions (maximum 4096), aligned row
counts, contiguous mapping ordinals, resolvable GT IDs and nonduplicate composite
GT identities. Validate the whole input before selecting a requested common
prefix. Filtered GT must match the query's file_id. Record SHA256 for query, GT,
mapping and, when supplied, filter files. Both rounds must have equal hashes, N
and K. This checks input identity, not a cross-run GT registry.

Returned rows: no more than K; non-null, unique `(file_id,id)` pairs. Filtered
queries additionally check the existing returned file_id and distance: finite,
nonnegative, ascending within `1e-6 * max(1, abs(distance))`, and within the
threshold for threshold mode. `l2_only` selects only two IDs, so it does not get
distance checks by pretending that an unselected column exists. There is no new
base-row lookup or independent distance recomputation.

Receipt: one `WIKI_QUALITY` JSON object, `version=1`, per native summary. Fields
are `expected`, `completed`, `failed`, `connection_errors`, `empty_gt`,
`zero_recall`, `k`, `input_sha256`, `gt_status=input_checked`,
`gt_provenance=not_independently_verified`, and bounded `failure_samples`.
Consumers reject unsupported versions, invalid counters, missing input identity,
mismatched summary counts/K, and changing inputs between rounds.

| State | Required outcome |
| --- | --- |
| Every query completed; valid nonempty GT; Recall is zero | Preserve real zero. Evaluate the historical gate; do not classify as missing evidence. |
| One query has empty filtered GT and returns no rows | Count `empty_gt`, exclude it from the Recall denominator. Do not invent 100% Recall. |
| Empty GT but nonempty result; duplicate/predicate/order violation | Query-quality failure, bounded failure sample, nonzero producer result. |
| Entire round has empty GT | Insufficient retrieval evidence; cannot pass. |
| Query exception, including connection failure | Count failure; connection codes form a subset. A native summary cannot override failure. |
| Receipt/summary absent, partial, malformed or inconsistent | Reject healthy admission; preserve available raw evidence. No default `verified` status. |
| Timeout/cancellation before complete receipt | Incomplete evidence, not success. Existing outer cleanup and resource ownership remain unchanged. |
| First round fails, second passes | Case quality fails; final-round metrics do not erase the first failure. |

Family requires exactly two formal rounds and exact source inventory. The legacy
workflow's existing runner validates its two-round execution; the shared parser
binds every supplied summary to its receipt, rather than hardcoding a round
count for every consumer. A Warm diagnostic can select its supported bounded
round count, but cannot masquerade as a two-round Family performance sample.

## 3. Units, verdicts and admission

Wiki Recall is a finite **fraction in [0,1]**. The historical threshold is an
absolute **0.05 fraction = five percentage points**, not a 5% relative drop and
not the generic SIFT/GIST percentage scale. With at least three valid prior
samples, every formal round must satisfy `recall >= median(history) - 0.05`.
Performance remains final-round QPS with the existing relative 25% drop policy.
The two checks are independent; better Recall does not silently waive QPS.

`BASELINE_BUILDING` means fewer than three historical Recall samples, not proven
performance stability or absolute retrieval quality. Structurally valid samples
may build the baseline, provided Family workload health and other gates allow
admission. This avoids a permanently empty baseline. Real zero Recall is not
missing data and can therefore be a building observation; it is not certified
as acceptable customer quality. No per-mode absolute minimum is invented here.
This explicitly resolves the earlier proposal's ambiguous “no floor, no healthy
sample” wording: baseline eligibility here is relative-regression eligibility,
not an absolute-quality certification. Any future minimum needs a separate
mode/GT decision by Vector maintainers and a reviewed policy change.

Family QPS comparison also waits for three samples. Legacy QPS retains its
existing comparison against available positive history; only the Wiki quality
policy is unified. Do not describe all legacy/Family performance behavior as
identical. Test Control's earlier frozen receipt records query-time facts; the
later publisher report owns history, thresholds and baseline decisions.

## 4. Persistence, history and compatibility

**Family:** reuse the existing `VectorIndex` schema and attempt-scoped candidate
remark. Validate the admitted artifact snapshot before processing and verify the
persisted candidate inventory before final promotion. History selects the exact
accepted series, `result='SUCCEED'`, excluding the current action, with at most
three samples from independent actions per metric. Quarantine uses `PERF_FAIL`,
`CASE_FAIL` or `BOTH_FAIL`; the normal series still exposes the observations.
Raw invalid/incomplete evidence may be artifact-only: this design does not
promise a fabricated numeric database row for an unparseable report.

Promotion locks action rows, verifies the candidate inventory and atomically
replaces that action's prior final rows. Reruns of one GitHub action do not create
independent baseline samples. If comparison/quarantine/promotion fails, propagate
failure and discard only private candidate rows. Failed discard leaves an
ineligible candidate remark; existing bounded TTL repair reclaims it on a later
publication (48h default, configured range 24–168h). No new Janitor is added.

**Legacy CPU/GPU:** keep branch/case history conventions, but select the latest
successful row per prior action before limiting history. The declared primary
key `(action_id,startTime,caseN)` prevents tied latest rows for the same case.
Evaluated quality failures update only current action + case + remark to
`QUALITY_FAILED`, preserving metrics and unrelated rows. Legacy binary-search
inventory comes from `IVF_PRE_POST_FILTER_TEST_LIST`, not the observed rows:
unset or `all` requires six modes; an explicit comma-separated selection requires
exactly those modes. Reject empty/unknown selectors and unexpected results.
Missing selected modes fail inventory without skipping checks/quarantine on
present modes. GPU retains the six-mode default; formal Family inventory is
unchanged. The legacy collection step passes the same resolved selector used by
the query steps, preventing intentionally unselected modes from becoming failures.

The legacy Processor writes before Checker; therefore it has a weaker failure
boundary than Family. If quarantine cannot commit, Checker raises and the job
fails, but the database row may still say `SUCCEED`. It is **not** evidence of
completed quarantine. Nightly maintainers must recover/quarantine that exact
action/case/remark before trusting subsequent legacy comparison. This PR does
not retrofit Family's staged publication protocol into legacy workflows or
claim crash-atomic legacy baseline admission. This compatibility tradeoff is an
explicit design-review decision, not hidden by a green Case result.

No bulk migration, deletion or retroactive certification of old rows occurs.
New Family Weekly tool fingerprints start a separate series, so old unchecked
rows do not seed it. Legacy stored successful history remains a relative trend
reference under its existing branch label; it lacks the new provenance and is
not retroactively validated. Reprocessing old raw Wiki logs without receipts
cannot produce a newly checked success. Parser and producer rollout must be
coordinated, including CPU/GPU, instead of mixing an old producer with a new
strict consumer.

Warm invokes the shared adapter; it retains session image, lease, cleanup and
result contracts. K above the supplied k10 GT capacity now fails explicitly.
Do not infer Family baseline publication or independent GT certification merely
from a Warm Case pass. No GPU-native algorithm or kernel path changes here;
offline delivery checks cover the common producer, not a fresh GPU live run.

## 5. Delivery identity, cost, limits and rollback

The external tool is pinned to `heni02/vector_benchmark`
`0bae04528673d7756c4ee2478ac8e4e41f54df1b`. Its evaluator SHA256 must be
`4afb51e70e627e0d75f8c46cc2bd1e89fc92524293229b5a39e4852fb85efb0e`
before the patch and
`cefd5a7e49d525d1a8ed82e46b9b4614d02fc435f06e5f7d023e04ddf98ddb1e`
after it. Nightly maintainers own the patch, installer and shared checker until
the upstream tool adopts the contract. An upstream revision requires refreshed
hashes, real-adapter tests and producer/consumer review; no floating fork fallback.

Family's Weekly tool manifest includes both upstream SHA and `wiki-quality`, a
Git blob hash of patch + installer + shared query checker; its enclosing manifest
SHA256 participates in existing series resolution. Profile/resource/product-line
separation remains intact. This is not a hash of all publisher code or a new GT
registry: future changes to policy/inputs must deliberately maintain comparable
series identities. Main/4.2 and diagnostic/official samples must not be relabeled
into each other's history.

No extra database query, retry, dataset or cluster is introduced. Input validation
and hashing are linear in pinned file size and occur before query timing. The
mapping is streamed and only referenced GT identities are retained; queries/GT
and existing futures remain proportional to the fixed input/query count. It is
not an untrusted-file sandbox or a constant-memory streaming evaluator. Formal
N=10,000, K=10, concurrency=100 and two rounds are unchanged. Returned-row checks
are O(K) with O(K) transient state and are timed: their cost is nonzero and is a
reason for a new tool series. At most 20 failure samples per round, with query
ordinal and a reason capped at 200 characters; arbitrary DB exception text and
credentials are not copied into those samples. Counters do not grow per query.

Keep existing Family bounds: prepare 10,800s, each round 7,200s, explain 1,800s,
cleanup 600s, plus their kill grace. Outer prepare/query jobs cap at 200/240min;
they may stop an unfinished matrix, which remains incomplete, not passed.
Publication has its existing 30min job bound and 15s connect / 30s read/write DB
timeouts. This PR adds no wait loop or reset of those deadlines. Existing runner
cleanup owns SQL resources and namespace deletion; the adapter owns no new
persistent database objects. Temporary publication snapshots use existing
scoped cleanup. Credentials and permissions are unchanged.

Rollback is coordinated: revert producer pin/patch enablement, strict consumers
and manifest change together, from a clean checkout. Do not disable the checks
while continuing to label new data with the checked series. Leave observations
and quarantine markers intact; do not convert failed rows to `SUCCEED` or claim
old runs were checked. In-flight runs keep their frozen workflow/tool revisions.
No schema or cluster data rollback is required.

## 6. Alternatives and validation

| Option | Decision |
| --- | --- |
| Only add a final Recall threshold in the publisher | Reject: input/result errors and an earlier failed round remain invisible; legacy and Family can still diverge. |
| Re-run exact searches / repeat every query / build a new evidence service | Defer: changes measurement load, requires an independent oracle and much more state. Not necessary for checks on already-returned rows. |
| Modify/fork the external benchmark as a separate release | Reasonable later; repository write access is currently unavailable. A locally owned exact-hash adapter is reviewable and fails on drift without a new release service. |
| Checked adapter + shared pure policy + existing publication/receipt machinery | Select: closes the immediate contract with no extra SQL or persistence subsystem, while explicitly retaining legacy limitations. |

[ANN-Benchmarks' runner](https://github.com/erikbern/ann-benchmarks/blob/main/ann_benchmarks/runner.py)
provides precedent for rejecting duplicate candidates before recall calculation;
[VectorDBBench](https://github.com/zilliztech/VectorDBBench) provides precedent for
database-oriented filtered workloads. These are precedents, not interoperability
standards or the source of a universal Recall floor. Composite SQL identity,
receipt timing and performance-DB compatibility are local contracts defined here.

| Invariant / consumer | Cheapest discriminating proof already present |
| --- | --- |
| Input alignment, composite IDs, filter/order/threshold/K, empty vs zero GT | `script/tke/test_wiki_query_quality.py`: small deterministic fixtures and corrupt/invalid controls. |
| The actual pinned evaluator uses checks, adds no SELECT, returns errors | Same suite's `test_real_frozen_adapter_all_modes_and_error_paths`: six modes, 1/2 workers, invalid rows, connection error and empty GT. |
| Missing receipt/early-round errors cannot become a healthy parser result | `result/test_vector_parser.py`; first-round counterexamples and a clean positive control. |
| Fraction threshold, baseline building, exact inventory, failed admission | `script/tke/test_publish_family_performance.py` and Wiki quality tests; no live report DB required. |
| Quarantine scope, reruns, failed publication and temporary cleanup | Existing publisher transaction/candidate/snapshot tests; legacy exact-update test. The latter does not prove crash-atomic legacy publication. |
| Pin/fingerprint and Family/Weekly/Warm/CPU/GPU consumers | Tool-manifest and IVF shell harnesses, workflow contracts and installer/version tests. |
| Native failures survive Test Control delivery | Existing `test_runner_result.py` and `test_runner_delivery_native.py`. |
| Real two-AP six-mode execution and publication | Run 35204196542: 12 complete round receipts, 120,000 queries, no query/connection errors; resource and exact cleanup passed. |

Evidence revisions, terminal links and limits are in the separate review record.
Acceptance requires design approval plus those contracts and mandatory CI; it
does not require another load campaign for documentation-only changes. A live
debug pass validates the Runner/checker path, not all 4.2 product behavior or
long-term performance stability. No new service, background task, RFC platform
or universal minimum Recall is proposed.
