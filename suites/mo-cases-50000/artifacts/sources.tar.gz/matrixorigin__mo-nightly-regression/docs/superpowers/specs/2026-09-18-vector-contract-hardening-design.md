# Vector contract hardening — bounded design v1

Status: design reviewed before integration/delivery. The user approved the
four-part scope in this conversation: fix plan/capability oracles, propagate
ordinary DML failures, add bounded post-timing returned-data checks, and expose
the checks in existing reports. Implementation PR: linked in its delivery record.
Owner: nightly regression maintainers. Extends the September 17 Wiki quality
gate; does not replace its Recall, performance, or baseline-building policy.

## Scope and alternatives

Existing MOTR P0 and #28943 already test deterministic vector semantics and a
specific multi-CN regression. Retain them. Do not build another matrix or change
MO code, resources, scheduling, datasets, SQL shapes, rounds or concurrency.

The selected approach extends existing test oracles and runner evidence. Merely
keeping QPS/Recall misses invalid returned records and non-panic DML errors.
Recomputing full 10M ground truth daily or adding a distributed test platform
costs substantially more than the targeted missing proof. The selected bounded
checks follow ANN-Benchmarks' independent returned-neighbor distance calculation
and pgvector's combination of result and index-plan assertions.

## Contracts and ownership

1. MOTR keeps its result assertions, accepts legitimate physical IVF nodes, and
   rejects plain-scan fallback and query-text-only matches. Only explicitly
   unsupported 4.2 L1 scenarios are marked inapplicable; arbitrary query failures
   remain failures. Main retains L1 coverage. A version-fenced runner adapter
   delivers these focused upstream test fixes in one PR, records its identity,
   and refuses unknown input rather than silently weakening an oracle.
2. Existing concurrent DML keeps its workload. Non-panic execution errors,
   failed workers, incomplete shutdown and missing required work cannot become
   success. Do not invent an error allowlist. Legitimate empty sparse-filter
   results are not errors; disabled operations are not required.
3. Wiki captures at most five deterministic actual requests/results per mode
   and round. It must retain the exact query representation used by SQL and
   composite `(file_id,id)`, not a completion-order sample or a bare ID.
4. Additional base-row reads happen after all selected timed modes and before
   cleanup. They verify existence/identity and independently recompute L2 for
   modes whose original SELECT returned distance, using documented floating
   tolerance. They do not certify global Top-K completeness or missing neighbors.
   Modes without a distance projection report identity-only coverage.
5. GT remains `not_independently_verified`. ANN/tied results need not be identical
   across requests. No arbitrary absolute Recall floor is introduced.

## Bounds and failure closure

The normal six-mode/two-round plan retains at most 60 requests and 600 returned
rows at K=10. Sample count, dimension, K and serialized bytes have explicit
limits. Samples are local run-owned artifacts, not a database or global registry.
Reset only the current mode/round's evidence before reuse. Missing, malformed,
partial or stale samples cannot be interpreted as a passing audit.

The audit owns one short-lived database connection with bounded connect/read
operations and an outer timeout. Parameterize composite keys; validate any SQL
identifiers. Close the connection on success and error. Never retain credentials
in evidence. Existing job/Warm cleanup still owns the dataset on every terminal
path. No new background thread, retry service or persisted session state.

Audit success is published only after all expected samples are checked. Failure
or missing evidence makes the family fail and the performance workload degraded;
available numeric observations remain publishable but cannot seed healthy
history. Existing query receipts keep their meaning; an earlier query-completion
receipt is not retroactively claimed to prove the later audit or historical gate.
The summary separates query checks, sampled-data checks, Recall/performance, and
GT provenance rather than calling everything `WIKI_QUALITY`.

## Compatibility and delivery

The frozen vector evaluator is patched by the existing guarded installer.
Capture is opt-in at the Family/Warm wrapper; legacy CPU/GPU callers retain the
previous per-query checks without unexpectedly requiring a post-run audit.
Warm checks only its explicitly selected modes and rounds, after their timing.
All changed evaluator/checker/adapter semantics enter the tool identity so old
and new measured series are not silently mixed. Existing upstream tool SHAs stay
immutable per run. No new artifact service or performance database schema.

Rollback is a runner commit rollback. No MO state or data format migration is
introduced. A new exact tool fingerprint may warm a new baseline; this is not a
performance pass. Full TKE cost and readiness remain a later real-run acceptance
claim, not something offline harness tests can certify.

## Validation and review decision

Required negative evidence: plain scan/SQL mention cannot pass the plan check;
unknown source drift fails installation; non-panic SQL errors and incomplete
workers exit nonzero; missing/duplicate composite identities and wrong distances
fail; valid ANN variation/floating tolerance remains accepted; missing/failed
audit cannot produce healthy baseline status. Verify workflow order, single-mode
debug, Warm selected inventory, frozen upstream patch application, and unchanged
formal SQL. Use small task-owned SQL fixtures if local resources permit; never
modify existing foreign services or run the full 10M load as an offline test.

Design decision: PASS for this bounded extension. Producer/consumer publication
and query resource boundaries require R2 review plus Q1/Q2/Q3 tracing. No kernel,
distributed protocol or cluster lifecycle change is in scope. Implementation
approval requires the stated negative tests, complete diff review and explicit
reporting of any real-topology acceptance gap.

### Local implementation evidence (2026-09-18)

- Frozen upstream integration: TKE Python discovery passed 216 tests without
  skips, using vector-benchmark `0bae04528673d7756c4ee2478ac8e4e41f54df1b`
  and MOTR `ebed6c8db2f19c48a5581a136fd2915f084d0d36`.
- Result tests: 23 passed; DML/auto-update tests: 11 passed; existing Recall
  checker: 7 passed. Full Warm contracts, including failure cleanup, passed.
- CI-scoped workflow lint, error-level ShellCheck and Test Control workflow
  graph/inventory checks passed. No scheduled job or resource plan was changed.
- An isolated, task-owned local MO container executed the DML workload and
  supplied real VECF32 rows/EXPLAIN output. Nonzero distance recomputation passed;
  wrong-distance and missing-row controls failed. Temporary containers were
  removed, with no changes to foreign services or the performance database.
- This is not a distributed 10M acceptance run. No TKE job was dispatched;
  benchmark-scale cost and current remote source compatibility still require
  the later PR-branch validation run.
