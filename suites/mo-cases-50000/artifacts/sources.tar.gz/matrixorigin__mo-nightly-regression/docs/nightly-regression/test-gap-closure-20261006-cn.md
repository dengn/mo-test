# 2026-10-06：现有测试与结果采集的最小收口

目标是让已有测试及时提供可信结果、把短验证用到 PR 合入前，不扩建 Runner 或调度平台。

## 本次采集修复

Main Run `37330486167` 的六类 Product Receipt 均已上传。GitHub 对未执行的 legacy fallback Job 返回 `skipped`、`steps=[]`，时间为 `15:11:02Z` 开始、`15:10:56Z` 结束；旧五秒例外拒绝了该 Run，六份包都未进入汇总。

- 明确空步骤的 skipped Job 不存在可判定的执行耗时；保留 GitHub 原时间和 `github_skipped_empty_steps_inversion`，附同源 `steps_count=0`。
- 两个时间仍必须满足现有 Run attempt 边界。实际执行 Job、cancelled、跨 attempt 与身份校验不放宽。
- 已接收的旧 receipt 不增字段，canonical bytes 和历史 facts 不变。
- 不修改产品 Case 判定，不将 skipped 记为 passed。

真实六份 ZIP 使用当前正式 `GitHubArtifactIngress → CentralIngress → ManifestImporter` 在一次性本地存储重放：全部接受，分别再次导入均不新增 facts。没有替换校验常量；这不等于已经补收进生产 MO/API。

提交前验证：863 项 Test Control 单测通过；build、validate、敏感扫描和当前 Workflow 图检查通过（270/270 call-site、462/462 execution）。独立审查比对旧、新实现，历史已接受输入的 canonical bytes 与事实不变，新增例外不放宽实际执行 Job。

部署遵循既有流程：合并后更新实际服务工作树 `/home/mo/projects/mo-nightly-regression-main`，精确重放这六份 Artifact，再等待原 Importer 生成 Snapshot，以真实 AI API 中的 Run ID 验收。不得只凭 healthz 或对象上传成功宣布完成。

## 四步复核后的范围

| 工作 | 最小处理 | 验收边界 |
|---|---|---|
| 采集与部署 | 修上述 metadata 阻断；部署已合入版本；合并后补收已有结果 | Main 六份结果进入正式 MO、Snapshot、API |
| PR 前短验证 | 复用 MOTR prepared/sql/search；固定 Candidate 和 Runner revision，使用 owner 的隔离实例，保留失败与报告 | 人工入口真实可用；不冒称自动 CI 已接入 |
| 小 Case 补强 | 仅扩现有数值合同的 binary Prepared Decimal/DOUBLE 换型、NULL、同句柄恢复 | 独立固定答案、真实二进制参数、清理后同实例再运行 |
| IDC 客户长稳 | 复用 #1745；先一个低负载短窗口，验证首错与报送，再由 owner 决定延长 | 旧负载未协调、准入未满足时不启动 |

近期修复已有的 scale38/39 SQL 扫描，以及行列规则/save_result/result_scan 真实服务测试不复制。现有 Prepared 产品失败不通过修改 Golden 或 skip 变绿，也不未经 CI owner 决策就设成全部 PR 的强制门禁。

## IDC 当前状态与安全边界

只读核对的候选是 `mo-stb-4-2-dev-28f1f02-r36999135328-a1 / stability-regression-dis`。当前 spec 已是 `commit-6dc7031`，不能把 namespace 中的旧版本当作被测 SHA。两 CN 旧压力接近各自 14 CPU 限额，外部 Runner owner/PID 尚未确认，因此不叠加新 soak。

先协调原全文/向量负载的维护窗口，确认完整 Candidate/image、专用非 sys Account、批准的输入与表、两个保护标签。只在该稳定性环境试一窗；不创建集群、不重新 Load、不停止其他负载、不写 new-moi QA/dev/prod。

本轮不增加数据库表、服务、TKE Job、通用 Fuzzer、自动选测或根因判断。性能新序列和新版 Producer 的自然运行仍需独立观察，不由本地验证冒充。
