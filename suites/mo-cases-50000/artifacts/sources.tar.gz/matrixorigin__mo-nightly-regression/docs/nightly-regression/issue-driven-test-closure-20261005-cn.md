# 近期 Issue 驱动的最小测试补强

## 结论与范围

对 2026-09-30 至 10-05 凌晨有更新的 Issue 核查后，本轮只修实际漏执行和
少量薄弱断言，分 MOTR、Nightly 两个 PR。不是增加测试平台，也不是修 MO 内核。
基线：MOTR `5b9fc960`、Nightly `187fcbe0`；分析用 MO `21f711a7`。

| 所属 | 现有缺口 | 最小改动 | 不作的保证 |
| --- | --- | --- | --- |
| MOTR 向量矩阵 | 已关闭 #29082 的开关仍跳过整个矩阵，包括独立 IVF/DML | Main 恢复已有检查，按已接受的 cosine 输入域验证索引结果/拒绝 | 4.2 不适用 Main 新拒绝合同；不承诺任意 ANN 均 100% Recall |
| MOTR 向量缓存 | 只比数量、单一距离调用顺序 | 小数据明确 ID、反向 L2/L2² 顺序及真实算子 | 不穷举向量组合，不新 Load 10M |
| MOTR Prepared | 等值裁剪不覆盖真实 BIGINT 绑定的 OR/BETWEEN 索引范围 | 复用既有多块 fixture，检查结果、重绑和可达索引/扫描 | 不使用共享机墙钟时间作门禁，不以 INT32 代替实际客户端类型 |
| Nightly IVF 终审 | 基表、索引来自分离的 SELECT；批量自增插入无独立行标识 | 同一语句读取 active generation/基表/索引；计时后增少量显式 PK 写入哨兵 | 不是全部批量数据的完整证明，也不是持久化/跨 CN 验证 |

所有结果继续通过现有 Runner、Receipt 和 Test Control；不新增 Job、服务、常驻数据库表、
调度入口、重试层或整套环境。既有测试已经捕获的 MO 失败必须保留，不能修改 golden、
扩大 skip 或重试刷绿。新测试自身正确与被测产品通过是两项独立验收。

## 借鉴的方法，不引入框架

- [SQLite testing](https://www.sqlite.org/testing.html)：边界、错误恢复、优化开关下的
  语义保持，优先可控小数据，不复制其大型 fuzz/soak 基础设施。
- [SQLancer](https://github.com/sqlancer/sqlancer)：用独立结果或等价关系发现静默错结果；
  变换前提须真实成立，不能假设所有类型转换或 ANN 查询精确等价。
- [pgvector IVF recall tests](https://github.com/pgvector/pgvector/blob/master/test/t/003_ivfflat_vector_build_recall.pl)：
  区分参考结果、索引路径与召回，不用“索引建成”或执行成功替代判定。

## 本轮暂不增加的部分

- Decimal256 #29607/#29610 的内部边界由相关内核修复 PR 维护；不在测试仓库复制一套实现。
- 常量视图权限 #29572 仍须独立认证会话复验，留给对应修复的权限合同；本轮不混入向量/Prepared PR。
- 现有并发建索引、远端 rebuild、RPC 生命周期已有确定性测试，不另建 Nightly。
- IDC `runVerify/check.log` 结果读取仍需已有 Runner 的只读出口/权限；不假装 K8s Pod Ready
  或启动 Workflow success 就能替代后台 Oracle。此次不修改 QA/prod/Chaos 环境。
- 已合并 #1755 的 Test Control 详情分页只需部署验收，不重复实现；Issue closed 不等于
  Main、4.2 与 IDC 原场景都已验证。合入后的自然回归按实际 SHA 分开观察。

## 验证与交付

先离线验证正常/负控/边界及失败资源释放，再用本轮独占的本机小实例运行精确选择，
检查真实退出状态、golden 对照与清理。至少重复一次同实例运行，避免状态残留。
不接触其他正在运行的 MO，不额外占用 TKE；本机版本、结果与未验证范围如实记录。

自审逐项检查：现有断言未丢失；首错不被后续成功覆盖；计时不受新审计影响；同一快照
比较；最多 32 个审计 ID；错误/超时释放连接；幂等清理只作用于本 Case 对象。

### Nightly 实施边界

- 基表、active metadata generation 与索引 entries 使用同一条 `UNION ALL` SQL；
  保留重复，不用 inner join 隐藏缺行。最多 32 ID/66 返回行，触及上限即失败，
  不把被截断的数据判为一致。仍受原 120 秒预算约束。
- 现有 auto-update Driver 在所有性能计时结束后，写入 8 条显式负 PK 哨兵。
  期望向量由客户端生成；只有 commit 成功才登记。原批量自增 INSERT 的所有 ID
  仍标 `unverified`，不能声称这 8 条证明了整个批次。原测试失败不会被清理/后续成功覆盖。
- 同一语句在 Main/4.2 的整数 PK 返回类型不同，按本次选定的 PK 类型做严格适配；
  字符串 PK（包括数值外观的字符串）保持原样，不混同 `01` 和 `1`。

### 真实验证

使用本机独占 4 CPU/6 GiB 容器，串行切换 Main `5a09e1f` 与 4.2 `28f1f02`，
不把旧镜像称为当前 HEAD。小数据验证覆盖整型和字符串 PK、更新、删除、插入哨兵；
负控故意删除应存在行，即使基表与索引同时缺失也必须失败。随机测试库清理后检查零残留。
35 项聚焦 Python 测试及 ANLI phased、Family tool-manifest 两个 shell harness 通过。
两种镜像均通过真实审计的重复生命周期、missing-both 负控和 VARCHAR `01`/`1` 区分。
不以 API 200 或测试文件存在声明通过。

MOTR Main 向量实测通过；Prepared 则真实报出索引/裁剪退化，4.2 旧镜像还触发
反向区间内部 panic。测试实现可交付不等于产品已修复，后续自然 Daily 按真实 SHA
记录这些失败。不升级 QA/prod，不自动新建重复 Issue，也不扩大本轮修复范围。
