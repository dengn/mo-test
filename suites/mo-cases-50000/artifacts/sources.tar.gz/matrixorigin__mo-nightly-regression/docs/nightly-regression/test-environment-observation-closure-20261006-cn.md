# 测试环境与观测最小补齐（2026-10-06）

目标：让已有测试的结果更容易判断，减少共享环境干扰，不增加集群、产品 Case 或调度平台。

审查/开发基线：`main@83f1aa42`。本轮不修改 MO 内核，也不把现存失败自动归因成环境问题。

## 1. 本 PR 的三个改动

### 1.1 MOTR 先于 Catalog/Account 压力

同一个 Family 中采用以下顺序：

```text
既有 TP/AP + Sysbench-special 安全交接
  → MOTR
  → deterministic Concurrent / Full Concurrent
  → 后续原有流程
```

- Main online-index 仍接在 deterministic Concurrent 后，不让它反过来成为 MOTR 前置条件。
- Full Concurrent 保留 AP、IVF、Sysbench-special 原有等待边界；没有减少并发数、放宽超时或跳过压力 Case。
- MOTR Case 失败但原有 cleanup 成功，可继续后续压力测试；取消、cleanup 失败或缺少安全输出则不继续。
- 合法 debug profile 未选择 MOTR 时仍可单独执行压力测试。
- 同步现有时序验证器：有实际时间时检查压力开始不早于 MOTR 结束；未执行/缺失时间不伪造成成功。
- 换序会改变性能争用条件：Main/4.2 的 Daily、Weekly 性能序列和 overlap manifest 均升版，明确记录 `catalog-pressure=after-motr-cleanup`。新序列不复用旧争用条件的基线；历史数据保留，没有可比历史时显示 `BASELINE_BUILDING`，不能冒充性能已验证通过。core 及通用 debug 序列模板、资源版本、工具摘要和阈值不变；Weekly debug 沿用 Weekly 新版身份。

目的不是让锁问题消失，而是避免压力清理长期等待同时拖垮普通正确性测试。压力失败本身仍保留，Campaign Gate 不放宽。

边界：可能延长整套测试关键路径；MOTR 仍与部分独立尾部共享 TN/S3，这不是完全资源隔离，也不是“所有 Case 数据库已经清空”的保证。实际改善需自然运行后核对，不能凭离线测试宣称锁问题已解决。

### 1.2 write_only 补展示，不新增性能门禁

现场 Run `37215929355` 的 write_only 已执行，原报告为 `757.63 TPS`，旧报表 Parser 写入整数 `758 TPS / 4546 QPS`。缺的是发布摘要，不是数据未执行或未入库。

- 复用已有报告库，只读取当前 Run/Attempt staging series 的准确 Case/并发组合。
- 在现有 `performance-evidence` Artifact 内增加一行 `observations.tsv`，同时写 Job Summary。
- 展示 `OBSERVATION_ONLY`、`performance_verified=false`；不改变九项核心 Sysbench Gate、阈值或基线晋升。
- 缺失、重复、非法值、查询失败展示 `OBSERVATION_UNAVAILABLE`，不填零、不输出 PASS。
- all/compare 两个发布入口都覆盖；不新增 Workflow Step、Job 或数据库表。

本轮未增加 AI Context 对此 TSV 的摄取合同。当前作用是让人工/AI 通过现有报告入口看到准确观测，不声称已新增自动性能判断。

### 1.3 修复 128 结果包与真实 Runtime 清单不一致

旧接收端只允许三个二进制成员；实际 Producer 还记录 launch 配置、ONNX 库和完整 Jieba 词典，导致 `runtime digest manifest has an unexpected member`。

- 接收已发布的完整清单：历史 3/7/12、当前 8/13 成员。
- 每个成员仍核对 SHA-256；不接受任意文件、部分配置/词典、重复条目或软链接绕过。
- Receipt 与读取器使用同一白名单，历史投影保留所有成员 digest。
- 测试直接读取当前 Workflow 的 `runtime_members` 数组，再构造文件、打包和验证，避免只有简化 Fixture 通过。

没有新增 BVT、重编译或测试，修复的是结果收集兼容性。新 Producer 的线上产物仍需合并后的自然 128 运行验证。

## 2. 50 已部署的现有能力（不是本 PR 未合入代码）

- Test Control 从 `7b2ffb3e` 更新至已合并 `83f1aa42`，重启既有 Context API。
- 既有内网反向代理放行 `/v2/analysis/details`；网段限制、只读方法和限流不变。
- 固定 Snapshot `sha256:15c606e4473ec3776dda12f4f60215c8652f010ddd63e7259f54ed0efead6cad`：79 条失败详情通过两页取全；27 条性能关注通过一页取全，内网/本机响应及摘要一致。
- 上述性能页仍标 `source.complete=false`：分页只能取回已收集的内容，不能补造源 Receipt 省略的结果。
- 入口：`http://10.222.1.50:8089/v2/analysis?days=10`；按响应中 pinned drill-down 链接翻页。

原导入告警没有被清除或伪装成健康。本轮也没有手工重复启动测试来制造新证据。

## 3. IDC 客户长稳沿用 #1745，不另起 Runner

现有 PR #1745 已有默认关闭的全文/向量一致性试点。本轮仅合并最新 main、解决 Context API helper 插入冲突，保留两边能力；不改变其业务测试逻辑、不自动接管 IDC。

实际启动前仍需要环境负责人和 QA 确认：

- 允许使用的 IDC 4.2 集群及旧负载处置、保护标签、SHA/image、资源预算。
- 已有 ANLI 表、ngram/IVF L2 索引和脱敏输入。
- 专用最小权限 SQL 账号、持久任务目录和 `CUSTOMER_SOAK_*` 报送配置。

当前这些报送变量未配置，未执行真实 SQL 验收。先完成一短窗、停止/恢复及 Report → MO → API，再做长时间稳定性验证。QA/new-moi、dev、prod 不作为可任意使用的空闲资源。

现有 IDC 只读观测不能替代 TPCC `runVerify/check.log` 的产品结论；50 至对应 Runner 的只读访问被认证拒绝，未绕过权限。后续可由已有授权 Runner 导出最后一次 Checker 时间/结果/报告入口，不必新建服务。

## 4. 验证与后续

- 128：历史/当前清单 → Receipt → History Bridge，保留全部 digest；覆盖缺失、篡改、非法成员及软链接反例。
- Family：完整 DAG、19 个 Profile、失败/取消/清理安全组合、真实时序正反例；原测试失败仍使 Campaign Gate 失败。
- Publisher：当前准确 staging 身份、不可用观测、all/compare 两入口；write_only 不改门禁或基线资格。MOTR 换序采用新性能序列，并验证旧序列的样本不会被选为新基线。
- 部署：就绪检查、Snapshot 固定、详情分页、内网/本机字节一致性。

原 Head `7f9ed994` 本地验证：Test Control **861/861**（406.759s）；TKE Python **380项、6项既有跳过**；四个 shell suite、actionlint v1.7.7、shellcheck、build/validate/scan、确定性重建及 diff-check 通过。当前调用图 **270/270 call sites、462/462 executions** 唯一。检查不代替下一轮自然运行的现场验收。

Review 修复后补充验证：在相同 Profile、资源、工具摘要、固定 AP/Proxy 入口下，四条生产路径的新旧性能序列和 manifest digest 均不同；用完整旧 SSB/TPCH 样本验证新序列的历史筛选为空，初始状态为 `BASELINE_BUILDING`。TKE Python **381项、375通过、6项既有跳过**；四个 shell suite、actionlint、shellcheck、current-checkout graph、build/validate/scan、确定性重建和 diff-check 通过。Test Control 的 Python 代码及生成数据未改，复用原全量单测证据。不启动 TKE。

合并本 PR 后更新 50，并观察自然 Main/4.2/128 运行：结果包是否收到、MOTR 与压力是否按序、压力失败是否仍完整保留、总耗时增加多少。不额外启动 TKE；IDC 未准入部分不冒充已完成。
