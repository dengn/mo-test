import unittest

from result.vector_checker import evaluate_vector_case, requires_recall


class VectorRecallCheckerTests(unittest.TestCase):
    def test_recall_drop_is_reported_even_when_qps_is_healthy(self):
        current = {"qps": 1000, "recall": 72.0}
        history = [
            {"qps": 1000, "recall": 80.0},
            {"qps": 950, "recall": 81.0},
            {"qps": 1050, "recall": 79.0},
        ]

        result = evaluate_vector_case(current, history)

        self.assertTrue(result["qps_pass"])
        self.assertFalse(result["recall_pass"])
        self.assertFalse(result["passed"])
        self.assertAlmostEqual(-8.0, result["recall_delta_pp"])

    def test_qps_drop_is_reported_even_when_recall_is_healthy(self):
        current = {"qps": 700, "recall": 80.0}
        history = [
            {"qps": 1000, "recall": 80.0},
            {"qps": 980, "recall": 81.0},
            {"qps": 1020, "recall": 79.0},
        ]

        result = evaluate_vector_case(current, history)

        self.assertFalse(result["qps_pass"])
        self.assertTrue(result["recall_pass"])
        self.assertFalse(result["passed"])

    def test_invalid_or_missing_recall_fails_required_recall_check(self):
        result = evaluate_vector_case(
            {"qps": 1000, "recall": None},
            [{"qps": 1000, "recall": 80.0}],
        )

        self.assertFalse(result["recall_pass"])
        self.assertFalse(result["passed"])

    def test_old_invalid_qps_samples_do_not_become_the_baseline(self):
        result = evaluate_vector_case(
            {"qps": 1000, "recall": 80.0},
            [
                {"qps": -1, "recall": 80.0},
                {"qps": 1000, "recall": 80.0},
            ],
        )

        self.assertTrue(result["qps_pass"])
        self.assertTrue(result["recall_pass"])
        self.assertTrue(result["passed"])

    def test_qps_only_case_ignores_recall_drop(self):
        result = evaluate_vector_case(
            {"qps": 1000, "recall": 8.0},
            [{"qps": 1000, "recall": 80.0}],
            check_recall=False,
        )

        self.assertTrue(result["qps_pass"])
        self.assertTrue(result["recall_pass"])
        self.assertFalse(result["recall_checked"])
        self.assertTrue(result["passed"])

    def test_qps_only_case_still_fails_invalid_qps(self):
        result = evaluate_vector_case(
            {"qps": -1, "recall": 80.0},
            [{"qps": 1000, "recall": 80.0}],
            check_recall=False,
        )

        self.assertFalse(result["qps_pass"])
        self.assertTrue(result["recall_pass"])
        self.assertFalse(result["passed"])

    def test_only_declared_qps_only_cases_skip_recall(self):
        self.assertFalse(requires_recall("ann_sift_ivf_cosine"))
        self.assertFalse(requires_recall("ann_sift_ivf_normalize"))
        self.assertTrue(requires_recall("ann_sift_ivf"))
        self.assertTrue(requires_recall("wiki_recall_hnsw"))


if __name__ == "__main__":
    unittest.main()
