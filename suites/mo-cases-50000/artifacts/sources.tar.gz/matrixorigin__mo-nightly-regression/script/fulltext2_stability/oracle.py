#!/usr/bin/env python3
"""Independent FULLTEXT2 score-oracle contract.

The runtime never derives an oracle from FULLTEXT2, hidden tables, or EXPLAIN.  A
data owner produces the versioned JSON (optionally zstd-compressed) from the
frozen corpus and query pack.  This module only validates that immutable
artifact and compares returned ``(pk, float32 bits)`` pairs.
"""

from __future__ import annotations

import argparse
import atexit
import csv
import json
import math
import hashlib
import os
import re
import shutil
import struct
import subprocess
import sys
import tarfile
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


SCHEMA_VERSION = 2
ALGORITHM = "BM25"
K1 = 1.5
B = 0.75
TOKENIZER_MODE = "gojieba-v1.4.7-defaultmode-hmmfalse-product-ascii-split-v2"
TOKENIZER_GOLDEN_COMMIT = "94528dcb63d55921b936cda611ea61eb1862ea79"
TOKENIZER_IMPLEMENTATION = "github.com/yanyiwu/gojieba"
TOKENIZER_VERSION = "v1.4.7"
TOKENIZER_BUNDLE_FORMAT = "tar-v1"
TOKENIZER_BUNDLE_FILES = (
    "jieba.dict.utf8",
    "hmm_model.utf8",
    "user.dict.utf8",
    "idf.utf8",
    "stop_words.utf8",
)
_TOKENIZER_PROCESSES: dict[str, "_GojiebaProcess"] = {}
# Expected product vectors are taken from MatrixOne's gojieba tokenizer tests
# and pkg/monlp/tokenizer/dict/user.dict.utf8 at TOKENIZER_GOLDEN_COMMIT. They
# are checked against the extracted bundle before this oracle can produce score
# bits.
TOKENIZER_GOLDENS = (
    ("清华大学", ("清华大学",)),
    ("我来到北京", ("我", "来到", "北京")),
    ("我来到北京清华大学", ("我", "来到", "北京", "清华大学")),
    ("云计算", ("云计算",)),
    ("韩玉鉴赏", ("韩玉鉴赏",)),
    ("蓝翔", ("蓝翔",)),
    ("区块链", ("区块链",)),
    ("一万一千五百二十颗", ("一万一千五百二",)),
)


@dataclass(frozen=True)
class Pattern:
    """The small source-derived pattern tree needed by the score oracle.

    MatrixOne parses Boolean mode into TEXT/STAR, PHRASE, GROUP and the
    +/-/~/< /> wrappers, then evaluates the tree after its PLUS-JOIN rewrite.
    Keeping that tree here avoids reducing Boolean queries to an incorrect
    flat list of terms.
    """

    operator: str
    terms: tuple[str, ...] = ()
    prefix: str = ""
    children: tuple["Pattern", ...] = ()


@dataclass(frozen=True)
class QuerySpec:
    mode: str
    patterns: tuple[Pattern, ...]


def float32_bits(value: float) -> int:
    """Return the exact IEEE-754 binary32 representation used by MatrixOne."""
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise ValueError(f"score must be finite and non-negative: {value!r}")
    return struct.unpack("!I", struct.pack("!f", value))[0]


def bits_to_float(value: int) -> float:
    return struct.unpack("!f", struct.pack("!I", int(value)))[0]


def _read(path: Path) -> dict[str, Any]:
    if path.suffix == ".zst":
        proc = subprocess.run(["zstd", "-q", "-dc", str(path)], capture_output=True, check=True)
        return json.loads(proc.stdout)
    return json.loads(path.read_text())


def _require(mapping: Mapping[str, Any], key: str, kind: type | tuple[type, ...]) -> Any:
    if key not in mapping or not isinstance(mapping[key], kind):
        raise ValueError(f"score oracle field {key!r} is missing or has the wrong type")
    return mapping[key]


def _sha256(value: Any, label: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError(f"{label} must be a lowercase SHA-256")
    return value


def tokenizer_bundle_metadata(document: Mapping[str, Any]) -> dict[str, str]:
    tokenizer = _require(document, "tokenizer", dict)
    bundle_sha256 = _sha256(document.get("gojieba_bundle_sha256"), "score oracle gojieba_bundle_sha256")
    if (
        tokenizer.get("parser") != "gojieba"
        or tokenizer.get("implementation") != TOKENIZER_IMPLEMENTATION
        or tokenizer.get("version") != TOKENIZER_VERSION
        or tokenizer.get("mode") != "DefaultMode"
        or tokenizer.get("hmm") is not False
        or tokenizer.get("contract") != TOKENIZER_MODE
        or tokenizer.get("golden_commit") != TOKENIZER_GOLDEN_COMMIT
        or document["matrixone_commit"] != TOKENIZER_GOLDEN_COMMIT
        or tokenizer.get("bundle_format") != TOKENIZER_BUNDLE_FORMAT
        or tokenizer.get("bundle_sha256") != bundle_sha256
    ):
        raise ValueError("score oracle tokenizer must bind the full product gojieba bundle")
    resources = tokenizer.get("resources")
    if not isinstance(resources, dict) or set(resources) != set(TOKENIZER_BUNDLE_FILES):
        raise ValueError("score oracle tokenizer resources must contain the exact five product files")
    return {name: _sha256(resources[name], f"gojieba resource {name}") for name in TOKENIZER_BUNDLE_FILES}


def validate_document(document: Mapping[str, Any]) -> dict[str, Any]:
    if _require(document, "schema_version", int) != SCHEMA_VERSION:
        raise ValueError("unsupported score oracle schema_version")
    if _require(document, "algorithm", str) != ALGORITHM:
        raise ValueError("score oracle algorithm must be BM25")
    params = _require(document, "bm25", dict)
    if float(params.get("k1", -1)) != K1 or float(params.get("b", -1)) != B:
        raise ValueError("score oracle BM25 parameters do not match the locked contract")
    for key in ("matrixone_commit", "corpus_sha256", "query_pack_sha256", "gojieba_bundle_sha256", "oracle_epoch"):
        value = _require(document, key, str)
        if not value:
            raise ValueError(f"score oracle {key} must not be empty")
    for key in ("corpus_sha256", "query_pack_sha256", "gojieba_bundle_sha256"):
        _sha256(document[key], f"score oracle {key}")
    tokenizer_bundle_metadata(document)
    counts = _require(document, "corpus", dict)
    for key in ("doc_count", "total_doc_length"):
        if int(_require(counts, key, int)) < 0:
            raise ValueError(f"score oracle corpus.{key} must be non-negative")
    queries = _require(document, "queries", dict)
    if not queries:
        raise ValueError("score oracle must contain at least one query")
    for query_id, query in queries.items():
        if not isinstance(query_id, str) or not isinstance(query, dict):
            raise ValueError("score oracle queries must be an object keyed by query id")
        rows = _require(query, "results", list)
        limit = int(_require(query, "limit", int))
        if limit <= 0 or len(rows) > limit:
            raise ValueError(f"score oracle query {query_id} has invalid limit/results")
        seen: set[int] = set()
        scores: list[float] = []
        for row in rows:
            if not isinstance(row, dict):
                raise ValueError(f"score oracle query {query_id} contains a non-object result")
            pk = int(_require(row, "pk", int))
            bits = int(_require(row, "score_bits", int))
            if pk in seen or not 0 <= bits <= 0xFFFFFFFF:
                raise ValueError(f"score oracle query {query_id} contains duplicate/invalid result")
            seen.add(pk)
            score = bits_to_float(bits)
            if not math.isfinite(score) or score < 0:
                raise ValueError(f"score oracle query {query_id} contains invalid score bits")
            scores.append(score)
        cutoff_unique = query.get("cutoff_unique", True)
        if not isinstance(cutoff_unique, bool):
            raise ValueError(f"score oracle query {query_id} cutoff_unique must be boolean")
        if rows and not cutoff_unique:
            raise ValueError(f"query {query_id} has a tied K/K+1 cutoff; regenerate the pack")
        if any(left < right for left, right in zip(scores, scores[1:])):
            raise ValueError(f"score oracle query {query_id} is not sorted by descending score")
    reservoir = _require(document, "mutation_reservoir", list)
    if len(reservoir) < 1000:
        raise ValueError("score oracle mutation_reservoir must contain at least 1000 corpus rows")
    pks: set[int] = set()
    for row in reservoir:
        if not isinstance(row, dict):
            raise ValueError("score oracle mutation_reservoir contains a non-object row")
        pk = int(_require(row, "pk", int))
        if pk in pks:
            raise ValueError("score oracle mutation_reservoir contains duplicate PKs")
        pks.add(pk)
        if int(_require(row, "doc_length", int)) < 0:
            raise ValueError("score oracle mutation_reservoir doc_length must be non-negative")
        tokens = _require(row, "tokens", list)
        if not tokens or not all(isinstance(token, str) and token for token in tokens):
            raise ValueError("score oracle mutation_reservoir tokens must be a non-empty list of strings")
        if row.get("safe_for_mutation") is not True or not isinstance(row.get("mutation_token"), str) or not row.get("mutation_token"):
            raise ValueError("score oracle mutation_reservoir rows must be marked safe with a mutation_token")
        body_sha256 = row.get("body_sha256")
        if not isinstance(body_sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", body_sha256):
            raise ValueError("score oracle mutation_reservoir rows must bind body_sha256")
    return dict(document)


def load(path: Path) -> dict[str, Any]:
    return validate_document(_read(path))


def for_epoch(document: Mapping[str, Any], epoch: str) -> dict[str, Any] | None:
    """Resolve a data-owner-published oracle epoch without consulting FULLTEXT2.

    ``epochs`` is optional for the immutable base artifact.  When present, an
    entry may contain a complete ``queries``/``corpus`` replacement or just a
    ``queries`` replacement; all immutable binding fields remain inherited from
    the base document and are validated again before use.
    """
    entries = document.get("epochs")
    if not isinstance(entries, Mapping):
        return None
    entry = entries.get(epoch)
    if not isinstance(entry, Mapping):
        return None
    merged = dict(document)
    merged.pop("epochs", None)
    for key in ("queries", "corpus", "mutation_reservoir", "oracle_epoch"):
        if key in entry:
            merged[key] = entry[key]
    merged["oracle_epoch"] = str(entry.get("oracle_epoch", epoch))
    return validate_document(merged)


def validate_bundle_directory(directory: Path, resource_hashes: Mapping[str, str]) -> Path:
    if not directory.is_dir():
        raise ValueError(f"gojieba bundle directory is missing: {directory}")
    entries = {entry.name: entry for entry in directory.iterdir()}
    if set(entries) != set(TOKENIZER_BUNDLE_FILES):
        raise ValueError("gojieba bundle directory must contain exactly the five product resources")
    for name in TOKENIZER_BUNDLE_FILES:
        path = entries[name]
        if path.is_symlink() or not path.is_file():
            raise ValueError(f"gojieba bundle resource is not a regular file: {name}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != resource_hashes[name]:
            raise ValueError(f"gojieba bundle resource SHA-256 mismatch: {name}")
    return directory


def extract_bundle(document: Mapping[str, Any], archive: Path, destination: Path, expected_bundle_sha256: str) -> Path:
    resource_hashes = tokenizer_bundle_metadata(document)
    expected_bundle_sha256 = _sha256(expected_bundle_sha256, "gojieba bundle SHA-256")
    if expected_bundle_sha256 != document["gojieba_bundle_sha256"]:
        raise ValueError("gojieba bundle SHA-256 does not match the score-oracle binding")
    if not archive.is_file() or hashlib.sha256(archive.read_bytes()).hexdigest() != expected_bundle_sha256:
        raise ValueError("gojieba bundle archive SHA-256 mismatch")
    if destination.exists():
        return validate_bundle_directory(destination, resource_hashes)
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=f".{destination.name}.extract-", dir=destination.parent))
    try:
        with tarfile.open(archive, "r:") as bundle:
            members = bundle.getmembers()
            names = [member.name for member in members]
            if len(names) != len(TOKENIZER_BUNDLE_FILES) or set(names) != set(TOKENIZER_BUNDLE_FILES):
                raise ValueError("gojieba bundle archive must contain exactly the five root resource files")
            if any(not member.isfile() for member in members):
                raise ValueError("gojieba bundle archive contains a non-regular resource")
            for member in members:
                source = bundle.extractfile(member)
                if source is None:
                    raise ValueError(f"gojieba bundle archive cannot read {member.name}")
                with source, (stage / member.name).open("wb") as output:
                    shutil.copyfileobj(source, output)
        validate_bundle_directory(stage, resource_hashes)
        os.replace(stage, destination)
    except Exception:
        shutil.rmtree(stage, ignore_errors=True)
        raise
    return destination


def _bundle_directory(base: Mapping[str, Any]) -> Path:
    tokenizer = _require(base, "tokenizer", dict)
    configured = str(os.environ.get("FT2_GOJIEBA_BUNDLE_DIR", "") or tokenizer.get("bundle_dir", ""))
    if not configured:
        raise ValueError("FT2_GOJIEBA_BUNDLE_DIR is required for score-oracle epoch recomputation")
    return validate_bundle_directory(Path(configured), tokenizer_bundle_metadata(base))


class _GojiebaProcess:
    def __init__(self, bundle_directory: Path):
        binary = os.environ.get("FT2_GOJIEBA_TOKENIZER_BIN", "/usr/local/bin/ft2-gojieba-tokenizer")
        if not Path(binary).is_file():
            raise ValueError(f"gojieba tokenizer binary is missing: {binary}")
        self.process = subprocess.Popen(
            [binary, "--dictionary-dir", str(bundle_directory)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

    def tokenize(self, text: str) -> list[str]:
        if self.process.poll() is not None or self.process.stdin is None or self.process.stdout is None:
            raise ValueError("gojieba tokenizer process is not running")
        self.process.stdin.write(json.dumps({"text": text}, ensure_ascii=False) + "\n")
        self.process.stdin.flush()
        response = self.process.stdout.readline()
        if not response:
            raise ValueError("gojieba tokenizer process exited before returning tokens")
        value = json.loads(response)
        if not isinstance(value, dict) or value.get("error"):
            raise ValueError(f"gojieba tokenizer failed: {value.get('error', 'invalid response') if isinstance(value, dict) else value!r}")
        tokens = value.get("tokens")
        if not isinstance(tokens, list) or not all(isinstance(token, str) and token for token in tokens):
            raise ValueError("gojieba tokenizer returned invalid tokens")
        return tokens

    def close(self) -> None:
        if self.process.poll() is None:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)


def _close_tokenizer_processes() -> None:
    for process in _TOKENIZER_PROCESSES.values():
        process.close()


atexit.register(_close_tokenizer_processes)


def _gojieba_tokens(text: str, bundle_directory: Path) -> list[str]:
    key = str(bundle_directory.resolve())
    process = _TOKENIZER_PROCESSES.get(key)
    if process is None:
        process = _GojiebaProcess(bundle_directory)
        _TOKENIZER_PROCESSES[key] = process
    return process.tokenize(text)


def validate_tokenizer(document: Mapping[str, Any], bundle_directory: Path) -> Path:
    """Prove that the extracted resources preserve the locked product vectors."""
    directory = validate_bundle_directory(bundle_directory, tokenizer_bundle_metadata(document))
    process = _GojiebaProcess(directory)
    try:
        for text, expected in TOKENIZER_GOLDENS:
            actual = tuple(process.tokenize(text))
            if actual != expected:
                raise ValueError(
                    f"gojieba bundle failed product vector {text!r}: "
                    f"expected={expected!r} actual={actual!r}"
                )
    finally:
        process.close()
    return directory


def _split_boolean(text: str) -> list[str]:
    """Split Boolean patterns like ParsePatternInBooleanMode does.

    Spaces inside quoted phrases and balanced groups are part of one pattern.
    Invalid/unbalanced input is rejected as a data-contract error instead of
    silently scoring a different query.
    """
    parts: list[str] = []
    start = 0
    depth = 0
    quoted = False
    for index, char in enumerate(text):
        if char == '"':
            quoted = not quoted
        elif not quoted and char == '(':
            depth += 1
        elif not quoted and char == ')':
            depth -= 1
            if depth < 0:
                raise ValueError("Boolean query has an unmatched closing group")
        elif not quoted and char.isspace() and depth == 0:
            if start < index:
                parts.append(text[start:index])
            start = index + 1
    if quoted or depth != 0:
        raise ValueError("Boolean query has an unterminated phrase or group")
    if start < len(text):
        parts.append(text[start:])
    return parts


def _pattern_from_token(token: str, dictionary: Path) -> Pattern:
    token = token.strip()
    if not token:
        raise ValueError("Boolean query contains an empty pattern")
    if token[0] in "+-~<>":
        operator = {"+": "plus", "-": "minus", "~": "rankless", "<": "lt", ">": "gt"}[token[0]]
        return Pattern(operator, children=(_pattern_from_token(token[1:], dictionary),))
    if token.startswith("(") or token.endswith(")"):
        if not (token.startswith("(") and token.endswith(")")):
            raise ValueError("Boolean query group is not balanced")
        children = tuple(_pattern_from_token(part, dictionary) for part in _split_boolean(token[1:-1]))
        if not children:
            raise ValueError("Boolean query group is empty")
        return Pattern("group", children=children)
    if token.startswith('"') or token.endswith('"'):
        if not (token.startswith('"') and token.endswith('"')):
            raise ValueError("Boolean query phrase is not balanced")
        terms = tuple(_gojieba_tokens(token[1:-1], dictionary))
        if not terms:
            raise ValueError("Boolean query phrase is empty")
        return Pattern("phrase", terms=terms)
    if token.endswith("*"):
        prefix = token[:-1]
        if not prefix:
            raise ValueError("Boolean wildcard must have a non-empty prefix")
        return Pattern("star", prefix=prefix)
    terms = tuple(_gojieba_tokens(token, dictionary))
    if not terms:
        raise ValueError(f"Boolean query term {token!r} tokenizes to empty")
    return Pattern("text", terms=terms)


def _validate_pattern(pattern: Pattern) -> None:
    """Apply the same operator-shape restrictions as Pattern.Validate()."""
    if pattern.operator in {"plus", "minus"}:
        child = pattern.children[0]
        if child.operator in {"plus", "minus", "phrase"}:
            raise ValueError(f"{pattern.operator} cannot wrap {child.operator} in Boolean mode")
    elif pattern.operator in {"lt", "gt", "rankless"}:
        child = pattern.children[0]
        if child.operator not in {"group", "text", "star"}:
            raise ValueError(f"{pattern.operator} must wrap TEXT, STAR, or GROUP")
    elif pattern.operator == "group":
        if any(child.operator in {"plus", "minus", "phrase"} for child in pattern.children):
            raise ValueError("Boolean GROUP cannot contain +, -, or PHRASE")
    for child in pattern.children:
        _validate_pattern(child)


def _query_spec(mode: str, text: str, dictionary: Path) -> QuerySpec:
    if mode != "boolean":
        terms = tuple(_gojieba_tokens(text, dictionary))
        if not terms:
            raise ValueError(f"{mode} query tokenizes to empty")
        if mode == "natural":
            # Natural-language mode retains the product's positional phrase
            # behavior for the frozen query pack.
            return QuerySpec(mode, (Pattern("phrase", terms=terms),))
        if mode == "bm25":
            # MatrixOne's IN BM25 MODE uses SearchBagOfWords: distinct query
            # terms are an OR/disjunction, not one positional phrase.
            distinct_terms = tuple(dict.fromkeys(terms))
            return QuerySpec(mode, tuple(Pattern("text", terms=(term,)) for term in distinct_terms))
        raise ValueError(f"unsupported query mode: {mode}")
    lowered = text.lower()
    if lowered.startswith('"') and lowered.endswith('"'):
        patterns = (_pattern_from_token(lowered, dictionary),)
    else:
        patterns = tuple(_pattern_from_token(part, dictionary) for part in _split_boolean(lowered))
    for pattern in patterns:
        _validate_pattern(pattern)
    return QuerySpec(mode, patterns)


def _contains_phrase(tokens: Sequence[str], phrase: Sequence[str]) -> int:
    size = len(phrase)
    if not size:
        return 0
    return min(255, sum(1 for index in range(len(tokens) - size + 1) if list(tokens[index : index + size]) == list(phrase)))


def _contains_prefix(tokens: Sequence[str], prefix: str) -> int:
    return min(255, sum(1 for token in tokens if token.startswith(prefix)))


def _leaf_key(pattern: Pattern) -> int:
    return id(pattern)


def _build_leaf_stats(
    patterns: Sequence[Pattern],
    documents: Mapping[int, Sequence[str]],
    boolean_tf_cap: bool = False,
) -> dict[int, tuple[int, dict[int, int]]]:
    """Return (document-frequency, capped term-frequency by PK) per leaf."""
    result: dict[int, tuple[int, dict[int, int]]] = {}

    def visit(pattern: Pattern) -> None:
        if pattern.operator in {"text", "phrase"}:
            tf_by_pk = {
                pk: _contains_phrase(tokens, pattern.terms)
                for pk, tokens in documents.items()
            }
            if boolean_tf_cap:
                # Boolean GenTextSql/SqlPhrase groups by doc_id, and the
                # Boolean PHRASE path also emits one row per document.  The
                # posting frequency used by EvalLeaf is therefore one even
                # when the source text contains the same term/phrase several
                # times.  STAR remains uncapped except for its uint8 cap.
                tf_by_pk = {pk: min(1, tf) for pk, tf in tf_by_pk.items()}
            tf_by_pk = {pk: tf for pk, tf in tf_by_pk.items() if tf}
            result[_leaf_key(pattern)] = (len(tf_by_pk), tf_by_pk)
            return
        if pattern.operator == "star":
            tf_by_pk = {
                pk: _contains_prefix(tokens, pattern.prefix)
                for pk, tokens in documents.items()
            }
            tf_by_pk = {pk: tf for pk, tf in tf_by_pk.items() if tf}
            result[_leaf_key(pattern)] = (len(tf_by_pk), tf_by_pk)
            return
        for child in pattern.children:
            visit(child)

    for pattern in patterns:
        visit(pattern)
    return result


def _node_matches(pattern: Pattern, pk: int, stats: Mapping[int, tuple[int, Mapping[int, int]]]) -> bool:
    if pattern.operator in {"text", "phrase", "star"}:
        return bool(stats[_leaf_key(pattern)][1].get(pk, 0))
    if pattern.operator == "group":
        return any(_node_matches(child, pk, stats) for child in pattern.children)
    if pattern.operator == "join":
        return all(_node_matches(child, pk, stats) for child in pattern.children)
    return _node_matches(pattern.children[0], pk, stats)


def _matches(mode: str, tokens: Sequence[str], spec: QuerySpec) -> bool:
    """Membership-only compatibility helper used by the contract tests."""
    documents = {0: list(tokens)}
    stats = _build_leaf_stats(spec.patterns, documents, boolean_tf_cap=mode == "boolean")
    patterns = list(spec.patterns)
    if mode == "natural":
        return _node_matches(patterns[0], 0, stats)
    if mode == "bm25":
        return any(_node_matches(pattern, 0, stats) for pattern in patterns)
    required = [pattern for pattern in patterns if pattern.operator in {"plus", "join"}]
    optional = [pattern for pattern in patterns if pattern.operator not in {"plus", "join", "minus"}]
    prohibited = [pattern for pattern in patterns if pattern.operator == "minus"]
    if not required and not optional:
        return False
    if required and not all(_node_matches(pattern, 0, stats) for pattern in required):
        return False
    if not required and not any(_node_matches(pattern, 0, stats) for pattern in optional):
        return False
    return not any(_node_matches(pattern, 0, stats) for pattern in prohibited)


def _f32(value: float) -> float:
    return struct.unpack("!f", struct.pack("!f", float(value)))[0]


def _bm25_leaf_score(
    tf: int,
    df: int,
    doc_length: int,
    doc_count: int,
    avg_doc_length: float,
    weight: float = 1.0,
) -> float:
    """Mirror pkg/fulltext.Pattern.EvalLeaf's float32 operation order.

    MatrixOne's BM25 implementation intentionally uses the historical
    ``log10(N/df)^2`` IDF, not the textbook ``log1p`` variant.  The casts below
    follow the Go float32 assignments and operators so score-bits comparison is
    meaningful rather than merely numerically close.
    """
    if tf <= 0 or df <= 0 or doc_count <= 0:
        return 0.0
    idf = math.log10(float(doc_count) / float(df))
    idf_sq = _f32(idf * idf)
    tf_value = _f32(tf)
    if avg_doc_length <= 0:
        # The product downgrades BM25 to TF-IDF when the __DocLen average is 0.
        return _f32(_f32(weight) * _f32(tf_value * idf_sq))
    norm = 1.0 - B + B * (float(doc_length) / avg_doc_length)
    denominator = _f32(tf_value + _f32(K1 * _f32(norm)))
    numerator = _f32(tf_value * _f32(K1 + 1.0))
    tf_component = _f32(numerator / denominator) if denominator else 0.0
    return _f32(_f32(_f32(weight) * idf_sq) * tf_component)


def _weight_factor(operator: str) -> float:
    return {"lt": 0.9, "gt": 1.1, "rankless": -1.0}.get(operator, 1.0)


def _node_score(
    pattern: Pattern,
    pk: int,
    stats: Mapping[int, tuple[int, Mapping[int, int]]],
    doc_lengths: Mapping[int, int],
    doc_count: int,
    avg_doc_length: float,
    weight: float = 1.0,
) -> float:
    operator = pattern.operator
    if operator in {"text", "phrase", "star"}:
        df, tf_by_pk = stats[_leaf_key(pattern)]
        score = _bm25_leaf_score(tf_by_pk.get(pk, 0), df, doc_lengths[pk], doc_count, avg_doc_length, weight)
        if operator == "phrase":
            # A PHRASE node visits every child TEXT node with the same
            # phrase-level tf/df, then adds those float32 scores.
            for _ in range(max(0, len(pattern.terms) - 1)):
                score = _f32(score + _bm25_leaf_score(tf_by_pk.get(pk, 0), df, doc_lengths[pk], doc_count, avg_doc_length, weight))
        return score
    if operator in {"plus", "minus"}:
        if operator == "minus":
            return 0.0
        return _node_score(pattern.children[0], pk, stats, doc_lengths, doc_count, avg_doc_length, weight)
    if operator in {"lt", "gt", "rankless"}:
        child_weight = _f32(_f32(weight) * _f32(_weight_factor(operator)))
        return _node_score(pattern.children[0], pk, stats, doc_lengths, doc_count, avg_doc_length, child_weight)
    if operator == "group":
        values = [
            _node_score(child, pk, stats, doc_lengths, doc_count, avg_doc_length, weight)
            for child in pattern.children
            if _node_matches(child, pk, stats)
        ]
        return max(values, default=0.0)
    if operator == "join":
        raise ValueError("internal JOIN node requires a combined score")
    raise ValueError(f"unsupported score-oracle pattern operator: {operator}")


def _query_matches_and_scores(
    spec: QuerySpec,
    tokenized: Mapping[int, Sequence[str]],
    doc_lengths: Mapping[int, int],
) -> list[tuple[int, float]]:
    stats = _build_leaf_stats(spec.patterns, tokenized, boolean_tf_cap=spec.mode == "boolean")
    doc_count = len(tokenized)
    avg_doc_length = sum(doc_lengths.values()) / doc_count if doc_count else 0.0
    patterns = list(spec.patterns)
    if spec.mode == "natural":
        pattern = patterns[0]
        return [
            (pk, _node_score(pattern, pk, stats, doc_lengths, doc_count, avg_doc_length))
            for pk in tokenized
            if _node_matches(pattern, pk, stats)
        ]
    if spec.mode == "bm25":
        scored: list[tuple[int, float]] = []
        for pk in tokenized:
            matched = [pattern for pattern in patterns if _node_matches(pattern, pk, stats)]
            if not matched:
                continue
            score = 0.0
            for pattern in matched:
                score = _f32(score + _node_score(pattern, pk, stats, doc_lengths, doc_count, avg_doc_length))
            if not math.isfinite(score) or score < 0:
                raise ValueError(f"query {spec.mode} produced a negative or non-finite score for pk={pk}")
            scored.append((pk, score))
        return scored

    required = [pattern for pattern in patterns if pattern.operator in {"plus", "join"}]
    optional = [pattern for pattern in patterns if pattern.operator not in {"plus", "join", "minus"}]
    prohibited = [pattern for pattern in patterns if pattern.operator == "minus"]
    if not required and not optional:
        # MatrixOne's Eval starts with an empty result; a query containing only
        # '-' filters therefore returns no rows, not the entire corpus.
        return []

    candidates = []
    for pk in tokenized:
        if required and not all(_node_matches(pattern, pk, stats) for pattern in required):
            continue
        if not required and not any(_node_matches(pattern, pk, stats) for pattern in optional):
            continue
        if any(_node_matches(pattern, pk, stats) for pattern in prohibited):
            continue
        candidates.append(pk)

    # PatternOptimizeJoin turns two or more simple PLUS leaves into one JOIN
    # posting.  Its aggregate vector has one slot, with df equal to the
    # intersection and tf equal to the number of joined rows (one for normal
    # TEXT leaves).  Reproduce that score separately from the remaining PLUS
    # or GROUP nodes.
    simple_plus = [
        pattern for pattern in required
        if pattern.operator == "plus" and pattern.children[0].operator in {"text", "star"}
    ]
    joined_score: dict[int, float] = {}
    joined_ids: set[int] = set()
    if required:
        # SqlBoolean builds the first PLUS/JOIN as the base relation.  Every
        # later PLUS/GROUP/value pattern is joined against that relation, so
        # its DF is scoped to the base candidates rather than the whole
        # corpus.  This is observable in BM25 bits for queries such as
        # ``+alpha beta`` and ``+alpha +(>beta <gamma)``.
        if len(simple_plus) > 1:
            scope_ids = {
                pk
                for pk in tokenized
                if all(_node_matches(pattern.children[0], pk, stats) for pattern in simple_plus)
            }
        else:
            base = required[0]
            base_child = base.children[0] if base.operator == "plus" and base.children else base
            scope_ids = {pk for pk in tokenized if _node_matches(base_child, pk, stats)}
    else:
        scope_ids = set(tokenized)
    scoped_documents = {pk: tokenized[pk] for pk in scope_ids}
    scoped_stats = _build_leaf_stats(patterns, scoped_documents, boolean_tf_cap=spec.mode == "boolean")
    if len(simple_plus) > 1:
        joined_ids = {id(pattern) for pattern in simple_plus}
        joined_docs = [
            pk for pk in candidates
            if all(_node_matches(pattern.children[0], pk, stats) for pattern in simple_plus)
        ]
        joined_df = len(joined_docs)
        for pk in joined_docs:
            joined_score[pk] = _bm25_leaf_score(1, joined_df, doc_lengths[pk], doc_count, avg_doc_length)

    scored: list[tuple[int, float]] = []
    for pk in candidates:
        score = joined_score.get(pk, 0.0)
        for pattern in required:
            if id(pattern) not in joined_ids:
                pattern_stats = stats if (required and pattern is required[0] and len(simple_plus) <= 1) else scoped_stats
                score = _f32(score + _node_score(pattern, pk, pattern_stats, doc_lengths, doc_count, avg_doc_length))
        for pattern in optional:
            if _node_matches(pattern, pk, stats):
                score = _f32(score + _node_score(pattern, pk, scoped_stats, doc_lengths, doc_count, avg_doc_length))
        if not math.isfinite(score) or score < 0:
            raise ValueError(f"query {spec.mode} produced a negative or non-finite score for pk={pk}")
        scored.append((pk, score))
    return scored


def recompute_epoch(base: Mapping[str, Any], corpus_path: Path, query_pack_path: Path, ledger_path: Path, epoch: str) -> dict[str, Any]:
    """Compute a mutation epoch from source rows and the independent ledger.

    This deliberately uses only the frozen corpus/query pack and ledger.  It is
    a reference BM25 implementation for score-bits validation, not a query to
    MatrixOne or its hidden FULLTEXT2 tables.
    """
    documents: dict[int, str] = {}
    with corpus_path.open() as handle:
        for line in handle:
            raw = line.rstrip("\n").split("\t", 1)
            if len(raw) == 2:
                documents[int(raw[0])] = raw[1]
    if ledger_path.exists():
        with ledger_path.open(newline="") as handle:
            reader = csv.DictReader(handle, delimiter="\t")
            for row in reader:
                status = row.get("transaction_status", "")
                if status not in {"committed", "rolled_back"} or row.get("operation") == "rollback":
                    continue
                pk = int(row["pk"])
                op = row.get("operation")
                if op in {"insert", "update"}:
                    documents[pk] = row.get("token", "")
                elif op == "delete":
                    documents.pop(pk, None)
    bundle_directory = _bundle_directory(base)
    tokenized = {pk: _gojieba_tokens(body, bundle_directory) for pk, body in documents.items()}
    lengths = {pk: len(tokens) for pk, tokens in tokenized.items()}
    total_length = sum(lengths.values())
    count = len(tokenized)
    queries: dict[str, Any] = {}
    with query_pack_path.open(newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        for row in reader:
            query_id = row["query_id"]
            mode = row["mode"]
            spec = _query_spec(mode, row["query_text"], bundle_directory)
            limit = int(row["limit"])
            scored = _query_matches_and_scores(spec, tokenized, lengths)
            scored.sort(key=lambda item: (-item[1], item[0]))
            cutoff_unique = not (
                len(scored) > limit
                and float32_bits(scored[limit - 1][1]) == float32_bits(scored[limit][1])
            )
            results = [{"pk": pk, "score_bits": float32_bits(score)} for pk, score in scored[:limit]]
            queries[query_id] = {"limit": limit, "cutoff_unique": cutoff_unique, "results": results}
    base_reservoir = {
        int(row["pk"]): row
        for row in base.get("mutation_reservoir", [])
        if isinstance(row, Mapping) and row.get("safe_for_mutation") is True
    }
    reservoir: list[dict[str, Any]] = []
    reservoir_limit = max(1000, len(base.get("mutation_reservoir", [])))
    # Keep deleted safe-PK rows in the mutation reservoir.  They are no longer
    # part of corpus N/DF (and therefore never enter ``documents``), but their
    # original body/token contract is still needed to reinsert the PK later in
    # the run.  Dropping them would make the first delete shrink the required
    # 1k/10k reservoir and make every subsequent epoch unavailable.
    for pk, original in sorted(base_reservoir.items()):
        if pk in tokenized:
            body = documents[pk]
            row = {
                "pk": pk,
                "doc_length": lengths[pk],
                "tokens": tokenized[pk],
                "safe_for_mutation": True,
                "mutation_token": str(original.get("mutation_token") or (tokenized[pk][0] if tokenized[pk] else "")),
                "body_sha256": hashlib.sha256(body.encode()).hexdigest(),
                "alive": True,
            }
        else:
            row = dict(original)
            row["alive"] = False
        reservoir.append(row)
        if len(reservoir) >= reservoir_limit:
            break
    if len(reservoir) < reservoir_limit:
        raise ValueError(f"recomputed score oracle needs at least {reservoir_limit} safe reservoir rows")
    result = dict(base)
    result.pop("epochs", None)
    result.update({"oracle_epoch": epoch, "corpus": {"doc_count": count, "total_doc_length": total_length}, "queries": queries, "mutation_reservoir": reservoir})
    return validate_document(result)


def query_expected(document: Mapping[str, Any], query_id: str) -> dict[int, int]:
    query = document["queries"][query_id]
    return {int(row["pk"]): int(row["score_bits"]) for row in query["results"]}


def compare(document: Mapping[str, Any], query_id: str, rows: Iterable[Sequence[Any]]) -> tuple[bool, str]:
    """Compare exact score bits while leaving equal-score PK order unspecified."""
    expected = query_expected(document, query_id)
    actual: list[tuple[int, int]] = []
    for row in rows:
        if len(row) < 2:
            return False, "ranked query did not return (pk, score)"
        pk = int(row[0])
        try:
            bits = float32_bits(float(row[1]))
        except (TypeError, ValueError, OverflowError) as exc:
            return False, f"invalid score for pk={pk}: {exc}"
        actual.append((pk, bits))
    expected_keys = set(expected)
    actual_keys = {pk for pk, _ in actual}
    if actual_keys != expected_keys:
        return False, f"expected_pks={sorted(expected_keys)[:5]!r} actual_pks={sorted(actual_keys)[:5]!r}"
    expected_bits = expected
    mismatched = [(pk, expected_bits[pk], bits) for pk, bits in actual if expected_bits.get(pk) != bits]
    if mismatched:
        return False, f"score_bits_mismatch={mismatched[:5]!r}"
    actual_scores = [bits_to_float(bits) for _, bits in actual]
    if any(left < right for left, right in zip(actual_scores, actual_scores[1:])):
        return False, f"scores are not non-increasing: {actual[:5]!r}"
    return True, "ok"


def command_validate(args: argparse.Namespace) -> int:
    document = load(Path(args.path))
    print(json.dumps({"schema_version": document["schema_version"], "oracle_epoch": document["oracle_epoch"], "queries": len(document["queries"]), "reservoir": len(document["mutation_reservoir"])}, sort_keys=True))
    return 0


def command_bits(args: argparse.Namespace) -> int:
    print(float32_bits(float(args.value)))
    return 0


def command_recompute_epoch(args: argparse.Namespace) -> int:
    base = load(Path(args.base))
    result = recompute_epoch(base, Path(args.corpus), Path(args.query_pack), Path(args.ledger), args.epoch)
    output = Path(args.output)
    output.write_text(json.dumps(result, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"oracle_epoch": args.epoch, "output": str(output), "queries": len(result["queries"])}, sort_keys=True))
    return 0


def command_extract_bundle(args: argparse.Namespace) -> int:
    document = load(Path(args.oracle))
    directory = extract_bundle(document, Path(args.archive), Path(args.destination), args.bundle_sha256)
    print(json.dumps({"bundle_directory": str(directory), "resources": list(TOKENIZER_BUNDLE_FILES)}, sort_keys=True))
    return 0


def command_validate_bundle(args: argparse.Namespace) -> int:
    document = load(Path(args.oracle))
    validate_bundle_directory(Path(args.bundle_directory), tokenizer_bundle_metadata(document))
    print(json.dumps({"bundle_directory": str(Path(args.bundle_directory)), "resources": list(TOKENIZER_BUNDLE_FILES)}, sort_keys=True))
    return 0


def command_validate_tokenizer(args: argparse.Namespace) -> int:
    document = load(Path(args.oracle))
    directory = validate_tokenizer(document, Path(args.bundle_directory))
    print(json.dumps({"bundle_directory": str(directory), "vectors": len(TOKENIZER_GOLDENS)}, sort_keys=True))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    validate = sub.add_parser("validate")
    validate.add_argument("path")
    validate.set_defaults(handler=command_validate)
    bits = sub.add_parser("float32-bits")
    bits.add_argument("value")
    bits.set_defaults(handler=command_bits)
    recompute = sub.add_parser("recompute-epoch")
    recompute.add_argument("--base", required=True)
    recompute.add_argument("--corpus", required=True)
    recompute.add_argument("--query-pack", required=True)
    recompute.add_argument("--ledger", required=True)
    recompute.add_argument("--epoch", required=True)
    recompute.add_argument("--output", required=True)
    recompute.set_defaults(handler=command_recompute_epoch)
    extract = sub.add_parser("extract-bundle")
    extract.add_argument("--oracle", required=True)
    extract.add_argument("--archive", required=True)
    extract.add_argument("--destination", required=True)
    extract.add_argument("--bundle-sha256", required=True)
    extract.set_defaults(handler=command_extract_bundle)
    validate_bundle = sub.add_parser("validate-bundle")
    validate_bundle.add_argument("--oracle", required=True)
    validate_bundle.add_argument("--bundle-directory", required=True)
    validate_bundle.set_defaults(handler=command_validate_bundle)
    validate_tokenizer = sub.add_parser("validate-tokenizer")
    validate_tokenizer.add_argument("--oracle", required=True)
    validate_tokenizer.add_argument("--bundle-directory", required=True)
    validate_tokenizer.set_defaults(handler=command_validate_tokenizer)
    args = parser.parse_args()
    try:
        return args.handler(args)
    except Exception as exc:
        print(f"score-oracle: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
