#!/usr/bin/env python3
"""Runtime workers for the namespace-local FULLTEXT2 stability harness."""

from __future__ import annotations

import argparse
import contextlib
import csv
import hashlib
import json
import os
import re
import sqlite3
import statistics
import subprocess
import sys
import threading
import time
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator, Mapping, Sequence

import oracle


ROOT = Path(__file__).resolve().parent
STATE = Path(os.environ.get("FT2_STATE_DIR", "/state"))
ARTIFACTS = Path(os.environ.get("FT2_ARTIFACT_DIR", str(STATE / "artifacts")))
RUNTIME = Path(os.environ.get("FT2_RUNTIME_DIR", str(STATE / "runtime")))
LEDGER_DB = STATE / "mutation-ledger.sqlite3"
STOP = RUNTIME / "stop"
WRITER_STOP = RUNTIME / "stop-writer"
PAUSE = RUNTIME / "pause-writer"
PAUSED = RUNTIME / "writer-paused"
FAILURE = RUNTIME / "failure.json"
PACK_PATH = STATE / "query-pack.tsv"
INDEX_CONFIG = STATE / "index-config.json"
CN_ENDPOINTS = STATE / "cn-endpoints.tsv"
CORPUS_TERM_RE = re.compile(r"[A-Za-z0-9_]{4,64}|[\u4e00-\u9fff]{2,16}")


def env(name: str, default: str | None = None) -> str:
    value = os.environ.get(name, default)
    if value is None or value == "":
        raise RuntimeError(f"required environment variable {name} is empty")
    return value


def env_int(name: str, default: int) -> int:
    value = int(os.environ.get(name, str(default)))
    if value < 0:
        raise RuntimeError(f"{name} must be non-negative")
    return value


def now_ns() -> int:
    return time.time_ns()


def boolean_query(token: str) -> str:
    """Return a strict-AND Boolean query for a ledger token or token phrase."""
    terms = [part.lstrip("+") for part in token.split() if part.lstrip("+")]
    if not terms or any(not re.fullmatch(r"[A-Za-z0-9_\u4e00-\u9fff]{2,64}", term) for term in terms):
        raise ValueError(f"unsafe FULLTEXT2 ledger token: {token!r}")
    return " ".join(f"+{term}" for term in terms)


def corpus_terms(body: str) -> Iterator[str]:
    seen: set[str] = set()
    for term in CORPUS_TERM_RE.findall(body):
        normalized = term.lower()
        if normalized not in seen:
            seen.add(normalized)
            yield normalized


def atomic_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    tmp.write_text(json.dumps(value, sort_keys=True, indent=2) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def fail(classification: str, message: str, **details: Any) -> None:
    if not FAILURE.exists():
        atomic_json(
            FAILURE,
            {
                "classification": classification,
                "message": message,
                "observed_at_ns": now_ns(),
                "details": details,
            },
        )


def append_row(path: Path, header: Sequence[str], row: Sequence[Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+", newline="") as handle:
        import fcntl

        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            csv.writer(handle, delimiter="\t", lineterminator="\n").writerow(header)
        csv.writer(handle, delimiter="\t", lineterminator="\n").writerow(row)
        handle.flush()
        os.fsync(handle.fileno())
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def sha256_lines(values: Iterable[Any]) -> str:
    digest = hashlib.sha256()
    for value in sorted(int(v) for v in values):
        digest.update(str(value).encode())
        digest.update(b"\n")
    return digest.hexdigest()


def safe_ident(value: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9_]{1,64}", value):
        raise ValueError(f"unsafe SQL identifier: {value!r}")
    return f"`{value}`"


class SQLClient:
    def __init__(self, host: str | None = None, database: str | None = None):
        self.host = host or env("MYSQL_HOST")
        self.port = env_int("MYSQL_PORT", 6001)
        self.user = env("MYSQL_USER", "dump")
        self.password = os.environ.get("MYSQL_PASSWORD", "")
        self.database = database

    def connect(self, autocommit: bool = True):
        try:
            import pymysql
        except ImportError as exc:  # pragma: no cover - image dependency
            raise RuntimeError("PyMySQL is required in the harness image") from exc
        conn = None
        try:
            conn = pymysql.connect(
                host=self.host,
                port=self.port,
                user=self.user,
                password=self.password,
                database=self.database,
                autocommit=autocommit,
                local_infile=True,
                charset="utf8mb4",
                read_timeout=env_int("SQL_READ_TIMEOUT_SECONDS", 300),
                write_timeout=env_int("SQL_WRITE_TIMEOUT_SECONDS", 300),
                connect_timeout=env_int("SQL_CONNECT_TIMEOUT_SECONDS", 15),
            )
            with conn.cursor() as cur:
                cur.execute("SET experimental_fulltext2_index=1")
                cur.execute("SET ft2_relevancy_algorithm='BM25'")
            return conn
        except Exception:
            if conn is not None:
                conn.close()
            raise

    @staticmethod
    def execute(conn: Any, sql: str, params: Sequence[Any] = ()) -> tuple[list[tuple[Any, ...]], int]:
        with conn.cursor() as cur:
            affected = cur.execute(sql, params)
            rows = list(cur.fetchall()) if cur.description else []
        return rows, affected

    def query(self, sql: str, params: Sequence[Any] = ()) -> list[tuple[Any, ...]]:
        with contextlib.closing(self.connect()) as conn:
            return self.execute(conn, sql, params)[0]

    def wait_ready(self, timeout_seconds: int | None = None) -> dict[str, Any]:
        """Wait for the proxy to accept SQL, not merely for CN Pods to be Ready."""
        timeout = timeout_seconds if timeout_seconds is not None else env_int("SQL_READY_TIMEOUT_SECONDS", 1800)
        retry_seconds = max(0.2, min(10.0, float(os.environ.get("SQL_READY_RETRY_SECONDS", "2"))))
        deadline = time.monotonic() + timeout
        attempts = 0
        last_error = ""
        while True:
            attempts += 1
            try:
                with contextlib.closing(self.connect()) as conn:
                    rows, _ = self.execute(conn, "SELECT 1")
                if rows and int(rows[0][0]) == 1:
                    return {"ready_at_ns": now_ns(), "attempts": attempts, "timeout_seconds": timeout}
                last_error = "SELECT 1 returned no sentinel row"
            except Exception as exc:  # readiness includes proxy connect and session setup
                last_error = f"{type(exc).__name__}: {str(exc)[:200]}"
            if time.monotonic() >= deadline:
                raise RuntimeError(f"SQL readiness timeout after {attempts} attempts: {last_error}")
            time.sleep(retry_seconds)


class FakeSQL:
    """Small stateful SQL double used by contract tests, never by production."""

    def __init__(self):
        self.rows: dict[int, str] = {}
        self.search: dict[str, set[int]] = {}
        self.history: list[tuple[str, tuple[Any, ...]]] = []

    def apply(self, op: "Operation") -> None:
        self.history.append((op.op, (op.pk, op.token)))
        if op.op in {"insert", "update"}:
            if op.previous_token:
                self.search.get(op.previous_token, set()).discard(op.pk)
            self.rows[op.pk] = f"{op.token} mutation stable text"
            self.search.setdefault(op.token, set()).add(op.pk)
        elif op.op == "delete":
            if op.previous_token:
                self.search.get(op.previous_token, set()).discard(op.pk)
            self.rows.pop(op.pk, None)
        elif op.op == "rollback":
            return
        else:  # pragma: no cover - programming error guard
            raise AssertionError(op.op)

    def body(self, pk: int) -> str | None:
        return self.rows.get(pk)

    def membership(self, token: str) -> list[int]:
        return sorted(self.search.get(token, set()))


@dataclass(frozen=True)
class QueryCase:
    query_id: str
    mode: str
    query_text: str
    limit: int
    expected_count: int
    expected_sha256: str


def load_pack(path: Path = PACK_PATH) -> list[QueryCase]:
    required = ["query_id", "mode", "query_text", "limit", "expected_count", "expected_sha256"]
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle, delimiter="\t")
        if reader.fieldnames != required:
            raise RuntimeError(f"query pack header must be {required!r}")
        result: list[QueryCase] = []
        seen: set[str] = set()
        for row in reader:
            query_id = row["query_id"]
            mode = row["mode"]
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", query_id) or query_id in seen:
                raise RuntimeError(f"invalid/duplicate query_id {query_id!r}")
            if mode not in {"natural", "bm25", "boolean"}:
                raise RuntimeError(f"invalid query mode {mode!r}")
            digest = row["expected_sha256"].lower()
            if not re.fullmatch(r"[0-9a-f]{64}", digest):
                raise RuntimeError(f"invalid expected digest for {query_id}")
            limit = int(row["limit"])
            expected = int(row["expected_count"])
            if limit <= 0 or expected < 0 or expected > limit or not row["query_text"]:
                raise RuntimeError(f"invalid query contract for {query_id}")
            seen.add(query_id)
            result.append(QueryCase(query_id, mode, row["query_text"], limit, expected, digest))
    modes = {case.mode for case in result}
    if modes != {"natural", "bm25", "boolean"}:
        raise RuntimeError(f"query pack must cover natural/bm25/boolean, got {sorted(modes)}")
    return result


def against(mode: str) -> str:
    return {
        "natural": "AGAINST(%s)",
        "bm25": "AGAINST(%s IN BM25 MODE)",
        "boolean": "AGAINST(%s IN BOOLEAN MODE)",
    }[mode]


def query_ranked(conn: Any, db_name: str, case: QueryCase) -> list[int]:
    return [row[0] for row in query_ranked_scores(conn, db_name, case)]


def query_ranked_scores(conn: Any, db_name: str, case: QueryCase) -> list[tuple[int, float]]:
    expr = against(case.mode)
    sql = (
        f"SELECT id, MATCH(body) {expr} AS ft2_score FROM {safe_ident(db_name)}.`documents` "
        f"WHERE MATCH(body) {expr} ORDER BY MATCH(body) {expr} DESC,id LIMIT {case.limit}"
    )
    rows, _ = SQLClient.execute(conn, sql, (case.query_text, case.query_text, case.query_text))
    return [(int(row[0]), float(row[1])) for row in rows]


def load_score_oracle(required: bool = False) -> dict[str, Any] | None:
    path = Path(os.environ.get("FT2_SCORE_ORACLE_LOCAL", str(STATE / "score-oracle.json")))
    if not path.exists():
        if required:
            raise RuntimeError(f"score oracle is missing: {path}")
        return None
    document = oracle.load(path)
    expected_commit = os.environ.get("MATRIXONE_COMMIT", "")
    if expected_commit and document["matrixone_commit"] != expected_commit:
        raise RuntimeError("score oracle matrixone_commit does not match the run envelope")
    expected_pack = os.environ.get("QUERY_PACK_SHA256", "")
    if expected_pack and document["query_pack_sha256"] != expected_pack:
        raise RuntimeError("score oracle query_pack_sha256 does not match the run envelope")
    return document


def active_score_oracle(document: dict[str, Any] | None) -> tuple[dict[str, Any] | None, str]:
    """Return the oracle for the currently frozen mutation epoch.

    A fixed base oracle is deliberately not used while the continuous writer is
    mutating N/DF/average document length.  The controller creates this marker
    only after pausing the writer and draining the ledger.  If a data owner did
    not publish the corresponding epoch, the check is deferred and the final
    gate records an invalid observation rather than a false score failure.
    """
    if document is None:
        return None, "not-configured"
    marker = RUNTIME / "score-oracle-epoch.json"
    if not marker.exists():
        return None, "deferred-no-active-epoch"
    try:
        value = json.loads(marker.read_text())
        if value.get("active") is not True:
            return None, "deferred-epoch-inactive"
        epoch = str(value.get("epoch", ""))
        if not epoch:
            return None, "deferred-epoch-empty"
        active_path = value.get("path")
        if isinstance(active_path, str) and active_path:
            path = Path(active_path)
            if not path.is_file():
                return None, "deferred-active-artifact-missing"
            active_document = oracle.load(path)
            if active_document.get("oracle_epoch") != epoch:
                return None, "deferred-active-epoch-mismatch"
            return active_document, "active"
        if epoch == document.get("oracle_epoch"):
            return document, "active"
        epoch_document = oracle.for_epoch(document, epoch)
        if epoch_document is None:
            return None, "deferred-epoch-artifact-missing"
        return epoch_document, "active"
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        fail("score_oracle_epoch_invalid", str(exc))
        return None, "invalid-epoch-marker"


def check_score_oracle(document: dict[str, Any] | None, case: QueryCase, rows: Sequence[tuple[int, float]]) -> tuple[bool, str]:
    selected, state = active_score_oracle(document)
    if selected is None:
        return False, state
    return oracle.compare(selected, case.query_id, rows)


@dataclass(frozen=True)
class Operation:
    operation_id: int
    op: str
    pk: int
    version: int
    token: str
    previous_token: str
    expected_state: str
    batch_id: str


class Ledger:
    def __init__(self, path: Path = LEDGER_DB):
        path.parent.mkdir(parents=True, exist_ok=True)
        self.path = path
        self.db = sqlite3.connect(path, timeout=30, isolation_level=None)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript(
            """
            CREATE TABLE IF NOT EXISTS operations (
              operation_id INTEGER PRIMARY KEY,
              op TEXT NOT NULL,
              pk INTEGER NOT NULL,
              version INTEGER NOT NULL,
              token TEXT NOT NULL,
              previous_token TEXT NOT NULL,
              expected_state TEXT NOT NULL,
              status TEXT NOT NULL,
              planned_ts_ns INTEGER NOT NULL,
              commit_ts_ns INTEGER,
              tail_chunk_before INTEGER NOT NULL DEFAULT -1,
              tail_generation_before INTEGER NOT NULL DEFAULT 0,
              batch_id TEXT NOT NULL,
              verified INTEGER NOT NULL DEFAULT 0,
              verdict TEXT NOT NULL DEFAULT ''
            );
            CREATE TABLE IF NOT EXISTS entities (
              pk INTEGER PRIMARY KEY,
              version INTEGER NOT NULL,
              token TEXT NOT NULL,
              alive INTEGER NOT NULL,
              last_operation_id INTEGER NOT NULL,
              origin TEXT NOT NULL DEFAULT 'synthetic',
              initial_body_sha256 TEXT NOT NULL DEFAULT ''
            );
            """
        )
        columns = {str(row[1]) for row in self.db.execute("PRAGMA table_info(operations)")}
        if "tail_generation_before" not in columns:
            self.db.execute("ALTER TABLE operations ADD COLUMN tail_generation_before INTEGER NOT NULL DEFAULT 0")
        entity_columns = {str(row[1]) for row in self.db.execute("PRAGMA table_info(entities)")}
        if "origin" not in entity_columns:
            self.db.execute("ALTER TABLE entities ADD COLUMN origin TEXT NOT NULL DEFAULT 'synthetic'")
        if "initial_body_sha256" not in entity_columns:
            self.db.execute("ALTER TABLE entities ADD COLUMN initial_body_sha256 TEXT NOT NULL DEFAULT ''")

    def close(self) -> None:
        self.db.close()

    def planned(self) -> list[Operation]:
        rows = self.db.execute(
            "SELECT operation_id,op,pk,version,token,previous_token,expected_state,batch_id "
            "FROM operations WHERE status='planned' ORDER BY operation_id"
        ).fetchall()
        return [Operation(*row) for row in rows]

    def corpus_seed_count(self) -> int:
        return int(self.db.execute("SELECT COUNT(*) FROM entities WHERE origin='corpus'").fetchone()[0])

    def seed_corpus_entities(self, rows: Sequence[tuple[int, str, str]]) -> int:
        self.db.execute("BEGIN IMMEDIATE")
        try:
            for pk, token, body_sha256 in rows:
                existing = self.db.execute("SELECT origin FROM entities WHERE pk=?", (pk,)).fetchone()
                if existing and str(existing[0]) != "corpus":
                    raise RuntimeError(f"corpus seed PK collides with synthetic entity: {pk}")
                self.db.execute(
                    "INSERT INTO entities(pk,version,token,alive,last_operation_id,origin,initial_body_sha256) "
                    "VALUES(?,?,?,?,0,'corpus',?) ON CONFLICT(pk) DO NOTHING",
                    (pk, 0, token, 1, body_sha256),
                )
            self.db.execute("COMMIT")
        except Exception:
            self.db.execute("ROLLBACK")
            raise
        return self.corpus_seed_count()

    def plan_batch(self, size: int, insert_pct: int, update_pct: int, delete_pct: int, rollback_every: int) -> list[Operation]:
        if insert_pct + update_pct + delete_pct != 100:
            raise RuntimeError("DML percentages must sum to 100")
        self.db.execute("BEGIN IMMEDIATE")
        try:
            next_id = int(self.db.execute("SELECT COALESCE(MAX(operation_id),0)+1 FROM operations").fetchone()[0])
            state = {
                int(pk): [int(version), str(token), bool(alive), str(origin)]
                for pk, version, token, alive, origin in self.db.execute(
                    "SELECT e.pk,e.version,e.token,e.alive,e.origin FROM entities e "
                    "LEFT JOIN operations o ON o.operation_id=e.last_operation_id "
                    "WHERE e.last_operation_id=0 OR o.verified=1"
                )
            }
            eligible = {pk for pk, values in state.items() if values[2]}
            deleted_corpus = {pk for pk, values in state.items() if not values[2] and values[3] == "corpus"}
            result: list[Operation] = []
            batch_id = f"{'single' if size == 1 else 'batch'}-{next_id:012d}"
            for offset in range(size):
                op_id = next_id + offset
                bucket = (op_id - 1) % 100
                op = "insert" if bucket < insert_pct else "update" if bucket < insert_pct + update_pct else "delete"
                if rollback_every > 0 and op_id % rollback_every == 0:
                    if result:
                        break
                    op = "rollback"
                if op in {"update", "delete"} and not eligible:
                    break
                if op == "insert":
                    if deleted_corpus:
                        pk = sorted(deleted_corpus)[0]
                        version = state[pk][0] + 1
                        previous = state[pk][1]
                        deleted_corpus.remove(pk)
                    else:
                        pk = 8_000_000_000_000_000_000 + op_id
                        version = 1
                        previous = ""
                elif op == "rollback":
                    pk = 8_000_000_000_000_000_000 + op_id
                    version = 1
                    previous = ""
                else:
                    corpus_candidates = sorted(pk for pk in eligible if state[pk][3] == "corpus")
                    if corpus_candidates and op_id % 4 == 0:
                        candidates = corpus_candidates
                    else:
                        candidates = sorted(eligible, key=lambda candidate: (state[candidate][3] != "corpus", candidate))
                    pk = candidates[0]
                    version = state[pk][0] + (1 if op == "update" else 0)
                    previous = state[pk][1]
                token = f"zzft2op{op_id:012d}v{version}zz"
                expected = "rollback_absent" if op == "rollback" else "absent" if op == "delete" else "present"
                operation = Operation(op_id, op, pk, version, token, previous, expected, batch_id)
                self.db.execute(
                    "INSERT INTO operations(operation_id,op,pk,version,token,previous_token,expected_state,status,planned_ts_ns,batch_id) "
                    "VALUES(?,?,?,?,?,?,?,'planned',?,?)",
                    (op_id, op, pk, version, token, previous, expected, now_ns(), batch_id),
                )
                if op == "insert":
                    # A deleted reservoir PK can be reinserted during the
                    # long run.  Keep its corpus provenance so coverage and
                    # the exported ledger remain an honest corpus-operation
                    # accounting, rather than silently relabeling history as
                    # synthetic.
                    origin = state[pk][3] if pk in state else "synthetic"
                    state[pk] = [version, token, True, origin]
                elif op == "update":
                    state[pk] = [version, token, True, state[pk][3]]
                elif op == "delete":
                    state[pk][2] = False
                if op in {"update", "delete"}:
                    eligible.remove(pk)
                result.append(operation)
                if op == "rollback":
                    break
            self.db.execute("COMMIT")
            return result
        except Exception:
            self.db.execute("ROLLBACK")
            raise

    def finalize(self, operations: Sequence[Operation], commit_ts_ns: int, rolled_back: bool = False) -> None:
        self.db.execute("BEGIN IMMEDIATE")
        try:
            for op in operations:
                status = "rolled_back" if rolled_back or op.op == "rollback" else "committed"
                self.db.execute(
                    "UPDATE operations SET status=?,commit_ts_ns=? WHERE operation_id=? AND status='planned'",
                    (status, commit_ts_ns, op.operation_id),
                )
                if status == "rolled_back":
                    continue
                if op.op in {"insert", "update"}:
                    self.db.execute(
                        "INSERT INTO entities(pk,version,token,alive,last_operation_id) VALUES(?,?,?,?,?) "
                        "ON CONFLICT(pk) DO UPDATE SET version=excluded.version,token=excluded.token,alive=1,last_operation_id=excluded.last_operation_id",
                        (op.pk, op.version, op.token, 1, op.operation_id),
                    )
                elif op.op == "delete":
                    self.db.execute(
                        "UPDATE entities SET alive=0,last_operation_id=? WHERE pk=?",
                        (op.operation_id, op.pk),
                    )
            self.db.execute("COMMIT")
        except Exception:
            self.db.execute("ROLLBACK")
            raise

    def set_tail_observation_before(self, operations: Sequence[Operation], tail_chunk: int, generation: int) -> None:
        self.db.executemany(
            "UPDATE operations SET tail_chunk_before=?,tail_generation_before=? WHERE operation_id=? AND status='planned'",
            [(tail_chunk, generation, operation.operation_id) for operation in operations],
        )

    def pending_verification(self, limit: int = 100) -> list[tuple[Any, ...]]:
        return self.db.execute(
            "SELECT operation_id,op,pk,version,token,previous_token,commit_ts_ns,tail_chunk_before,tail_generation_before,expected_state,batch_id "
            "FROM operations WHERE status IN ('committed','rolled_back') AND verified=0 ORDER BY operation_id LIMIT ?",
            (limit,),
        ).fetchall()

    def pending_count(self) -> int:
        row = self.db.execute(
            "SELECT COUNT(*) FROM operations WHERE status='planned' OR (status IN ('committed','rolled_back') AND verified=0)"
        ).fetchone()
        return int(row[0]) if row else 0

    def pending_max_age_seconds(self) -> float:
        row = self.db.execute(
            "SELECT COALESCE(MIN(planned_ts_ns),0) FROM operations "
            "WHERE status='planned' OR (status IN ('committed','rolled_back') AND verified=0)"
        ).fetchone()
        return max(0.0, (now_ns() - int(row[0])) / 1e9) if row and row[0] else 0.0

    def mark_verified(self, operation_id: int, verdict: str) -> None:
        self.db.execute(
            "UPDATE operations SET verified=1,verdict=? WHERE operation_id=?",
            (verdict, operation_id),
        )

    def all_entities(self) -> list[tuple[int, int, str, int]]:
        rows = self.db.execute(
            "SELECT pk,version,token,alive FROM entities ORDER BY pk"
        ).fetchall()
        return [tuple(row) for row in rows]

    def export(self, path: Path) -> str:
        tmp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
        header = [
            "operation_id", "operation", "pk", "version", "token", "previous_token", "commit_ts", "tail_chunk_before", "tail_generation_before",
            "expected_state", "transaction_status", "batch_id", "verified", "verdict", "entity_origin", "initial_body_sha256",
        ]
        rows = self.db.execute(
            "SELECT o.operation_id,o.op,o.pk,o.version,o.token,o.previous_token,COALESCE(o.commit_ts_ns,0),o.tail_chunk_before,o.tail_generation_before,o.expected_state,o.status,o.batch_id,o.verified,o.verdict,COALESCE(e.origin,'synthetic'),COALESCE(e.initial_body_sha256,'') "
            "FROM operations o LEFT JOIN entities e ON e.pk=o.pk ORDER BY o.operation_id"
        )
        with tmp.open("w", newline="") as handle:
            writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
            writer.writerow(header)
            writer.writerows(rows)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, path)
        return hashlib.sha256(path.read_bytes()).hexdigest()


def execute_operation(conn: Any, db_name: str, operation: Operation) -> None:
    table = f"{safe_ident(db_name)}.`documents`"
    body = operation.token
    if operation.op in {"insert", "rollback"}:
        _, affected = SQLClient.execute(conn, f"INSERT INTO {table}(id,body) VALUES(%s,%s)", (operation.pk, body))
    elif operation.op == "update":
        _, affected = SQLClient.execute(conn, f"UPDATE {table} SET body=%s WHERE id=%s", (body, operation.pk))
    elif operation.op == "delete":
        _, affected = SQLClient.execute(conn, f"DELETE FROM {table} WHERE id=%s", (operation.pk,))
    else:  # pragma: no cover
        raise AssertionError(operation.op)
    if affected != 1:
        raise RuntimeError(f"{operation.op} operation {operation.operation_id} affected {affected} rows")


def seed_oracle_entities(
    client: SQLClient, db_name: str, score_document: Mapping[str, Any], ledger: Ledger, required: int
) -> int:
    """Seed the data-owner-selected reservoir without querying FULLTEXT2 for eligibility."""
    reservoir = score_document.get("mutation_reservoir")
    if not isinstance(reservoir, list) or len(reservoir) < required:
        raise RuntimeError(f"score oracle mutation reservoir has fewer than {required} rows")
    selected = reservoir[:required]
    pack_terms = {term for case in load_pack() for term in corpus_terms(case.query_text)}
    rows: list[tuple[int, str, str]] = []
    pks: list[int] = []
    for item in selected:
        if not isinstance(item, dict) or item.get("safe_for_mutation") is not True:
            raise RuntimeError("score oracle reservoir row is not marked safe_for_mutation")
        pk = int(item["pk"])
        tokens = item.get("tokens")
        if isinstance(tokens, list) and pack_terms.intersection(str(token).lower() for token in tokens):
            raise RuntimeError(f"score oracle reservoir row {pk} overlaps a query-pack token")
        if not isinstance(tokens, list) or not tokens:
            raise RuntimeError(f"score oracle reservoir row {pk} lacks an initial corpus token")
        # The mutation token is the data-owner's safe token contract; it is
        # not necessarily present in the frozen body.  The ledger entity must
        # start with a token that is actually searchable before its first DML.
        token = str(tokens[0])
        body_sha = str(item.get("body_sha256", ""))
        if not token or not body_sha:
            raise RuntimeError(f"score oracle reservoir row {pk} lacks initial token/body_sha256")
        rows.append((pk, token, body_sha))
        pks.append(pk)
    existing: set[int] = set()
    body_digests: dict[int, str] = {}
    for offset in range(0, len(pks), 500):
        values = pks[offset : offset + 500]
        placeholders = ",".join(["%s"] * len(values))
        found = client.query(
            f"SELECT id,body FROM {safe_ident(db_name)}.`documents` WHERE id IN ({placeholders})",
            tuple(values),
        )
        for row in found:
            pk = int(row[0])
            existing.add(pk)
            body_digests[pk] = hashlib.sha256(str(row[1]).encode("utf-8")).hexdigest()
    missing = sorted(set(pks) - existing)
    if missing:
        raise RuntimeError(f"score oracle reservoir contains missing corpus PKs: {missing[:5]}")
    mismatched = sorted(pk for pk, _, body_sha in rows if body_digests.get(pk) != body_sha)
    if mismatched:
        raise RuntimeError(f"score oracle reservoir body SHA mismatch for corpus PKs: {mismatched[:5]}")
    return ledger.seed_corpus_entities(rows)


def recover_planned(client: SQLClient, ledger: Ledger, db_name: str) -> None:
    for operation in ledger.planned():
        rows = client.query(
            f"SELECT body FROM {safe_ident(db_name)}.`documents` WHERE id=%s", (operation.pk,)
        )
        body = str(rows[0][0]) if rows else None
        applied = operation.op in {"insert", "update"} and body is not None and operation.token in body
        applied = applied or (operation.op == "delete" and body is None)
        if operation.op == "rollback":
            if body is not None:
                fail("rollback_visible", "planned rollback row survived controller loss", operation_id=operation.operation_id)
                raise RuntimeError("rollback recovery found visible row")
            ledger.finalize([operation], now_ns(), rolled_back=True)
        elif applied:
            ledger.finalize([operation], now_ns())
        else:
            with contextlib.closing(client.connect(autocommit=False)) as conn:
                execute_operation(conn, db_name, operation)
                conn.commit()
            ledger.finalize([operation], now_ns())


DML_RAW_HEADER = ["operation_id", "batch_id", "operation", "start_ts_ns", "commit_ts_ns", "latency_ms", "result"]
DML_WINDOW_HEADER = [
    "window_start_ns", "window_end_ns", "target_ops_per_second", "operations", "committed", "errors",
    "batches", "p50_ms", "p95_ms", "p99_ms", "burst", "pending_count", "pending_max_age_seconds", "clean",
]


def percentile(values: Sequence[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = max(0, min(len(ordered) - 1, int((len(ordered) - 1) * fraction + 0.999999)))
    return float(ordered[index])


class TokenBucket:
    """Monotonic-rate limiter so DML load is measured, not sleep-shaped."""

    def __init__(self, rate: float, burst: float | None = None):
        self.rate = max(0.0, float(rate))
        # The bucket must be able to pay for one whole DML batch.  A zero-rate
        # calibration bootstrap therefore still has a finite, configurable
        # capacity; changing only ``rate`` after construction must not leave a
        # burst larger than the bucket permanently blocked.
        self.capacity = max(1.0, float(burst if burst is not None else 1.0))
        self.tokens = self.capacity
        self.last = time.monotonic()

    def set_rate(self, rate: float, burst: float | None = None) -> None:
        self.rate = max(0.0, float(rate))
        requested = max(1.0, float(burst if burst is not None else 1.0))
        if requested > self.capacity:
            self.capacity = requested
        self.tokens = min(self.capacity, max(0.0, self.tokens))

    def wait(self, amount: int = 1) -> None:
        if self.rate <= 0:
            return
        amount = max(1, amount)
        while not STOP.exists() and not FAILURE.exists():
            current = time.monotonic()
            self.tokens = min(self.capacity, self.tokens + (current - self.last) * self.rate)
            self.last = current
            if self.tokens >= amount:
                self.tokens -= amount
                return
            time.sleep(min(0.5, (amount - self.tokens) / self.rate))


def writer(_: argparse.Namespace) -> int:
    db_name = env("FT2_DATABASE")
    deadline_ns = int(env("FT2_DEADLINE_NS"))
    insert_pct = env_int("DML_INSERT_PCT", 25)
    update_pct = env_int("DML_UPDATE_PCT", 50)
    delete_pct = env_int("DML_DELETE_PCT", 25)
    if insert_pct + update_pct + delete_pct != 100:
        raise RuntimeError("DML percentages must sum to 100")
    client = SQLClient(database=db_name)
    ledger = Ledger()
    raw_path = STATE / "dml-samples.tsv"
    window_path = ARTIFACTS / "dml-windows.tsv"
    recover_planned(client, ledger, db_name)
    base_batch = max(1, env_int("DML_BATCH_SIZE", 1))
    burst_batch = max(base_batch, env_int("BURST_BATCH_SIZE", 20))
    burst_interval = max(1, env_int("BURST_INTERVAL_SECONDS", 1800))
    burst_duration = env_int("BURST_DURATION_SECONDS", 120)
    rollback_every = env_int("ROLLBACK_EVERY", 50)
    delay_ms = env_int("DML_INTERVAL_MS", 20)
    steady_rate = float(os.environ.get("STEADY_OPS_PER_SECOND", "0"))
    burst_rate = float(os.environ.get("BURST_OPS_PER_SECOND", str(max(steady_rate, 0.0))))
    bucket = TokenBucket(steady_rate, burst=burst_batch)
    window_seconds = max(1, env_int("WINDOW_SECONDS", 300))
    started = time.monotonic()
    window_started_ns = now_ns()
    window_rows: list[tuple[float, bool, str]] = []
    batch_ids: set[str] = set()
    try:
        while now_ns() < deadline_ns and not STOP.exists() and not WRITER_STOP.exists() and not FAILURE.exists():
            if PAUSE.exists():
                PAUSED.touch()
                while PAUSE.exists() and not STOP.exists() and not FAILURE.exists():
                    time.sleep(0.25)
                PAUSED.unlink(missing_ok=True)
                continue
            elapsed = int(time.monotonic() - started)
            phase = (RUNTIME / "phase").read_text().strip() if (RUNTIME / "phase").exists() else "steady"
            in_burst = False if phase == "calibration" else phase == "burst" if env_int("DURATION_SECONDS", 7200) >= 86400 else elapsed % burst_interval < burst_duration
            batch_size = burst_batch if in_burst else base_batch
            if phase == "calibration" and (RUNTIME / "calibration-rate").exists():
                with contextlib.suppress(ValueError):
                    bucket.set_rate(float((RUNTIME / "calibration-rate").read_text().strip()), burst=batch_size)
            elif phase in {"steady", "final-steady"} and (RUNTIME / "steady-rate").exists():
                with contextlib.suppress(ValueError):
                    bucket.set_rate(float((RUNTIME / "steady-rate").read_text().strip()), burst=batch_size)
            elif phase == "burst" and (RUNTIME / "burst-rate").exists():
                with contextlib.suppress(ValueError):
                    bucket.set_rate(float((RUNTIME / "burst-rate").read_text().strip()), burst=batch_size)
            if phase not in {"calibration", "steady", "final-steady", "burst"}:
                bucket.set_rate(burst_rate if in_burst else steady_rate, burst=batch_size)
            bucket.wait(batch_size)
            operations = ledger.plan_batch(batch_size, insert_pct, update_pct, delete_pct, rollback_every)
            if not operations:
                time.sleep(0.1)
                continue
            tail_before, generation_before = tail_observation(client, db_name)
            ledger.set_tail_observation_before(operations, tail_before, generation_before)
            begin = now_ns()
            result = "committed"
            try:
                with contextlib.closing(client.connect(autocommit=False)) as conn:
                    for operation in operations:
                        execute_operation(conn, db_name, operation)
                    if operations[0].op == "rollback":
                        conn.rollback()
                        result = "rolled_back"
                    else:
                        conn.commit()
                committed = now_ns()
                ledger.finalize(operations, committed, rolled_back=result == "rolled_back")
            except Exception as exc:
                committed = now_ns()
                result = "error"
                fail("dml_error", str(exc), batch_id=operations[0].batch_id)
            latency = (committed - begin) / 1_000_000
            for operation in operations:
                append_row(raw_path, DML_RAW_HEADER, [operation.operation_id, operation.batch_id, operation.op, begin, committed, f"{latency:.3f}", result])
                window_rows.append((latency, result != "error", "1" if in_burst else "0"))
                batch_ids.add(operation.batch_id)
            if now_ns() - window_started_ns >= window_seconds * 1_000_000_000:
                latencies = [row[0] for row in window_rows]
                append_row(
                    window_path,
                    DML_WINDOW_HEADER,
                    [
                        window_started_ns,
                        now_ns(),
                        f"{bucket.rate:.6f}",
                        len(window_rows),
                        sum(1 for row in window_rows if row[1]),
                        sum(1 for row in window_rows if not row[1]),
                        len(batch_ids),
                        f"{percentile(latencies,.50):.3f}",
                        f"{percentile(latencies,.95):.3f}",
                        f"{percentile(latencies,.99):.3f}",
                        max((row[2] for row in window_rows), default="0"),
                        ledger.pending_count(),
                        f"{ledger.pending_max_age_seconds():.3f}",
                        "1" if window_rows and all(row[1] for row in window_rows) and ledger.pending_count() == 0 else "0",
                    ],
                )
                window_started_ns = now_ns()
                window_rows.clear()
                batch_ids.clear()
                ledger.export(ARTIFACTS / "mutation-ledger.tsv")
            if result == "error":
                break
            if not in_burst and delay_ms:
                time.sleep(delay_ms / 1000)
    finally:
        PAUSED.unlink(missing_ok=True)
        ledger.export(ARTIFACTS / "mutation-ledger.tsv")
        ledger.close()
    return 1 if FAILURE.exists() else 0


QUERY_RAW_HEADER = ["ts_ns", "query_id", "mode", "concurrency", "worker", "endpoint", "phase", "burst", "cache_state", "latency_ms", "rows", "result", "cold_first"]
QUERY_WINDOW_HEADER = [
    "window_id", "window_start_ns", "window_end_ns", "mode", "concurrency", "endpoint", "phase", "burst",
    "cache_state", "active_duration_seconds", "queries", "errors", "qps", "p50_ms", "p95_ms", "p99_ms", "noise",
]


def reader(_: argparse.Namespace) -> int:
    db_name = env("FT2_DATABASE")
    deadline_ns = int(env("FT2_DEADLINE_NS"))
    pack = load_pack()
    concurrencies = [int(value) for value in env("READER_CONCURRENCIES", "1,10").split(",")]
    if concurrencies != [1, 10]:
        raise RuntimeError("first-stage reader contract requires C1,C10")
    score_document = load_score_oracle(required=os.environ.get("FT2_SCORE_ORACLE_REQUIRED", "0") == "1")
    performance_host = os.environ.get("FT2_PERF_CN", "")
    performance_endpoint = os.environ.get("FT2_PERF_ENDPOINT", "cn1")
    raw_path = STATE / "query-samples.tsv"
    windows_path = ARTIFACTS / "query-windows.tsv"
    window_seconds = max(1, env_int("WINDOW_SECONDS", 300))
    window_ns = window_seconds * 1_000_000_000
    epoch_path = RUNTIME / "query-epoch.json"
    if epoch_path.exists():
        epoch_start = int(json.loads(epoch_path.read_text())["epoch_start_ns"])
    else:
        epoch_start = ((now_ns() + window_ns - 1) // window_ns) * window_ns
        atomic_json(epoch_path, {"schema_version": 1, "epoch_start_ns": epoch_start, "window_seconds": window_seconds})
    # The cold query is the only score check allowed before a writer starts.
    # Freeze the matching base epoch explicitly so a later DML epoch cannot be
    # mistaken for the immutable corpus oracle.
    if score_document and not (RUNTIME / "score-oracle-epoch.json").exists():
        atomic_json(RUNTIME / "score-oracle-epoch.json", {"schema_version": 1, "active": True, "epoch": score_document.get("oracle_epoch", ""), "source": "base"})
    lock = threading.Lock()
    samples: dict[tuple[str, int], list[tuple[float, bool]]] = {}
    threads: list[threading.Thread] = []

    cold_case = pack[0]
    cold_begin = now_ns()
    cold_result = "ok"
    cold_ids: list[int] = []
    performance_pod = performance_pod_name(performance_endpoint)
    proc_before = proc_metrics(performance_pod) if performance_pod else (0, 0, 0, 0, 0, 0, 0, "unavailable")
    query_end = cold_begin
    try:
        with contextlib.closing(SQLClient(host=performance_host or None, database=db_name).connect()) as cold_conn:
            cold_scores = query_ranked_scores(cold_conn, db_name, cold_case)
            cold_ids = [pk for pk, _ in cold_scores]
            query_end = now_ns()
            _, score_state = active_score_oracle(score_document)
            if score_state == "active":
                score_ok, score_reason = check_score_oracle(score_document, cold_case, cold_scores)
                if not score_ok:
                    cold_result = "score_wrong"
                    fail("score_bits_mismatch", score_reason, query_id=cold_case.query_id, endpoint=performance_endpoint)
        if len(cold_ids) != cold_case.expected_count or sha256_lines(cold_ids) != cold_case.expected_sha256:
            cold_result = "wrong"
            fail("query_oracle_mismatch", "controlled cold query disagreed with the independent query pack", query_id=cold_case.query_id)
    except Exception as exc:
        cold_result = "error"
        fail("cold_query_error", str(exc), query_id=cold_case.query_id)
    proc_after = proc_metrics(performance_pod) if performance_pod else proc_before
    cold_latency = (query_end - cold_begin) / 1_000_000
    append_row(raw_path, QUERY_RAW_HEADER, [cold_begin, cold_case.query_id, cold_case.mode, 1, -1, performance_endpoint, "cold", 0, "cold", f"{cold_latency:.3f}", len(cold_ids), cold_result, 1])
    generation = ""
    with contextlib.suppress(Exception):
        generation = str(tail_observation(SQLClient(host=performance_host or None, database=db_name), db_name)[1])
    rss_value = str(proc_after[0]) if proc_after[-1] == "ok" else "UNAVAILABLE_NO_POD_PROC"
    faults_value = str(max(0, proc_after[3] - proc_before[3])) if proc_after[-1] == "ok" and proc_before[-1] == "ok" else "UNAVAILABLE_NO_POD_PROC"
    append_row(ARTIFACTS / "cache-events.tsv", ["ts_ns", "endpoint", "event", "latency_ms", "generation", "rss_bytes", "page_fault_delta", "verdict"], [now_ns(), performance_endpoint, "cold-query", f"{cold_latency:.3f}", generation, rss_value, faults_value, "PASS" if cold_result == "ok" else "FAIL"])
    (RUNTIME / "cold-query-observed").touch()
    if cold_result != "ok":
        return 1

    workload_start = int(os.environ.get("FT2_WORKLOAD_STARTED_AT_NS", str(now_ns())))
    exclusive = os.environ.get("FT2_READER_EXCLUSIVE_WINDOWS", "1") == "1"

    def window_position() -> tuple[int, int, int]:
        current = now_ns()
        if current < epoch_start:
            return -1, epoch_start, epoch_start + window_ns
        window_id = (current - epoch_start) // window_ns
        start = epoch_start + window_id * window_ns
        return int(window_id), start, start + window_ns

    def active_concurrency(at_ns: int | None = None) -> int:
        if not exclusive:
            return 0
        current = now_ns() if at_ns is None else at_ns
        if current < epoch_start:
            return 0
        window_id = (current - epoch_start) // window_ns
        return 1 if window_id % 2 == 0 else 10

    def run_worker(concurrency: int, worker_id: int) -> None:
        client = SQLClient(host=performance_host or None, database=db_name)
        try:
            with contextlib.closing(client.connect()) as conn:
                index = worker_id % len(pack)
                while now_ns() < deadline_ns and not STOP.exists() and not FAILURE.exists():
                    if exclusive and active_concurrency() != concurrency:
                        time.sleep(0.25)
                        continue
                    case = pack[index % len(pack)]
                    index += 1
                    begin = now_ns()
                    result = "ok"
                    ids: list[int] = []
                    try:
                        scores = query_ranked_scores(conn, db_name, case)
                        ids = [pk for pk, _ in scores]
                        _, score_state = active_score_oracle(score_document)
                        if score_state == "active":
                            score_ok, score_reason = check_score_oracle(score_document, case, scores)
                            if not score_ok:
                                result = "score_wrong"
                                fail("score_bits_mismatch", score_reason, query_id=case.query_id, concurrency=concurrency, worker=worker_id, endpoint=performance_endpoint)
                        if len(ids) != case.expected_count or sha256_lines(ids) != case.expected_sha256:
                            result = "wrong"
                            fail("query_oracle_mismatch", "reader result disagreed with the independent query pack", query_id=case.query_id, concurrency=concurrency, worker=worker_id)
                    except Exception:
                        result = "error"
                        with contextlib.suppress(Exception):
                            conn.ping(reconnect=True)
                    latency = (now_ns() - begin) / 1_000_000
                    with lock:
                        samples.setdefault((case.mode, concurrency), []).append((latency, result == "ok"))
                        phase = (RUNTIME / "phase").read_text().strip() if (RUNTIME / "phase").exists() else "steady"
                        burst = (RUNTIME / "burst").exists()
                        cache_state = (RUNTIME / "cache-state").read_text().strip() if (RUNTIME / "cache-state").exists() else "unknown"
                        append_row(raw_path, QUERY_RAW_HEADER, [begin, case.query_id, case.mode, concurrency, worker_id, performance_endpoint, phase, int(burst), cache_state, f"{latency:.3f}", len(ids), result, 0])
                    if result == "wrong":
                        return
        except Exception as exc:
            fail("reader_connection", str(exc), concurrency=concurrency, worker=worker_id)

    started_groups: set[int] = set()

    def ensure_group(concurrency: int) -> None:
        if concurrency not in concurrencies or concurrency in started_groups:
            return
        started_groups.add(concurrency)
        for worker_id in range(concurrency):
            thread = threading.Thread(target=run_worker, args=(concurrency, worker_id), daemon=True)
            thread.start()
            threads.append(thread)

    while now_ns() < epoch_start and now_ns() < deadline_ns and not STOP.exists() and not FAILURE.exists():
        time.sleep(min(1, max(0.01, (epoch_start - now_ns()) / 1e9)))
    window_id, window_start, window_end = window_position()
    ensure_group(active_concurrency(window_start) or concurrencies[0])
    while now_ns() < deadline_ns and not STOP.exists() and not FAILURE.exists():
        remaining = max(0.0, (window_end - now_ns()) / 1_000_000_000)
        if remaining > 0:
            time.sleep(min(1, remaining))
            continue
        end = window_end
        noise = (RUNTIME / "noise-status").read_text().strip() if (RUNTIME / "noise-status").exists() else "unknown"
        with lock:
            current, samples = samples, {}
        for mode in ("natural", "bm25", "boolean"):
            for concurrency in concurrencies:
                values = current.get((mode, concurrency), [])
                latencies = [value[0] for value in values if value[1]]
                errors = sum(1 for value in values if not value[1])
                active = (not exclusive) or active_concurrency(window_start) == concurrency
                active_seconds = (end - window_start) / 1_000_000_000 if active else 0.0
                seconds = max(active_seconds, 0.001)
                selected_endpoint = performance_endpoint
                phase = (RUNTIME / "phase").read_text().strip() if (RUNTIME / "phase").exists() else "steady"
                burst = int((RUNTIME / "burst").exists())
                cache_state = (RUNTIME / "cache-state").read_text().strip() if (RUNTIME / "cache-state").exists() else "unknown"
                append_row(windows_path, QUERY_WINDOW_HEADER, [window_id, window_start, end, mode, concurrency, selected_endpoint, phase, burst, cache_state, f"{active_seconds:.6f}", len(values), errors, f"{len(values)/seconds:.6f}" if active else "0.000000", f"{percentile(latencies,.50):.3f}", f"{percentile(latencies,.95):.3f}", f"{percentile(latencies,.99):.3f}", noise])
        window_id, window_start, window_end = window_position()
        if window_id < 0:
            continue
        ensure_group(active_concurrency(window_start) or concurrencies[0])
    STOP.touch(exist_ok=True) if FAILURE.exists() else None
    for thread in threads:
        thread.join(timeout=5)
    return 1 if FAILURE.exists() else 0


def read_endpoints() -> list[tuple[str, str]]:
    rows: list[tuple[str, str]] = []
    if CN_ENDPOINTS.exists():
        with CN_ENDPOINTS.open() as handle:
            for line in handle:
                name, host = line.rstrip("\n").split("\t", 1)
                rows.append((name, host))
    rows.append(("proxy", env("MYSQL_HOST")))
    dedup: dict[str, str] = {}
    for name, host in rows:
        dedup[name] = host
    endpoints = sorted(dedup.items(), key=lambda item: (0 if item[0] == "cn1" else 1 if item[0] == "cn2" else 2, item[0]))
    if len([name for name, _ in endpoints if name.startswith("cn")]) < 2:
        raise RuntimeError("two direct CN endpoints are required")
    return endpoints


def performance_pod_name(endpoint: str) -> str:
    path = RUNTIME / "cn-pod-map.json"
    if not path.exists():
        return ""
    try:
        value = json.loads(path.read_text())
    except (OSError, json.JSONDecodeError):
        return ""
    return str(value.get(endpoint, ""))


def token_membership(client: SQLClient, db_name: str, token: str) -> list[int]:
    rows = client.query(
        f"SELECT id FROM {safe_ident(db_name)}.`documents` WHERE MATCH(body) AGAINST(%s IN BOOLEAN MODE) ORDER BY id",
        (boolean_query(token),),
    )
    return [int(row[0]) for row in rows]


def tail_observation(client: SQLClient, db_name: str) -> tuple[int, int]:
    if not INDEX_CONFIG.exists():
        return -1, 0
    cfg = json.loads(INDEX_CONFIG.read_text())
    store = safe_ident(cfg["storage_table"])
    meta = safe_ident(cfg["metadata_table"])
    chunk_rows = client.query(
        f"SELECT COALESCE(MAX(chunk_id),-1) FROM {safe_ident(db_name)}.{store} WHERE index_id='cdc_tail' AND tag=1"
    )
    ts_rows = client.query(f"SELECT COALESCE(MAX(timestamp),0) FROM {safe_ident(db_name)}.{meta}")
    return int(chunk_rows[0][0]), int(ts_rows[0][0])


def tail_progress_state(previous: Mapping[str, Any], chunk: int, generation: int, sample_ts: int) -> dict[str, int]:
    """Advance tail progress only when chunk/generation actually changes."""
    changed_at = int(previous.get("changed_at_ns", 0) or 0)
    if chunk < 0:
        changed_at = 0
    elif previous.get("chunk") != chunk or previous.get("generation") != generation or changed_at <= 0:
        changed_at = sample_ts
    return {"chunk": int(chunk), "generation": int(generation), "changed_at_ns": changed_at, "observed_at_ns": int(sample_ts)}


CORRECTNESS_HEADER = ["ts_ns", "check", "event_id", "operation_id", "pk", "endpoint", "expected", "actual", "classification", "verdict"]
VISIBILITY_HEADER = ["operation_id", "pk", "operation", "batch_id", "commit_ts", "tail_durable_ts", "first_correct_search_ts", "visible_latency_ms", "timeout_seconds", "verdict"]
SCORE_ORACLE_HEADER = ["ts_ns", "event_id", "query_id", "endpoint", "oracle_epoch", "rows", "verdict", "reason"]


def verifier(args: argparse.Namespace) -> int:
    if args.event:
        return event_snapshot(args)
    db_name = env("FT2_DATABASE")
    deadline_ns = int(env("FT2_DEADLINE_NS"))
    ledger = Ledger()
    correctness = ARTIFACTS / "correctness.tsv"
    visibility = ARTIFACTS / "visibility.tsv"
    try:
        while not STOP.exists() and not FAILURE.exists():
            pending = ledger.pending_verification()
            if not pending:
                if now_ns() >= deadline_ns:
                    break
                time.sleep(1)
                continue
            for row in pending:
                op_id, op, pk, version, token, previous, commit_ts, tail_before, generation_before, expected, batch_id = row
                timeout = env_int("VISIBILITY_TIMEOUT_BATCH_SECONDS", 600) if str(batch_id).startswith("batch-") else env_int("VISIBILITY_TIMEOUT_SINGLE_SECONDS", 120)
                deadline = time.monotonic() + timeout
                last_class = "lost"
                tail_ts = 0
                first_correct_ts = 0
                actual_summary = ""
                passed = False
                while time.monotonic() < deadline and not STOP.exists() and not FAILURE.exists():
                    endpoints = read_endpoints()
                    endpoint_results: dict[str, list[int]] = {}
                    for name, host in endpoints:
                        endpoint_results[name] = token_membership(SQLClient(host, db_name), db_name, token)
                    base_rows = SQLClient(database=db_name).query(
                        f"SELECT body FROM {safe_ident(db_name)}.`documents` WHERE id=%s", (pk,)
                    )
                    body = str(base_rows[0][0]) if base_rows else None
                    expected_present = expected == "present"
                    base_ok = (body is not None and token in body) if expected_present else body is None
                    token_ok = all(values == [pk] for values in endpoint_results.values()) if expected_present else all(not values for values in endpoint_results.values())
                    stale = False
                    if previous:
                        stale = any(token_membership(SQLClient(host, db_name), db_name, previous) for _, host in endpoints)
                    duplicates = any(len(values) != len(set(values)) or (expected_present and any(value != pk for value in values)) for values in endpoint_results.values())
                    if duplicates:
                        last_class = "duplicate"
                    elif stale:
                        last_class = "stale"
                    elif not expected_present and any(endpoint_results.values()):
                        last_class = "phantom"
                    elif expected_present and not token_ok:
                        last_class = "lost"
                    elif not base_ok:
                        last_class = "base_state_mismatch"
                    else:
                        passed = True
                    observed_tail_chunk, observed_generation = tail_observation(SQLClient(database=db_name), db_name)
                    durable = observed_tail_chunk > int(tail_before) or observed_generation > int(generation_before)
                    observed_now = now_ns()
                    if tail_ts == 0 and durable:
                        tail_ts = observed_now
                    if passed and first_correct_ts == 0:
                        first_correct_ts = observed_now
                    actual_summary = json.dumps(endpoint_results, sort_keys=True, separators=(",", ":"))
                    if passed and (op == "rollback" or tail_ts > 0):
                        break
                    if passed:
                        last_class = "tail_durable_wait"
                    time.sleep(1)
                observed = first_correct_ts or now_ns()
                if passed and op != "rollback" and tail_ts == 0:
                    passed = False
                    last_class = "tail_durable_timeout"
                verdict = "PASS" if passed else "FAIL"
                append_row(visibility, VISIBILITY_HEADER, [op_id, pk, op, batch_id, commit_ts, tail_ts, first_correct_ts, f"{(observed-int(commit_ts))/1_000_000:.3f}", timeout, verdict])
                append_row(correctness, CORRECTNESS_HEADER, [observed, "mutation_visibility", "", op_id, pk, "all", expected, actual_summary, "none" if passed else last_class, verdict])
                ledger.mark_verified(int(op_id), verdict)
                if not passed:
                    fail(last_class, f"operation {op_id} did not reach correct search state", operation_id=op_id, actual=actual_summary)
                    return 1
    finally:
        ledger.export(ARTIFACTS / "mutation-ledger.tsv")
        ledger.close()
        (RUNTIME / "verifier-drained").touch()
    return 1 if FAILURE.exists() else 0


def maintenance(args: argparse.Namespace) -> int:
    db_name = env("FT2_DATABASE")
    client = SQLClient(database=db_name)
    if args.action == "merge":
        client.query(f"ALTER TABLE {safe_ident(db_name)}.`documents` ALTER REINDEX ft_body FULLTEXT2 MERGE FORCE_SYNC")
    elif args.action == "rebuild":
        client.query(f"ALTER TABLE {safe_ident(db_name)}.`documents` ALTER REINDEX ft_body FULLTEXT2 FORCE_SYNC")
    elif args.action == "drop-create":
        client.query(f"DROP INDEX ft_body ON {safe_ident(db_name)}.`documents`")
        parser = env("FULLTEXT2_PARSER", "gojieba")
        client.query(f"CREATE FULLTEXT2 INDEX ft_body ON {safe_ident(db_name)}.`documents`(body) WITH PARSER {parser}")
    else:  # pragma: no cover
        raise AssertionError(args.action)
    return 0


def wait_index_ready(args: argparse.Namespace) -> int:
    """Wait for catalog/tag-0 readiness and a correct first query on every CN."""
    db_name = env("FT2_DATABASE")
    timeout = max(1, int(args.timeout_seconds or env_int("INDEX_READY_TIMEOUT_SECONDS", 7200)))
    pack = load_pack()
    deadline = time.monotonic() + timeout
    client = SQLClient(database=db_name)
    index_ready_ns = 0
    config: dict[str, str] = {}
    while time.monotonic() < deadline:
        try:
            rows = client.query(
                "SELECT index_table_name,algo_table_type FROM mo_catalog.mo_indexes WHERE name='ft_body' AND algo='fulltext2' "
                "AND table_id IN (SELECT rel_id FROM mo_catalog.mo_tables WHERE reldatabase=%s AND relname='documents')",
                (db_name,),
            )
            by_type = {str(table_type): str(name) for name, table_type in rows}
            if "ftv2_index" in by_type and "ftv2_meta" in by_type:
                config = {"storage_table": by_type["ftv2_index"], "metadata_table": by_type["ftv2_meta"]}
                store = safe_ident(config["storage_table"])
                ready = client.query(f"SELECT COUNT(*) FROM {safe_ident(db_name)}.{store} WHERE tag=0")
                if int(ready[0][0]) > 0:
                    index_ready_ns = now_ns()
                    atomic_json(INDEX_CONFIG, {**(json.loads(INDEX_CONFIG.read_text()) if INDEX_CONFIG.exists() else {}), **config})
                    break
        except Exception:
            pass
        time.sleep(min(2.0, max(0.1, float(os.environ.get("SQL_READY_RETRY_SECONDS", "2")))))
    if not index_ready_ns:
        raise RuntimeError(f"FULLTEXT2 catalog/tag0 readiness timeout after {timeout}s")
    first_correct: dict[str, int] = {}
    endpoints = read_endpoints()
    while time.monotonic() < deadline and len(first_correct) < len(endpoints):
        for endpoint, host in endpoints:
            if endpoint in first_correct:
                continue
            try:
                with contextlib.closing(SQLClient(host, db_name).connect()) as conn:
                    ok = True
                    for case in pack:
                        ids = query_ranked(conn, db_name, case)
                        if len(ids) != case.expected_count or sha256_lines(ids) != case.expected_sha256:
                            ok = False
                            break
                    if ok:
                        first_correct[endpoint] = now_ns()
            except Exception:
                continue
        if len(first_correct) < len(endpoints):
            time.sleep(min(2.0, max(0.1, float(os.environ.get("SQL_READY_RETRY_SECONDS", "2")))))
    if len(first_correct) < len(endpoints):
        missing = sorted(set(name for name, _ in endpoints) - set(first_correct))
        raise RuntimeError(f"first correct query timeout for endpoints: {missing}")
    first_correct_ns = max(first_correct.values())
    result = {
        "schema_version": 1,
        "action": "wait-index-ready",
        "ddl_returned_at_ns": int(args.ddl_returned_at_ns or 0),
        "index_ready_at_ns": index_ready_ns,
        "first_correct_search_ts": first_correct_ns,
        "endpoints": {name: {"first_correct_search_ts": ts} for name, ts in sorted(first_correct.items())},
        "timeout_seconds": timeout,
        "observed_at_ns": now_ns(),
    }
    atomic_json(Path(args.output), result)
    return 0


def export_ledger(_: argparse.Namespace) -> int:
    ledger = Ledger()
    try:
        ledger.export(ARTIFACTS / "mutation-ledger.tsv")
    finally:
        ledger.close()
    return 0


def ledger_pending(_: argparse.Namespace) -> int:
    ledger = Ledger()
    try:
        count = int(
            ledger.db.execute(
                "SELECT COUNT(*) FROM operations WHERE status='planned' OR (status IN ('committed','rolled_back') AND verified=0)"
            ).fetchone()[0]
        )
        print(count)
    finally:
        ledger.close()
    return 0


def event_snapshot(args: argparse.Namespace) -> int:
    if not args.event_id or not args.output:
        raise RuntimeError("--event-id and --output are required for an event snapshot")
    db_name = env("FT2_DATABASE")
    pack = load_pack()
    ledger = Ledger()
    canonical: dict[str, Any] = {"event": args.event, "event_id": args.event_id, "pack": {}, "ledger": {}}
    correctness = ARTIFACTS / "correctness.tsv"
    score_events = ARTIFACTS / "score-oracle-events.tsv"
    score_document = load_score_oracle(required=os.environ.get("FT2_SCORE_ORACLE_REQUIRED", "0") == "1")
    try:
        for endpoint, host in read_endpoints():
            client = SQLClient(host, db_name)
            with contextlib.closing(client.connect()) as conn:
                for case in pack:
                    scored = query_ranked_scores(conn, db_name, case)
                    values = [pk for pk, _ in scored]
                    digest = sha256_lines(values)
                    verdict = len(values) == case.expected_count and digest == case.expected_sha256
                    canonical["pack"].setdefault(case.query_id, {})[endpoint] = {"count": len(values), "sha256": digest}
                    append_row(correctness, CORRECTNESS_HEADER, [now_ns(), "event_pack_membership", args.event_id, "", "", endpoint, f"{case.expected_count}:{case.expected_sha256}", f"{len(values)}:{digest}", "none" if verdict else "membership_mismatch", "PASS" if verdict else "FAIL"])
                    if not verdict:
                        fail("membership_mismatch", f"query pack mismatch at {args.event_id}", query_id=case.query_id, endpoint=endpoint)
                        return 1
                    score_ok, score_reason = check_score_oracle(score_document, case, scored)
                    score_verdict = "PASS" if score_ok else "UNAVAILABLE_EPOCH" if score_reason.startswith("deferred") else "FAIL"
                    append_row(score_events, SCORE_ORACLE_HEADER, [now_ns(), args.event_id, case.query_id, endpoint, score_document.get("oracle_epoch", "") if score_document else "", len(scored), score_verdict, score_reason])
                    if not score_ok:
                        failure_class = "score_oracle_epoch" if score_verdict == "UNAVAILABLE_EPOCH" else "score_bits_mismatch"
                        fail(failure_class, f"score oracle comparison unavailable or mismatched at {args.event_id}", query_id=case.query_id, endpoint=endpoint, reason=score_reason)
                        return 1
        for pk, version, token, alive in ledger.all_entities():
            endpoint_values = {
                endpoint: token_membership(SQLClient(host, db_name), db_name, token)
                for endpoint, host in read_endpoints()
            }
            expected = [pk] if alive else []
            verdict = all(values == expected for values in endpoint_values.values())
            canonical["ledger"][str(pk)] = {"version": version, "token": token, "alive": bool(alive), "endpoints": endpoint_values}
            append_row(correctness, CORRECTNESS_HEADER, [now_ns(), "event_ledger_membership", args.event_id, "", pk, "all", json.dumps(expected), json.dumps(endpoint_values, sort_keys=True), "none" if verdict else "membership_mismatch", "PASS" if verdict else "FAIL"])
            if not verdict:
                fail("membership_mismatch", f"ledger sample mismatch at {args.event_id}", pk=pk)
                return 1
        digest_payload = json.dumps({"pack": canonical["pack"], "ledger": canonical["ledger"]}, sort_keys=True, separators=(",", ":")).encode()
        canonical["membership_sha256"] = hashlib.sha256(digest_payload).hexdigest()
        canonical["observed_at_ns"] = now_ns()
        atomic_json(Path(args.output), canonical)
        return 0
    finally:
        ledger.close()


def setup(_: argparse.Namespace) -> int:
    db_name = env("FT2_DATABASE")
    expected_commit = env("MATRIXONE_COMMIT")
    expected_rows = env_int("CORPUS_EXPECTED_ROWS", 2_303_643)
    corpus = Path(env("FT2_CORPUS_LOCAL"))
    score_document = load_score_oracle(required=os.environ.get("FT2_SCORE_ORACLE_REQUIRED", "0") == "1" and os.environ.get("FT2_CONTRACT_TEST", "0") != "1")
    client = SQLClient()
    readiness = client.wait_ready()
    atomic_json(RUNTIME / "sql-readiness.json", readiness)
    atomic_json(ARTIFACTS / "sql-readiness.json", readiness)
    version_rows = client.query("SELECT git_version()")
    version = str(version_rows[0][0]) if version_rows else ""
    if expected_commit not in version:
        raise RuntimeError(f"MatrixOne git_version does not contain exact commit {expected_commit}: {version!r}")
    client.query(f"CREATE DATABASE IF NOT EXISTS {safe_ident(db_name)}")
    db_client = SQLClient(database=db_name)
    db_client.query(f"CREATE TABLE IF NOT EXISTS {safe_ident(db_name)}.`documents` (id BIGINT PRIMARY KEY, body TEXT)")
    count = int(db_client.query(f"SELECT COUNT(*) FROM {safe_ident(db_name)}.`documents`")[0][0])
    if count == 0:
        if not corpus.is_file():
            raise RuntimeError(f"verified corpus is missing: {corpus}")
        escaped = str(corpus).replace("\\", "\\\\").replace("'", "''")
        db_client.query(
            f"LOAD DATA LOCAL INFILE '{escaped}' INTO TABLE {safe_ident(db_name)}.`documents` "
            "FIELDS TERMINATED BY '\\t' ESCAPED BY '\\\\' LINES TERMINATED BY '\\n' (id,body)"
        )
        count = int(db_client.query(f"SELECT COUNT(*) FROM {safe_ident(db_name)}.`documents`")[0][0])
    if count != expected_rows:
        raise RuntimeError(f"corpus row count mismatch: expected {expected_rows}, got {count}")
    index_rows = db_client.query(
        "SELECT COUNT(*) FROM mo_catalog.mo_indexes WHERE name='ft_body' AND algo='fulltext2' "
        "AND table_id IN (SELECT rel_id FROM mo_catalog.mo_tables WHERE reldatabase=%s AND relname='documents')",
        (db_name,),
    )
    ddl_returned_at_ns = now_ns()
    if int(index_rows[0][0]) == 0:
        parser = env("FULLTEXT2_PARSER", "gojieba")
        if parser not in {"ngram", "gojieba"}:
            raise RuntimeError("FULLTEXT2_PARSER must be ngram or gojieba")
        db_client.query(
            f"CREATE FULLTEXT2 INDEX ft_body ON {safe_ident(db_name)}.`documents`(body) WITH PARSER {parser}"
        )
        ddl_returned_at_ns = now_ns()
        ddl_action = "create"
    else:
        ddl_action = "existing"
    atomic_json(
        RUNTIME / "initial-ddl.json",
        {"action": ddl_action, "ddl_returned_at_ns": ddl_returned_at_ns, "observed_at_ns": now_ns()},
    )
    deadline = time.monotonic() + env_int("INDEX_READY_TIMEOUT_SECONDS", 7200)
    config: dict[str, str] = {}
    while time.monotonic() < deadline:
        rows = db_client.query(
            "SELECT index_table_name,algo_table_type FROM mo_catalog.mo_indexes WHERE name='ft_body' AND algo='fulltext2' "
            "AND table_id IN (SELECT rel_id FROM mo_catalog.mo_tables WHERE reldatabase=%s AND relname='documents')",
            (db_name,),
        )
        by_type = {str(table_type): str(name) for name, table_type in rows}
        if "ftv2_index" in by_type and "ftv2_meta" in by_type:
            config = {"storage_table": by_type["ftv2_index"], "metadata_table": by_type["ftv2_meta"]}
            storage = safe_ident(config["storage_table"])
            ready = db_client.query(
                f"SELECT COUNT(*) FROM {safe_ident(db_name)}.{storage} WHERE tag=0"
            )
            if int(ready[0][0]) > 0:
                break
        time.sleep(2)
    else:
        raise RuntimeError("FULLTEXT2 initial base readiness timeout")
    ledger = Ledger()
    try:
        seed_target = env_int("CORPUS_LEDGER_SAMPLE_SIZE", 32)
        if seed_target < 1:
            raise RuntimeError("CORPUS_LEDGER_SAMPLE_SIZE must be at least 1 for real-corpus DML coverage")
        if score_document is None:
            raise RuntimeError("independent score oracle is required before selecting the mutation reservoir")
        seeded = seed_oracle_entities(db_client, db_name, score_document, ledger, seed_target)
    finally:
        ledger.close()
    config.update(
        {
            "database": db_name,
            "index": "ft_body",
            "row_count": str(count),
            "matrixone_commit": expected_commit,
            "corpus_ledger_seeded": str(seeded),
            "score_oracle_epoch": score_document.get("oracle_epoch", "") if score_document else "unavailable",
        }
    )
    atomic_json(INDEX_CONFIG, config)
    return 0


STORAGE_HEADER = ["ts_ns", "tag0_segments", "tag0_chunks", "tag0_bytes", "tag1_chunks", "tag1_bytes", "generation", "tail_chunk", "tail_observed_at_ns", "tail_progress_age_seconds", "ledger_pending_count", "ledger_pending_max_age_seconds", "object_count", "object_bytes", "object_p50_bytes", "object_p95_bytes", "object_max_bytes", "delete_frame_count", "sample_status"]
RESOURCE_HEADER = ["ts_ns", "pod", "component", "cpu_mcores", "rss_bytes", "working_set_bytes", "proc_rss_bytes", "gc_pause_seconds", "gc_pause_delta_seconds", "io_read_bytes", "io_write_bytes", "minor_faults", "major_faults", "network_rx_bytes", "network_tx_bytes", "restarts", "noise", "sample_status"]


def parse_cpu(value: str) -> int:
    return int(value[:-1]) if value.endswith("m") else int(float(value) * 1000)


def parse_memory(value: str) -> int:
    units = {"Ki": 1024, "Mi": 1024**2, "Gi": 1024**3, "K": 1000, "M": 1000**2, "G": 1000**3}
    for suffix, factor in units.items():
        if value.endswith(suffix):
            return int(float(value[: -len(suffix)]) * factor)
    return int(value)


def kubectl(*args: str, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run([os.environ.get("KUBECTL_BIN", "kubectl"), *args], text=True, capture_output=True, check=check)


def verify_node_pool_placement(snapshot: Mapping[str, Any]) -> None:
    """Prove workload pods carry the scheduler-enforced node-pool selector.

    The controller service account is namespace-scoped.  A Node object is
    cluster-scoped, so reading ``kubectl get node`` here would make every real
    collector iteration fail with Forbidden.  The rendered MatrixOne and
    harness pod specs carry an exact ``nodeSelector``; once a pod has an
    assigned node, that selector is the namespace-visible evidence that the
    scheduler enforced the declared placement.  The artifact records this
    evidence explicitly instead of claiming to have inspected Node labels.
    """
    selector = os.environ.get("TKE_NODE_POOL", "")
    if "=" not in selector:
        fail("isolation_placement", "TKE_NODE_POOL must be an exact key=value selector")
        return
    key, expected = selector.split("=", 1)
    if not key or not expected:
        fail("isolation_placement", "TKE_NODE_POOL selector is empty")
        return
    placements: list[dict[str, Any]] = []
    for item in snapshot.get("items", []):
        metadata = item.get("metadata", {})
        name = str(metadata.get("name", ""))
        if not (name.startswith("ft2-mo") or name.startswith("ft2-controller")):
            continue
        node = str(item.get("spec", {}).get("nodeName", ""))
        if not node:
            fail("isolation_placement", f"pod {name} has no assigned node")
            continue
        pod_selector = item.get("spec", {}).get("nodeSelector", {})
        actual = str(pod_selector.get(key, "")) if isinstance(pod_selector, Mapping) else ""
        row = {
            "pod": name,
            "node": node,
            "selector": selector,
            "pod_node_selector": f"{key}={actual}",
            "placement_evidence": "pod_spec_node_selector",
        }
        placements.append(row)
        if actual != expected:
            fail(
                "isolation_placement",
                f"pod {name} has nodeSelector {key}={actual!r}, expected {expected!r}",
            )
    if not placements:
        fail("isolation_placement", "no owned workload pod placement was observed")
        return
    isolation_path = ARTIFACTS / "isolation.json"
    value: dict[str, Any] = {}
    if isolation_path.exists():
        with contextlib.suppress(json.JSONDecodeError, OSError):
            value = json.loads(isolation_path.read_text())
    value.update(
        {
            "node_selector": selector,
            "pod_placements": placements,
            "placement_evidence": "pod_spec_node_selector",
            "placement_verified": not bool(FAILURE.exists()),
            "placement_observed_at_ns": now_ns(),
        }
    )
    atomic_json(isolation_path, value)


def object_summary() -> tuple[int, int, int, int, int, str]:
    bucket = os.environ.get("MO_SHARED_BUCKET", "")
    prefix = os.environ.get("MO_DATA_PREFIX", os.environ.get("MO_SHARED_PREFIX", ""))
    endpoint = os.environ.get("COS_ENDPOINT", "")
    if not bucket or not prefix or not endpoint:
        return -1, -1, -1, -1, -1, "unavailable"
    proc = subprocess.run(
        ["aws", "--endpoint-url", endpoint, "s3", "ls", f"s3://{bucket}/{prefix.strip('/')}/", "--recursive"],
        text=True,
        capture_output=True,
    )
    if proc.returncode:
        return -1, -1, -1, -1, -1, "error"
    count = 0
    total = 0
    sizes: list[int] = []
    for line in proc.stdout.splitlines():
        fields = line.split(maxsplit=3)
        if len(fields) >= 4 and fields[2].isdigit():
            count += 1
            size = int(fields[2])
            total += size
            sizes.append(size)
    sizes.sort()
    pick = lambda fraction: sizes[min(len(sizes) - 1, int((len(sizes) - 1) * fraction))] if sizes else -1
    return count, total, pick(.50), pick(.95), pick(1.0), "ok"


def storage_sample(client: SQLClient, db_name: str, object_count: int, object_bytes: int, object_p50: int, object_p95: int, object_max: int, object_status: str) -> list[Any]:
    cfg = json.loads(INDEX_CONFIG.read_text())
    store = safe_ident(cfg["storage_table"])
    meta = safe_ident(cfg["metadata_table"])
    rows = client.query(
        f"SELECT tag,COUNT(DISTINCT index_id),COUNT(*),COALESCE(SUM(LENGTH(data)),0),COALESCE(MAX(chunk_id),-1) "
        f"FROM {safe_ident(db_name)}.{store} GROUP BY tag"
    )
    by_tag = {int(tag): (int(segments), int(chunks), int(size), int(max_chunk)) for tag, segments, chunks, size, max_chunk in rows}
    meta_rows = client.query(f"SELECT COALESCE(MAX(timestamp),0) FROM {safe_ident(db_name)}.{meta}")
    generation = int(meta_rows[0][0]) if meta_rows else 0
    tag0 = by_tag.get(0, (0, 0, 0, -1))
    tag1 = by_tag.get(1, (0, 0, 0, -1))
    sample_ts = now_ns()
    tail_state_path = RUNTIME / "tail-progress.json"
    previous: dict[str, Any] = {}
    with contextlib.suppress(Exception):
        previous = json.loads(tail_state_path.read_text())
    tail_state = tail_progress_state(previous, tag1[3], generation, sample_ts)
    atomic_json(tail_state_path, tail_state)
    tail_observed_ts = tail_state["changed_at_ns"]
    tail_age = (sample_ts - tail_observed_ts) / 1e9 if tail_observed_ts else -1
    pending_count = 0
    pending_age = 0.0
    with contextlib.suppress(Exception):
        ledger = Ledger()
        try:
            row = ledger.db.execute("SELECT COUNT(*),COALESCE(MIN(planned_ts_ns),0) FROM operations WHERE status='planned' OR (status IN ('committed','rolled_back') AND verified=0)").fetchone()
            pending_count = int(row[0])
            pending_age = max(0.0, (sample_ts - int(row[1])) / 1e9) if row[1] else 0.0
        finally:
            ledger.close()
    return [sample_ts, tag0[0], tag0[1], tag0[2], tag1[1], tag1[2], generation, tag1[3], tail_observed_ts, f"{tail_age:.3f}", pending_count, f"{pending_age:.3f}", object_count, object_bytes, object_p50, object_p95, object_max, "UNAVAILABLE_NO_STABLE_API", object_status]


def proc_metrics(pod: str) -> tuple[int, int, int, int, int, int, int, str]:
    command = "awk '{print $10,$12,$14,$15,$24}' /proc/1/stat; awk '/read_bytes|write_bytes/{print $2}' /proc/1/io; awk 'NR>2 {rx += $2; tx += $10} END {print rx+0,tx+0}' /proc/1/net/dev"
    proc = kubectl("-n", env("FT2_NAMESPACE"), "exec", pod, "--", "sh", "-c", command, check=False)
    if proc.returncode:
        return 0, 0, 0, 0, 0, 0, 0, "unavailable"
    values = [int(value) for value in proc.stdout.split() if value.isdigit()]
    if len(values) < 7:
        return 0, 0, 0, 0, 0, 0, 0, "unavailable"
    minor, major, utime, stime, rss_pages, read_bytes, write_bytes = values[:7]
    rx_bytes, tx_bytes = values[7:9] if len(values) >= 9 else (0, 0)
    return rss_pages * os.sysconf("SC_PAGE_SIZE"), read_bytes, write_bytes, minor, major, rx_bytes, tx_bytes, "ok"


def gc_pause(pod_ip: str) -> float:
    if not pod_ip:
        return -1.0
    try:
        with urllib.request.urlopen(f"http://{pod_ip}:6060/metrics", timeout=2) as response:
            text = response.read().decode(errors="replace")
        values = [float(match.group(1)) for match in re.finditer(r"^go_gc_duration_seconds_sum\s+([0-9.eE+-]+)$", text, re.M)]
        return values[-1] if values else -1.0
    except Exception:
        return -1.0


def collector(_: argparse.Namespace) -> int:
    db_name = env("FT2_DATABASE")
    deadline_ns = int(env("FT2_DEADLINE_NS"))
    interval = max(1, env_int("COLLECT_INTERVAL_SECONDS", 300))
    object_interval = max(interval, env_int("OBJECT_SAMPLE_INTERVAL_SECONDS", 900))
    client = SQLClient(database=db_name)
    storage_path = ARTIFACTS / "storage-windows.tsv"
    resource_path = ARTIFACTS / "resource-samples.tsv"
    pod_jsonl = STATE / "pod-events.jsonl"
    last_object = 0.0
    objects = (-1, -1, -1, -1, -1, "unavailable")
    previous_restarts: dict[str, int] = {}
    previous_gc: dict[str, float] = {}
    previous_storage: tuple[int, int, int, int] | None = None
    auto_merge_sequence = 0
    while now_ns() < deadline_ns and not STOP.exists() and not FAILURE.exists():
        start = time.monotonic()
        if start - last_object >= object_interval:
            objects = object_summary()
            last_object = start
        try:
            storage_row = storage_sample(client, db_name, *objects)
            if previous_storage is not None:
                previous_generation, previous_tag0_chunks, previous_tag1_bytes, previous_ts = previous_storage
                generation, tag0_chunks, tag1_bytes = int(storage_row[6]), int(storage_row[2]), int(storage_row[5])
                if tag0_chunks >= 0 and tag0_chunks != previous_tag0_chunks and tag1_bytes >= 0 and tag1_bytes <= previous_tag1_bytes:
                    auto_merge_sequence += 1
                    event_ts = int(storage_row[0])
                    auto_event = [
                        f"auto-merge-{auto_merge_sequence}", "auto-merge", "observed", event_ts, event_ts, 0,
                        event_ts, event_ts, event_ts, "", "", "OBSERVED",
                    ]
                    append_row(ARTIFACTS / "merge-events.tsv", ["event_id", "event_type", "strategy", "start_ts_ns", "end_ts_ns", "downtime_ms", "ddl_returned_ts_ns", "index_ready_ts_ns", "first_correct_search_ts_ns", "before_sha256", "after_sha256", "verdict"], auto_event)
                previous_storage = (generation, tag0_chunks, tag1_bytes, int(storage_row[0]))
            else:
                previous_storage = (int(storage_row[6]), int(storage_row[2]), int(storage_row[5]), int(storage_row[0]))
            append_row(storage_path, STORAGE_HEADER, storage_row)
        except Exception as exc:
            append_row(storage_path, STORAGE_HEADER, [now_ns(), -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, *objects[:5], "UNAVAILABLE_NO_STABLE_API", f"sql_error:{type(exc).__name__}"])
        pods_proc = kubectl("-n", env("FT2_NAMESPACE"), "get", "pods", "-o", "json", check=False)
        if pods_proc.returncode:
            fail("kubernetes_unreachable", "collector cannot list namespace pods", stderr=pods_proc.stderr[-500:])
            return 1
        snapshot = json.loads(pods_proc.stdout)
        with pod_jsonl.open("a") as handle:
            handle.write(json.dumps({"observed_at_ns": now_ns(), "items": snapshot.get("items", [])}, separators=(",", ":")) + "\n")
        if os.environ.get("FT2_SKIP_K8S", "0") != "1":
            verify_node_pool_placement(snapshot)
            if FAILURE.exists():
                return 1
        top_proc = kubectl("-n", env("FT2_NAMESPACE"), "top", "pods", "--no-headers", check=False)
        top: dict[str, tuple[int, int]] = {}
        if top_proc.returncode == 0:
            for line in top_proc.stdout.splitlines():
                fields = line.split()
                if len(fields) >= 3:
                    with contextlib.suppress(ValueError):
                        top[fields[0]] = (parse_cpu(fields[1]), parse_memory(fields[2]))
        metrics_api = top_proc.returncode == 0 and bool(top)
        noise = os.environ.get("SHARED_HOST_NOISE", "unknown")
        atomic_json(RUNTIME / "collector-status.json", {"observed_at_ns": now_ns(), "noise": noise, "metrics_api": metrics_api, "metrics_pods": sorted(top)})
        (RUNTIME / "noise-status").write_text(noise + "\n")
        for item in snapshot.get("items", []):
            meta = item.get("metadata", {})
            status = item.get("status", {})
            name = meta.get("name", "")
            component = meta.get("labels", {}).get("matrixorigin.io/component", "unknown")
            if not name.startswith("ft2-mo"):
                continue
            containers = status.get("containerStatuses", [])
            restarts = sum(int(value.get("restartCount", 0)) for value in containers)
            previous = previous_restarts.get(name, 0)
            reasons = [
                value.get("state", {}).get("terminated", {}).get("reason", "")
                for value in containers
            ] + [
                value.get("lastState", {}).get("terminated", {}).get("reason", "")
                for value in containers
            ]
            waiting_reasons = [value.get("state", {}).get("waiting", {}).get("reason", "") for value in containers]
            planned_restart = ""
            marker = RUNTIME / "planned-restart.json"
            if marker.exists():
                with contextlib.suppress(Exception):
                    planned_restart = str(json.loads(marker.read_text()).get("pod", ""))
            if name != planned_restart and (
                "OOMKilled" in reasons
                or restarts > previous
                or status.get("phase") == "Failed"
                or any(reason in {"CrashLoopBackOff", "Error"} for reason in waiting_reasons)
            ):
                fail("pod_crash", f"product pod {name} restarted, OOMed, or crash-looped", reasons=reasons + waiting_reasons, restarts=restarts, previous=previous, phase=status.get("phase"))
                return 1
            previous_restarts[name] = restarts
            rss_proc, read_bytes, write_bytes, minor, major, rx_bytes, tx_bytes, proc_status = proc_metrics(name)
            cpu, rss_top = top.get(name, (-1, -1))
            sample_status = "metrics_api" if name in top and cpu >= 0 and rss_top >= 0 else "proc_fallback" if proc_status == "ok" else "unavailable"
            gc_total = gc_pause(status.get('podIP',''))
            previous = previous_gc.get(name, gc_total)
            gc_delta = max(0.0, gc_total - previous) if gc_total >= 0 and previous >= 0 else -1.0
            previous_gc[name] = gc_total
            append_row(resource_path, RESOURCE_HEADER, [now_ns(), name, component, cpu, rss_proc if proc_status == "ok" else -1, rss_top, rss_proc if proc_status == "ok" else -1, f"{gc_total:.6f}", f"{gc_delta:.6f}", read_bytes, write_bytes, minor, major, rx_bytes, tx_bytes, restarts, noise, sample_status])
        elapsed = time.monotonic() - start
        time.sleep(max(0.2, interval - elapsed))
    return 1 if FAILURE.exists() else 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup")
    sub.add_parser("writer")
    sub.add_parser("reader")
    verify = sub.add_parser("verifier")
    verify.add_argument("--event", choices=["before-merge", "after-merge", "before-rebuild", "after-rebuild", "before-restart", "after-restart"])
    verify.add_argument("--event-id")
    verify.add_argument("--output")
    sub.add_parser("collector")
    sub.add_parser("export-ledger")
    sub.add_parser("ledger-pending")
    maintenance_parser = sub.add_parser("maintenance")
    maintenance_parser.add_argument("--action", required=True, choices=["merge", "rebuild", "drop-create"])
    ready = sub.add_parser("wait-index-ready")
    ready.add_argument("--output", required=True)
    ready.add_argument("--ddl-returned-at-ns", type=int, default=0)
    ready.add_argument("--timeout-seconds", type=int, default=0)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    RUNTIME.mkdir(parents=True, exist_ok=True)
    handlers = {"setup": setup, "writer": writer, "reader": reader, "verifier": verifier, "collector": collector, "maintenance": maintenance, "wait-index-ready": wait_index_ready, "export-ledger": export_ledger, "ledger-pending": ledger_pending}
    try:
        return handlers[args.command](args)
    except Exception as exc:
        fail(f"{args.command}_exception", str(exc), exception=type(exc).__name__)
        print(f"{args.command}: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
