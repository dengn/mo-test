import unittest
import sys
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch

from script import test_vector_index_auto_update as driver


class VectorIndexAutoUpdateContractTest(unittest.TestCase):
    def test_database_fixture_uses_supported_collation_and_preserves_errors(self):
        test = driver.VectorIndexTest(database="anli_update_contract")
        test.cursor, test.conn = Mock(), Mock()
        test.create_database()
        test.cursor.execute.assert_called_once_with(
            "CREATE DATABASE IF NOT EXISTS anli_update_contract "
            "CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;"
        )
        test.conn.commit.assert_called_once_with()
        test.conn.reset_mock()
        test.cursor.execute.side_effect = RuntimeError("DDL rejected")
        with self.assertRaisesRegex(RuntimeError, "DDL rejected"):
            test.create_database()
        test.conn.commit.assert_not_called()

    def test_direct_script_import_path_and_audit_seed_option(self):
        script = Path(driver.__file__)
        result = subprocess.run([sys.executable, str(script), "--help"],
                                capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("--audit-seed", result.stdout)

    def test_terminal_audit_failure_fails_existing_workload(self):
        test = driver.VectorIndexTest()
        test.audit_expected = {17: [1.0] * test.dimension}
        results = {"before": {"avg": 1}, "after": {"avg": 1},
                   "operation": "UPDATE", "num_operations": 1,
                   "avg_change": 0, "avg_change_pct": 0}
        methods = ("connect", "create_database", "create_table", "insert_initial_data",
                   "create_ivf_index", "insert_audit_sentinels")
        with patch.object(test, "close"), patch.multiple(
            test, **{name: unittest.mock.DEFAULT for name in methods}
        ), patch.object(test, "test_insert_operation", return_value=results), patch.object(
            test, "test_update_operation", return_value=results
        ), patch.object(test, "test_delete_operation", return_value=results), patch.object(
            driver, "audit_active_entries", side_effect=RuntimeError("audit failed")
        ):
            self.assertFalse(test.run_all_tests())

    def test_insert_sentinels_have_independent_bounded_expectations(self):
        test = driver.VectorIndexTest()
        test.cursor, test.conn = Mock(), Mock()
        test.insert_audit_sentinels()
        sql, rows = test.cursor.executemany.call_args.args
        self.assertIn("(id, embedding) VALUES (%s, %s)", sql)
        self.assertEqual(len(rows), 8)
        self.assertEqual(test.audit_insert_ids, set(range(-8, 0)))
        self.assertEqual(set(test.audit_expected), test.audit_insert_ids)
        for key, value in rows:
            self.assertEqual(driver.json.loads(value), test.audit_expected[key])
            self.assertEqual(len(test.audit_expected[key]), test.dimension)
        test.conn.commit.assert_called_once_with()
        test.cursor.execute.assert_not_called()  # no database-derived expectation
        test.cursor.fetchall.assert_not_called()

    def test_insert_sentinel_failure_is_not_hidden_by_rollback(self):
        for stage in ("insert", "commit"):
            with self.subTest(stage=stage):
                test = driver.VectorIndexTest()
                test.cursor, test.conn = Mock(), Mock()
                failing_call = test.cursor.executemany if stage == "insert" else test.conn.commit
                failing_call.side_effect = RuntimeError(f"first {stage} failure")
                test.conn.rollback.side_effect = RuntimeError("later rollback failure")
                with self.assertRaisesRegex(RuntimeError, f"first {stage} failure"):
                    test.insert_audit_sentinels()
                self.assertEqual(test.audit_expected, {})
                self.assertEqual(test.audit_insert_ids, set())
                test.conn.rollback.assert_called_once_with()

    def test_sentinels_run_after_timing_and_before_terminal_audit(self):
        test = driver.VectorIndexTest()
        calls = []
        result = {"operation": "test", "num_operations": 1, "avg_change": None}
        methods = ("connect", "create_database", "create_table", "insert_initial_data",
                   "create_ivf_index")
        def step(name):
            def invoke(**kwargs):
                calls.append(name)
                return result
            return invoke
        with patch.multiple(test, **{name: unittest.mock.DEFAULT for name in methods}), \
                patch.object(test, "test_insert_operation", side_effect=step("insert")), \
                patch.object(test, "test_update_operation", side_effect=step("update")), \
                patch.object(test, "test_delete_operation", side_effect=step("delete")), \
                patch.object(test, "insert_audit_sentinels", side_effect=step("sentinels")), \
                patch.object(driver, "audit_active_entries", side_effect=lambda *a, **k: calls.append("audit") or {}):
            self.assertTrue(test.run_all_tests())
        self.assertEqual(calls, ["insert", "update", "delete", "sentinels", "audit"])

    def test_existing_workload_failure_cannot_be_overwritten_by_sentinels(self):
        test = driver.VectorIndexTest()
        methods = ("connect", "create_database", "create_table", "insert_initial_data",
                   "create_ivf_index")
        with patch.multiple(test, **{name: unittest.mock.DEFAULT for name in methods}), \
                patch.object(test, "test_insert_operation", side_effect=RuntimeError("original workload failure")), \
                patch.object(test, "insert_audit_sentinels") as sentinels, \
                patch.object(driver, "audit_active_entries") as audit:
            self.assertFalse(test.run_all_tests())
        sentinels.assert_not_called()
        audit.assert_not_called()

    def test_driver_reports_setup_error_to_its_caller(self):
        test = driver.VectorIndexTest(connect_timeout=1)
        with patch.object(test, "connect", side_effect=RuntimeError("simulated connection loss")):
            self.assertFalse(test.run_all_tests())

    def test_cleanup_reports_missing_connection(self):
        test = driver.VectorIndexTest(connect_timeout=1)
        self.assertFalse(test.cleanup())

    def test_cli_propagates_workload_and_cleanup_status_in_order(self):
        cases = (
            # A failed workload must still run requested cleanup, then close.
            (False, True, 1),
            # A cleanup failure is also a terminal CLI failure.
            (True, False, 1),
            # Only a successful workload and cleanup may return normally.
            (True, True, 0),
        )

        for workload_ok, cleanup_ok, expected_exit in cases:
            calls = []

            class FakeVectorIndexTest:
                def __init__(self, **kwargs):
                    calls.append(("init", kwargs))

                def run_all_tests(self):
                    calls.append("run")
                    return workload_ok

                def cleanup(self):
                    calls.append("cleanup")
                    return cleanup_ok

                def close(self):
                    calls.append("close")

            argv = ["test_vector_index_auto_update.py", "--cleanup"]
            with patch.object(driver, "VectorIndexTest", FakeVectorIndexTest), patch.object(
                sys, "argv", argv
            ):
                if expected_exit:
                    with self.assertRaises(SystemExit) as raised:
                        driver.main()
                    self.assertEqual(raised.exception.code, expected_exit)
                else:
                    driver.main()

            self.assertEqual([call for call in calls if isinstance(call, str)],
                             ["run", "cleanup", "close"])


if __name__ == "__main__":
    unittest.main()
