---
slug: /guides/developer/lightweight-delete
title: 'Lightweight delete'
keywords: ['lightweight delete']
description: 'Provides an overview of lightweight deletes in ClickHouse'
doc_type: 'reference'
---

import Content from '@site/docs/sql-reference/statements/delete.md';

<Content />
