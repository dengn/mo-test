## 问题与影响

合法的双字段 Kafka JSON 对象，改变 SELECT 投影就改变读取正确性：严格模式下，选择第一数据列或只选择消息元数据报 20301；非严格模式下，只选择 `__mo_message_id` 会静默返回 NULL。全列读取和相同数据的 CSV 控制组正常。

消费程序经常只读取事件 ID 或消息位点；此问题会阻断消费，或使断点记录得到错误的 NULL。建议优先级 P1。这里是查询正确性缺陷，不能用关闭严格模式作为完整解决方案。

## 实际测试环境

- MatrixOne 本地源码构建 SHA `652c643666428f1c434e03369834f2a9bead7c27`；单节点，MySQL 协议端口 6001，MinIO 持久存储。没有声称已在最新 main 运行复现。
- Apache Kafka 3.9.1，单分区、单副本、KRaft，broker `127.0.0.1:19092`；Python kafka-python 2.2.15。
- 共享 Linux 环境限制 4 CPU / 16 GiB；本组测试期间未注入故障，MO 正常可连接。
- 每个格式使用 3 个独立的新 topic 和 group；每个 topic 只有一条合法消息，offset 为 0。
- JSON 消息原始字节：`{"event_id":"valid-event","delta":1}`；CSV 控制组：`valid-event,1`。

## 可复现过程

用 Kafka producer 创建单分区 topic 并写入一条消息，例如：

```python
from kafka import KafkaProducer
from kafka.admin import KafkaAdminClient, NewTopic

a = KafkaAdminClient(bootstrap_servers='127.0.0.1:19092', api_version=(3,0,0))
a.create_topics([NewTopic('repro-json-projection', 1, 1)])
p = KafkaProducer(bootstrap_servers='127.0.0.1:19092', api_version=(3,0,0), acks='all')
p.send('repro-json-projection', b'{"event_id":"valid-event","delta":1}').get(timeout=10)
p.close()
a.close()
```

连接 MatrixOne，在独立测试数据库中执行：

```sql
CREATE EXTERNAL TABLE repro_json_projection (
  event_id VARCHAR(96), delta BIGINT
) ENGINE=KAFKA WITH (
  'brokers'='127.0.0.1:19092',
  'topic'='repro-json-projection', 'partition'='0',
  'autocommit'='false', 'group'='repro-json-projection-group',
  'format'='jsonl'
);

SET SESSION sql_mode='STRICT_TRANS_TABLES';
SELECT * FROM repro_json_projection
WHERE __mo_read_start_id=-1 AND __mo_read_size=1 AND __mo_read_timeout=2;
-- 正常：('valid-event', 1)

SELECT event_id FROM repro_json_projection
WHERE __mo_read_start_id=-1 AND __mo_read_size=1 AND __mo_read_timeout=2;
-- 20301: invalid input: the data of row 1 contained is not equal to input columns

SELECT __mo_message_id FROM repro_json_projection
WHERE __mo_read_start_id=-1 AND __mo_read_size=1 AND __mo_read_timeout=2;
-- 同样 20301

SELECT delta FROM repro_json_projection
WHERE __mo_read_start_id=-1 AND __mo_read_size=1 AND __mo_read_timeout=2;
-- 正常：(1)

SELECT __mo_message_id,event_id,delta FROM repro_json_projection
WHERE __mo_read_start_id=-1 AND __mo_read_size=1 AND __mo_read_timeout=2;
-- 正常：(0, 'valid-event', 1)

SET SESSION sql_mode='';
SELECT __mo_message_id FROM repro_json_projection
WHERE __mo_read_start_id=-1 AND __mo_read_size=1 AND __mo_read_timeout=2;
-- 错误：(NULL)，预期是 (0)
```

注意：本例 `autocommit=false`，`start_id=-1` 才读最早消息；`start_id=0` 表示从 offset 1 开始。测试前曾误用 0 得到空结果，已排除该组，重新使用 -1、全新 topic/group 完成下述认证。`autocommit=true` 的另一组 offset 0 控制也已观察到相同投影异常。

## 完整结果（每种格式独立重复三次）

| 投影 | JSON 严格模式 | JSON 非严格模式 | CSV 两种模式 |
|---|---|---|---|
| `*` | 正确 | 正确 | 正确 |
| `event_id` | 20301 | 正确 | 正确 |
| `delta` | 正确 | 正确 | 正确 |
| `__mo_message_id` | 20301 | **NULL** | 正确 offset 0 |
| `__mo_message_id,event_id` | 20301 | 正确 | 正确 |
| `__mo_message_id,event_id,delta` | 正确 | 正确 | 正确 |

共 72 个 SELECT 控制与 6 个全字段 INSERT SELECT 控制；三个重复的模式完全一致。全字段 INSERT SELECT 对 JSON 与 CSV 都正确写入 `(0,'valid-event',1)`。没有非法 JSON、字段缺失、超时截断或消息重放。

## 源码定位线索（不是已经确认的补丁）

- `pkg/sql/colexec/external/reader_csv.go:transJsonObject2Lines` 根据已投影数据列的最大 `ColFieldIndex+1` 构造数组，并跳过 Kafka synthetic attrs；因此只选择第一列数组长 1，元数据投影数组长 0。
- `pkg/sql/compile/operator.go:externalColumnListLen` 保留外部表完整数据列数（本例 2）。
- `pkg/sql/colexec/external/external.go:checkLineValidRestrictive` 在 Kafka 路径比较数组长度与完整列数，从而误判合法记录。
- 同文件 `materializeOneRow` 的非严格短记录分支按字段索引补 NULL；元数据专用投影因此可能在调用元数据合成前就被补为 NULL。

预期修复：投影裁剪不能改变合法记录判断或 Kafka 元数据值；增加真实 planner→Kafka reader 的全列/子集/元数据、严格/非严格回归覆盖。

## 关联与区别

- 生态认证总单：https://github.com/matrixorigin/matrixone/issues/29848
- 已关闭的 JSONLine 文件投影缺陷：https://github.com/matrixorigin/matrixone/issues/26264 。该单是第三列及以后 `index out of range`；本例为 Kafka 两字段对象、第一列/元数据的 20301 与 NULL，应分别覆盖回归。
- 消费数据/位点认证：https://github.com/matrixorigin/matrixone/issues/27587 。本缺陷在没有显式 SQL 事务和没有后续失败语句时也复现，独立于该单的进度问题。
