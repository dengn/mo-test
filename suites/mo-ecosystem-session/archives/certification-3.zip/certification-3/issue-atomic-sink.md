## 需要的能力

提供 MatrixOne 可认证、可部署的 Kafka Connect / NiFi sink 配置或适配器，将稳定事件 ID 的去重账本、业务变更、数据库消费位点放在同一个 MO 事务里，并明确崩溃与提交回执不确定时的恢复协议。

这是原生集成能力请求。下面观察符合通用 at-least-once sink 的故障边界，**不能据此归因 MatrixOne ACID 实现有缺陷**；也不能用目标表主键唯一或最终快照相同认证非幂等业务效果 exactly-once。

## 实际环境

MatrixOne SHA `652c643666428f1c434e03369834f2a9bead7c27`，单节点持久存储；Kafka 3.9.1 / Debezium MySQL 与 JDBC 3.1.2.Final / NiFi 2.4.0 / Java 21 / MySQL 8.4.11 / kafka-python 2.2.15，全部本地合成数据。共享 4 CPU、16 GiB。不是最新 main / 多节点 / 生产容量认证。

## 反例 1：Kafka Connect 数据已提交而 group offset 未提交

1. MySQL 源创建 `eos_events(event_id BIGINT PRIMARY KEY,delta BIGINT,payload VARCHAR(100))`，Debezium 源产生独立单分区 topic。
2. MO 创建无主键 append 目标 `eos_native_append(event_id BIGINT,delta BIGINT,payload VARCHAR(100))`。
3. Debezium JDBC sink 配置 `insert.mode=insert,primary.key.mode=none,delete.enabled=false,schema.evolution=none`，目标预建；专用 distributed worker group，`offset.flush.interval.ms=60000`。
4. 仅一次插入事件 1..100，每个 delta=1。等待 MO 100 行可见，独立 KafkaConsumer 检查 topic end=100、sink group committed offset=NULL；REST offsets 为空。
5. 在此真实故障窗口 SIGKILL sink worker，保留同一 worker group/config/status/offset topic，重启；没有手动回拨 offset，没有新增源事件，也没有强杀 source worker。
6. 结果 MO **200 行 / 100 个不同 event_id**，每个 ID 恰好两份；Kafka topic end 仍为 100。因此重复出现在 sink replay。

专用 worker 已设置 `exactly.once.source.support=enabled`。MySQL source 配置验证 `exactly.once.support=required` 返回 connector 未实现 preflight 的错误；不能据此断言所有 source EOS 不可行，但更不能据此认证当前完整链路。Source EOS 开关也不会原子化 JDBC sink 的数据库提交和 Kafka offset 提交。

## 反例 2：NiFi 数据库 COMMIT 成功，但客户端收不到 ACK

1. 独立计数表 `nifi_eos_totals(id INT PRIMARY KEY,n BIGINT)` 初始化 `(1,0)`。
2. GenerateFlowFile 只 `RUN_ONCE` 一次，输出恰好一份 SQL：`UPDATE nifi_eos_totals SET n=n+1 WHERE id=1`。
3. PutSQL 经独立本地 TCP 故障代理连接 MO：batch=1、rollback-on-failure=true、penalty=2 秒；普通持续负载链路不走这个代理。
4. 代理只在读到 MO 对 COM_QUERY COMMIT 的成功 OK 包后，丢弃该包、关闭连接；持久化记录成功包 payload `0000001008000000`。此时直连 MO 查询计数为 1。
5. NiFi 回滚 FlowFile session 并重试，最终计数 **2**，queue=0；GenerateFlowFile output=1/taskCount=1，PutSQL taskCount=2。

故障不是“COMMIT 根本没有成功”，也不是人工生成两份 FlowFile。初版结果采集误用不存在的 processor status URL，随后改用 GET processor entity 的 status 读取同一次已完成运行；没有二次注入。

## 已跑通的参考实现与范围

一个单 consumer / 单分区适配器已经跑通：

```text
BEGIN MO transaction
  查稳定 event_id 去重账本
  若首次：INSERT ledger + UPDATE business counter
  更新 MO checkpoint(topic,partition,last_offset)
COMMIT MO
随后提交 Kafka consumer offset
```

- 在第 5 个事件 MO commit 前 SIGKILL consumer：未提交变更回滚，恢复重读。
- 在第 10 个事件 MO commit 后、Kafka offset ACK 前 SIGKILL：重读一次，由 ledger 抑制二次效果。
- 100 个事件最终 ledger=100、业务累计=100、MO checkpoint=99、Kafka committed=100。
- 扩展到 120 个事件，第 105 个事件未提交期间 SIGKILL MO；恢复前后已提交 ledger/counter 均为 104，重启继续消费，最终 ledger/counter/source count 与 sum 均为 120。

此结果仅认证自建适配器在上述故障点的事务内业务效果，不代表原生 JDBC/NiFi 已通过，也未认证多 consumer 并发、跨分区业务顺序、HA rebalance 或跨系统分布式事务。

## 原生 Kafka SQL 的相关契约

当前版本 `FinalizeKafkaProgress` 是语句/会话状态，不是 SQL 事务状态。独立三次重复测试：Kafka INSERT SELECT 成功后 ROLLBACK 或断开，MO 目标 0 行，但 broker committed offset=1。源码注释明确要求应用将 `LAST_KAFKA_MESSAGE_ID()` 存入同一显式 MO 事务的 checkpoint 表。正式接入模板应明确哪份 checkpoint 是恢复权威，不能把 broker offset 当作与 MO 数据原子提交的证据。

## 建议验收

1. 提供 Kafka Connect 与 NiFi 官方可运行模板/适配器，保留稳定 event ID、topic/partition/offset；定义缺少 event ID、同 ID 不同 payload、删除、主键改变和 schema evolution 的行为。
2. 重放不重复非幂等效果；事务前故障无半写，事务后 offset/ACK 前故障无重复效果。
3. 将事件账本、业务 DML、MO checkpoint 放同一事务；明确并发 fencing、再均衡、去重账本保留与回放窗口。
4. 增加自动故障矩阵，至少包括 client/worker/MO SIGKILL、COMMIT OK 丢失、网络恢复及重复投递；逐事件审计而不是只查最终行数。
5. 对外区分 source EOS、sink 幂等快照、事务内 exactly-once effects 和完整跨系统 EOS 的认证等级。

建议 P1：影响生产接入承诺，应先落实恢复/去重语义，再扩更高吞吐。

关联：https://github.com/matrixorigin/matrixone/issues/29848 、https://github.com/matrixorigin/matrixone/issues/27746 、https://github.com/matrixorigin/matrixone/issues/27587 。本单给出 Connect 与 NiFi 的新故障反例及实施验收；#27587 是另一版本的后续失败语句进度丢弃问题，不等同本单。
