# rest-seed

- status: `failed`
- rows: `0`
- checksum: `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`

## Error

```text
create Iceberg table ci_e2e_20261010t225350z.append_orders: ICEBERG_AUTH_FORBIDDEN: Iceberg REST catalog request failed [catalog_error_code=403, catalog_error_message_hash=530a953b407ad4cc, catalog_error_type_hash=13cb2ca091438dd5, operation=create_table, status=403]
```
