# Iceberg E2E Local Summary

- namespace: `ci_e2e_20261010t225350z`
- database: `iceci_20261010t225350z`
- catalog: `iceci_20261010t225350z`

| case | status |
| --- | --- |
| `ICE-CI-E2E-000` rest-seed | `failed` |
