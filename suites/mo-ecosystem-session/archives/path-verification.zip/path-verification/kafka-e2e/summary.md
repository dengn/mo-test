## kafka external table E2E

Status: **passed**

Cases: setup-seed, read-to-end-timeout-clean, gap-free-chaining, repeated-start-id-replays, pickup-after-produce, zero-messages-null-and-preserved, metadata-key-null, autocommit-earliest-and-last-id, txn-explicit-offset-table-atomic, error-mode-split, error-mode-message-id, error-mode-no-file-line, error-mode-pruned-still-fails
