# partition-filter

- status: `passed`
- rows: `2`
- checksum: `fd569c6e6ff2e997873b22c1117747f7b7669c497fce698eb49b73f7e3344d92`
