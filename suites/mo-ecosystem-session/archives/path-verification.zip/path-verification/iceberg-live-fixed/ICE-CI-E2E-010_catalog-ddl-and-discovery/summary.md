# catalog-ddl-and-discovery

- status: `passed`
- rows: `6`
- checksum: `18d3e482979bb1866c3c73bde8807db6c4c671aa6c713d69423c9820ebe95d29`
