# access-register-unregister-lifecycle

- status: `passed`
- rows: `2`
- checksum: `979da5bdf9235d115a6b431670d2a6f335e519e833db16d1eb5873724f31c5a2`
