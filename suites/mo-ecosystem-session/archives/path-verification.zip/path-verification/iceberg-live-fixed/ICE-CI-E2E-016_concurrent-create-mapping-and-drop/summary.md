# concurrent-create-mapping-and-drop

- status: `passed`
- rows: `1`
- checksum: `4b14c7b5549e560a68e9c4daaae3fdb8a28fe32d0247050325e7c5a3b2b3271c`
