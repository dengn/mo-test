# Iceberg E2E Local Summary

- namespace: `ci_e2e_20261010t225509z`
- database: `iceci_20261010t225509z`
- catalog: `iceci_20261010t225509z`

| case | status |
| --- | --- |
| `ICE-CI-E2E-000` rest-seed | `passed` |
| `ICE-CI-E2E-010` catalog-ddl-and-discovery | `passed` |
| `ICE-CI-E2E-015` access-register-unregister-lifecycle | `passed` |
| `ICE-CI-E2E-016` concurrent-create-mapping-and-drop | `passed` |
| `ICE-CI-E2E-020` append-read-time-travel | `passed` |
| `ICE-CI-E2E-025` empty-string-read | `passed` |
| `ICE-CI-E2E-030` partition-filter | `passed` |
| `ICE-CI-E2E-035` year-partition-date-filter | `passed` |
| `ICE-CI-E2E-040` merge-on-read-delete | `passed` |
