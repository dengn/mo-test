# merge-on-read-delete

- status: `passed`
- rows: `2`
- checksum: `85cf77ae1ec6e82f1c68360c44b8e3705ab9a5e2142cc0acd57a52c4b9345208`
