# rest-seed

- status: `passed`
- rows: `1`
- checksum: `7ce84c093bfef94f8ea473334cac7e7c87b4e42bd6ec35ca6c94b1382d9eeb37`
