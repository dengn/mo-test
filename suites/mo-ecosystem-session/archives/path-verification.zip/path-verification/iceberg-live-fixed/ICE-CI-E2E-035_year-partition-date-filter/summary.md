# year-partition-date-filter

- status: `passed`
- rows: `9`
- checksum: `a74f0e0818bae9dd4af147360c0aa2d39d59a056ef305de980934cda1c276ccb`
