# empty-string-read

- status: `passed`
- rows: `3`
- checksum: `a3c16836bcc2794139a153da1dbdb79b360c512cdc5c3223535c31c1807e813e`
