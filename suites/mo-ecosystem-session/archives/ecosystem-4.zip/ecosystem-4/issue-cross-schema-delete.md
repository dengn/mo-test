## 结论与优先级

建议 **P0 / 数据正确性阻断**。当关联子查询的内外表位于不同数据库、具有相同表名且没有显式别名时，已写完整 `database.table.column` 的关联条件仍会被错误绑定。DELETE 返回成功，但删除不匹配的行；SELECT 也返回不匹配行。

这是本轮 **dlt 真实增量装载** 发现的静默数据丢失：首次装载 ID 1/2/3；下一包只更新 1、新增 4，目标却变为仅有 1/4，未变化的 2/3 消失。dlt 的 target/staging 使用不同数据库、相同 `records` 表名，默认 delete-insert merge 正好生成该 SQL 形状。

## 实际环境

- MO 本地源码构建 `652c643666428f1c434e03369834f2a9bead7c27`，单节点 + MinIO，MySQL 协议端口 6001；未声称最新 main 已复现。
- 独立对照 MySQL 8.4.11，端口 13306。
- 集成发现路径：PostgreSQL 16.14 → dlt 1.31.0 官方 `sql_database` source / `sqlalchemy` destination，SQLAlchemy 2.1.4，PyMySQL。只使用本地合成数据。
- 共享 4 CPU / 16 GiB。本组 SQL 控制未注入宕机或网络故障。

## 最小复现（不依赖 dlt）

在空的测试数据库名称执行：

```sql
CREATE DATABASE eco4_corr_main;
CREATE DATABASE eco4_corr_stage;
CREATE TABLE eco4_corr_main.records(id INT PRIMARY KEY,v INT);
CREATE TABLE eco4_corr_stage.records(id INT PRIMARY KEY,v INT);
INSERT INTO eco4_corr_main.records VALUES(1,10),(2,20),(3,30);
INSERT INTO eco4_corr_stage.records VALUES(1,99),(4,44);

DELETE FROM eco4_corr_main.records
WHERE EXISTS (
  SELECT 1 FROM eco4_corr_stage.records
  WHERE eco4_corr_main.records.id=eco4_corr_stage.records.id
);
SELECT * FROM eco4_corr_main.records ORDER BY id;
```

**MO：affected=3，结果空表；MySQL：affected=1，剩余 `(2,20),(3,30)`。** 重置目标再执行，独立重复 3 次，结果完全一致。不能用 DELETE 的成功 ACK 或 dlt load package 成功状态判断数据正确。

## 控制矩阵

每组每次将目标重置为 1/2/3，stage 为 1/4；MO / MySQL 各做 3 次：

| SQL 形状 | MO | MySQL |
|---|---|---|
| 跨库同名表，完整限定名，未加别名 EXISTS | **全部删除** | 只删 1 |
| 同样两张表，显式 `t`/`s` 别名 EXISTS | 只删 1 | 只删 1 |
| 同样两张表，`id IN (SELECT id FROM stage.records)` | 只删 1 | 只删 1 |
| 同数据库、不同表名 EXISTS / IN / JOIN | 只删 1 | 只删 1 |

别名控制：

```sql
DELETE t FROM eco4_corr_main.records t
WHERE EXISTS (SELECT 1 FROM eco4_corr_stage.records s WHERE t.id=s.id);
```

更强的“不匹配”控制：将 stage 清空后仅插入 `(99,99)`，目标保持 1/2/3。执行：

```sql
SELECT id FROM eco4_corr_main.records
WHERE EXISTS (SELECT 1 FROM eco4_corr_stage.records
              WHERE eco4_corr_main.records.id=eco4_corr_stage.records.id)
ORDER BY id;
```

MO 返回 **1/2/3 全部**，MySQL 返回空。相同条件 DELETE 在显式事务中，MO affected=3、事务内空表；MySQL affected=0、保持三行。ROLLBACK 后两者都恢复/保留三行。因此不是事务回滚失效，而是查询谓词错误。stage 为空时两者均不匹配、不删除；问题与非空内表条件有关。

## dlt 中的真实影响

官方生成的 completed merge job 第一条 SQL：

```sql
DELETE FROM eco4_dlt_incremental.records WHERE EXISTS (
  SELECT 1 AS anon_1 FROM eco4_dlt_incremental_staging.records
  WHERE eco4_dlt_incremental.records.id = eco4_dlt_incremental_staging.records.id
)
```

随后 dlt 从 staging 插入本次改变的 1/4，load package 完成，最终 target 1/4，但 source 1/2/3/4。此前“全量 merge 每次携带所有行”的测试会把误删行重新插入，掩盖此缺陷。增量包只含变化行时，丢失立即显现。

本组已显式配置 `dedup_sort=asc` 绕开独立的 window scalar-constant ORDER BY 阻断；这个 DELETE 缺陷本身无需任何 window，也无需 dlt 或 CDC。

## 源码定位线索与验收

`pkg/sql/plan/base_binder.go:baseBindColRef` 已读取 `astExpr.DbName()`，但在正常 `bindingByTable[table]` 查找命中时，没有验证/优先解析数据库限定；只有未命中且有 remapOption 时尝试 `db+"."+table`。这与外层 `main.records.id` 在内层 `stage.records` 上误绑定的观察一致，需通过计划和回归测试确认最终修复。

验收应覆盖：跨库同名表的 SELECT/DELETE，匹配与不匹配/空 stage，别名与完整限定名，真正只含变化行的 dlt merge。不能只测试不同表名或全量再装载。

关联：生态认证总单 #29848；#23083 是 nested SELECT/IN 的 JOIN remapping **报错**，本例是简单 EXISTS **成功但错行/误删**，已核对不是同一复现场景。
