## 结论 / 环境

建议 P1：标准窗口 ORDER BY 中的无关联 scalar constant subquery 不能执行，直接阻断 dlt 1.31.0 默认 delete-insert merge 去重 SQL。

实际运行 MO 源码构建 `652c643666428f1c434e03369834f2a9bead7c27`，Linux x86_64 standalone + MinIO，MySQL 协议 6001，PyMySQL；独立 MySQL 8.4.11 / 13306 对照。日期 2026-10-11。没有在最新 main 运行或做多 CN 认证。只使用三行合成数据，无故障注入。

## 实际执行的最小 SQL

```sql
CREATE TABLE window_order4(id INT,v INT);
INSERT INTO window_order4 VALUES(1,10),(1,20),(2,30);
SELECT id,v,ROW_NUMBER() OVER(PARTITION BY id ORDER BY (SELECT NULL)) AS rn
FROM window_order4;
SELECT id,v,ROW_NUMBER() OVER(PARTITION BY id ORDER BY (SELECT 1)) AS rn
FROM window_order4;
-- 正常列排序对照
SELECT id,v,ROW_NUMBER() OVER(PARTITION BY id ORDER BY id) AS rn
FROM window_order4;
```

每条语句分别在 MO/MySQL 重复 3 次。两种 scalar constant 排序 MO 每次失败，MySQL 每次成功；普通 id 排序两端每次成功。相同常量形成 ties，不要求同组中 v=10/20 的行号顺序确定；验收是查询可执行、partition=1 内 rn 为 1/2，partition=2 内 rn 为 1。

MO 返回：

```text
20102 unsupported expression executor for typ:<id:71 width:4 > sub:<node_id:2 row_size:1 > now is not yet implemented
20102 unsupported expression executor for typ:<id:23 notNullable:true > sub:<node_id:2 row_size:1 > now is not yet implemented
```

## 真实生态路径 / 失败后的状态

dlt 1.31.0 官方 sqlalchemy destination，SQLAlchemy 2.1.4，primary_key=id，write_disposition=merge。初始三行装载成功；第二包 merge 中 dlt 默认生成 `row_number() over(partition by id order by (select null))` 去重，此 job 失败、pending package 保留，已有初始行保持不变。MySQL 同一官方 pipeline 完成。

显式设置 id 列 `dedup_sort='asc'` 后该执行阻断消失。但是不能据此宣布 merge 数据正确：后续跨数据库同名表的 DELETE 会独立误删未变化行，见 #29876。只有同时加了明确标注的精确 SQL 形状别名适配后，真正增量的更新、hard delete、ADD COLUMN 和 normalize 后 SIGKILL/package resume 七阶段才全部保真通过。

`ORDER BY NULL` 也不是可用绕过方案：literal NULL 控制进入另一条 ANY / PartitionForOrder 错误路径，单独跟踪。不能把两个错误码当成一个已修复路径。

## 验收与关联

- 覆盖 (SELECT NULL)、(SELECT 1)、普通列，NULL/non-NULL 常量、重复分区键、空输入和不同 batch；只要求 ties 合法而非任意顺序固定。
- 默认 dlt merge package 能执行；独立对目标全部行比对，不能只看 package LOADED。
- #29848：生态认证总单；#29876：独立的成功但误删问题。
- #23070：VARCHAR ORDER BY 的 RANGE frame 限制；#25115：大数据 split window result；#27858：单行聚合消除后 constant ORDER BY 优化。已核对触发和错误不同，均不覆盖本组三行 scalar constant executor 缺失。

原始证据：`window-order-controls.json`（包含 literal NULL 在内共 2 引擎×4形状×3重复=24项），`dlt-native-result.json` 与失败 SQL package。文件为本地保存证据，不是公开附件；上面的 SQL 已独立执行，无需 dlt 即可复现。
