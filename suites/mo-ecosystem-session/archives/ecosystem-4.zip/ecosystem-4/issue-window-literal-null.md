## 结论 / 测试条件

建议 P2：三行输入的 `ROW_NUMBER() OVER(PARTITION BY id ORDER BY NULL)` 在窗口排序分区处理返回 ANY not-supported 错误和 recovery stack，MySQL 正常执行。不是服务整体崩溃，也没有证据证明磁盘数据损坏。

2026-10-11，实际 MO 构建 SHA `652c643666428f1c434e03369834f2a9bead7c27`，standalone + MinIO，Linux x86_64，PyMySQL 文本协议 6001。独立 MySQL 8.4.11 /13306 对照。未在最新 main 部署执行，未做多 CN/吞吐测试。

## 独立执行的复现与对照

```sql
CREATE TABLE window_order4(id INT,v INT);
INSERT INTO window_order4 VALUES(1,10),(1,20),(2,30);
SELECT id,v,ROW_NUMBER() OVER(PARTITION BY id ORDER BY NULL) AS rn
FROM window_order4;
-- 对照
SELECT id,v,ROW_NUMBER() OVER(PARTITION BY id ORDER BY id) AS rn
FROM window_order4;
```

同一连接每条语句重复 3 次：literal NULL 在 MO 3/3 失败、MySQL 3/3 成功；id 排序在两端 3/3 成功。后续普通 SELECT 仍可执行，无需服务重启。ties 无确定顺序，预期是 partition=1 产生 rn 1/2、partition=2 产生 rn 1；不要求 10/20 谁先。

返回错误核心：

```text
20105 not supported: ANY:
github.com/matrixorigin/matrixone/pkg/partition.Partition
  pkg/partition/partition.go:246
github.com/matrixorigin/matrixone/pkg/partition.PartitionForOrder
  pkg/partition/partition.go:262
github.com/matrixorigin/matrixone/pkg/sql/colexec/window.(*container).processOrder
  pkg/sql/colexec/window/window.go:2593
github.com/matrixorigin/matrixone/pkg/sql/colexec/window.(*Window).Call
  pkg/sql/colexec/window/window.go:397
```

这是 literal NULL 类型进入窗口 partition 路径；scalar `(SELECT NULL)` / `(SELECT 1)` 则报 20102 subquery expression executor not implemented，错误根与栈不同，独立跟踪。生态上，不能把默认 dlt scalar ORDER BY 改成 literal NULL 当作兼容绕过。

## 验收 / 关联

覆盖 NULL 常量、显式 CAST(NULL AS INT)、非 NULL 常量、普通 nullable 排序列，partition/no-partition、空/单行/多 batch 输入。类型处理应返回合法行号，不能把 panic recovery 错误当作合法 SQL 的正常结果。

关联 #29848；#23070 是 VARCHAR/RANGE frame，#25288 是 nullable **列** 的 RANGE frame 错行，#25115 是大数据 split-result 错误，都不是本组三行 literal NULL 的 ANY 路径。

原始本地证据 `window-order-controls.json`，24 项独立控制的其中 6 项为 literal NULL MO/MySQL×3重复。上面 SQL 已运行，并非从未运行的裁剪建议。
