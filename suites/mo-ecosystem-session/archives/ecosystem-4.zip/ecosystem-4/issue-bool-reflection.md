## 结论 / 环境

建议 P2：MO MySQL 协议的 BOOL 表定义元数据不能被 SQLAlchemy MySQL dialect 识别；反射为 NullType，后续从反射 schema 编译克隆建表失败。布尔值的直接读写本身正常；不是 BOOL 数据丢失。

2026-10-11，实际运行 MO 源码构建 `652c643666428f1c434e03369834f2a9bead7c27`，standalone + MinIO，Linux x86_64，SQLAlchemy **2.1.4** / PyMySQL，6001。同一脚本独立连接 MySQL **8.4.11** /13306。未声称最新 main 也运行复现。

## 实际过程 / 最小复现

```sql
CREATE TABLE bool_metadata4(id INT PRIMARY KEY,flag BOOL);
INSERT INTO bool_metadata4 VALUES(1,TRUE),(2,FALSE),(3,NULL);
SHOW COLUMNS FROM bool_metadata4;
SELECT * FROM bool_metadata4 ORDER BY id;
```

两端读值均为 `(1,1),(2,0),(3,NULL)`。SHOW COLUMNS 的 flag 类型：MO `BOOL(0)`，MySQL `tinyint(1)`。

```python
import os, sqlalchemy as sa
engine=sa.create_engine(os.environ['TEST_MYSQL_SQLALCHEMY_URL'])
table=sa.Table('bool_metadata4',sa.MetaData(),autoload_with=engine)
print(table.c.flag.type)
clone=table.to_metadata(sa.MetaData(),name='bool_metadata_clone4')
print(sa.schema.CreateTable(clone).compile(dialect=engine.dialect))
```

上面的反射与编译控制已分别在两端运行：

- MO warning: `Did not recognize type 'bool' of column 'flag'`；flag type 为 `NULL` / NullType。
- MO 编译失败：`(in table 'bool_metadata_clone4', column 'flag'): Can't generate DDL for NullType(); did you forget to specify a type on this Column?`
- MySQL 无 warning、flag 为 TINYINT，克隆 DDL 正常编译为 `flag TINYINT(1)`。

没有把编译失败说成数据库接收到 CREATE 后拒绝；失败发生在客户端使用反射结果时。实际 dlt 1.31.0 合并中新添加的 deleted hard-delete BOOL 列也出现同样 warning，但部分 dlt 任务仍完成，因此不能声称所有 dlt BOOL 装载都被阻断。

## 预期 / 验收 / 关联

面向标准 MySQL 客户端返回可解析且不丢布尔语义的表定义，或提供明确、官方的 MatrixOne SQLAlchemy dialect 类型映射。应覆盖 SHOW CREATE/SHOW COLUMNS/information_schema 路径，反射、克隆 DDL、bool 真/假/NULL、nullable与默认值，并验证修正不把整数/unsigned/decimal 类型误改。

#29846 是 Ibis 不能识别 BIGINT UNSIGNED(64)，同属元数据兼容但不同组件/类型；#25103 是 information_schema 缺表等兼容背景，不覆盖这条 SHOW 反射 BOOL→NullType。总单 #29848。

原始本地证据 `boolean-reflection-result.json` 保存返回类型、warning、编译失败/成功对照；`dlt-incremental-alias-run.log` 保存 deleted 列真实 warning。仅提供证据名称，复现不依赖访问本地文件。
