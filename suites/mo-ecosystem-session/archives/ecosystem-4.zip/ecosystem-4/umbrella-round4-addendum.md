
## 第四轮：新生态组件与真实增量/CDC/恢复扩展（2026-10-11，Asia/Shanghai）

### 实际版本与边界

仍以 **实际运行 SHA `652c643666428f1c434e03369834f2a9bead7c27`** 为准。不是最新 main 部署认证。单节点 MO + MinIO；共享 4 CPU / 16 GiB，全部人工合成数据。新组件本轮是功能、类型保真和具体恢复切面，**没有新增组件吞吐、长稳、多 CN HA 或跨系统 exactly-once 认证**；上一轮 30 分钟 soak/EOS 结论仍按原条件解释。

新增 PostgreSQL **16.14**（真实 pgoutput/WAL）、Debezium PostgreSQL/JDBC **3.1.2.Final**、dlt **1.31.0** 官方 SQL source / SQLAlchemy destination（SQLAlchemy **2.1.4**）、Redpanda Connect **4.113.0** 官方二进制 SHA 核验、Confluent JDBC **10.8.4** 独立原生 sink。Kafka **3.9.1**；MySQL **8.4.11** 作同脚本独立控制。NiFi/旧 worker 没有为本轮顺带重启。

### 最严重的新结果：成功装载仍可误删

**#29876 / 建议 P0**：跨数据库同名表、完整 `database.table.column` 限定的无别名 EXISTS 条件绑定错误。target=1/2/3，stage=1/4，DELETE 在 MO 删除全部三行，在 MySQL 只删除 1；三次重复一致。stage 只有 99、不匹配任何目标时，MO 的 SELECT/DELETE 仍匹配全部行。别名/IN 与同数据库不同表名控制正确，ROLLBACK 也正确，因此不能泛化为事务回滚失效。

dlt 真正增量包只更新 1、新增 4，目标只剩 1/4，未变化的 2/3 丢失。进一步核对：single-row hard-delete 包虽显示 LOADED，MO 目标变空；single-row schema-add 更新包只剩 2，MySQL 仍保留 2/3/4。**已有本轮原始 receipt 的 `completed` 只是交付状态，不能列为数据保真通过。** 全字段控制复核已另存并判失败。全量 update 包把全部行再插回，会掩盖此错误。

新增独立问题也已详细提交并核对 readback：

- **#29877 / 建议 P1**：ROW_NUMBER ORDER BY `(SELECT NULL)` / `(SELECT 1)`，MO 20102，MySQL 正常，阻断默认 dlt merge。
- **#29878 / 建议 P2**：literal `ORDER BY NULL` 在 PartitionForOrder 报 20105 ANY recovery error；是另一条执行路径，服务未整体崩溃。
- **#29879 / 建议 P2**：BOOL(0) 表定义反射为 SQLAlchemy NullType，编译克隆 DDL 失败；TRUE/FALSE/NULL 直接读写正常。

核对并关联 #23083、#23070、#25115、#25288、#27858、#25103、#29846 等背景 issue，没有把不同触发的历史问题当成重复/已修复。

### 完整链路和检查阶段

“阶段数”是实际检查条目；两端对照、语义复核、故障重跑分别记账，不能相加当成独立认证数量。

| 路径 | 本轮执行与实际结果 | 必须保留的条件 |
|---|---|---|
| PG→Debezium pgoutput→Kafka→Debezium JDBC→MO | **7 阶段逐字段通过**：snapshot、update、delete+tombstone、PK migration、源事务 rollback、不丢微秒的 coordinated ADD COLUMN、Connect worker SIGKILL 后 logical-slot resume | 预建目标；ADD COLUMN 明确在两端协调执行；不是自动 DDL 或 EOS |
| PG 扩展类型→Debezium JDBC→MO/MySQL | TIME(6)、TIMESTAMPTZ→UTC、BOOLEAN、日期边界、无固定 scale NUMERIC 在目标 DECIMAL(38,18) 范围内，**4 个两端语义检查通过** | 初始脚本把 time/timedelta 字符串、list/tuple 容器拿来比较造成假差异；原输出保留，语义复核覆盖结论 |
| PG INTEGER[] 原生 Debezium JDBC | MO/MySQL **两端均失败**，GeneralDatabaseDialect.getSchemaType NPE | 插件在 SQL 写入前失败，归 upstream 适配限制，非 MO 内核 bug |
| PG ARRAY 显式事务内 trigger→JSONB envelope→CDC→MO/MySQL | **6 检查通过**：snapshot（NULL 元素/空数组/SQL NULL）、非 1 起始下标+多维数组更新、删除+主键迁移 | envelope 保留 values + array_dims；不是原生 ARRAY 支持，也不是仅将维度丢弃的 JSON 化 |
| Redpanda Connect 原生 sql_select→sql_insert | **4 方向全部精确保真**：MySQL→MySQL、MySQL→MO、MO→MO、MO→MySQL | Go 原生 SQL types / prepared args，含 uint64 max、decimal38,18、二进制 00ff80/空/NULL、JSON 大整数、微秒时间 |
| Redpanda Kafka franz→SQL→Kafka fallback DLQ | 初始 **10 检查通过**：精确编码 profile、更新/删除/显式换主键、重复 upsert 最终状态幂等、坏行隔离与有效后续、DLQ 完整原始内容 | JSON 中 64bit integer/decimal 使用 string，binary hex，时间精确文本；逐条 ACK/checkpoint；最终状态幂等不等于 EOS |
| Redpanda 新列/重启恢复 | 原 v2 Bloblang 测试配置用 array+array 导致两端坏映射、记录入 DLQ；修正为单一 array literal 并**显式重放**两条合法记录后恢复，失败未隐去 | 这是测试配置问题，非 MO bug；DLQ reader 缺 snappy 的依赖也已装齐续跑，未把 reader 失败算服务失败 |
| Redpanda SIGKILL 恢复时间复测 | 默认会话下 **MO 45s deadline 未达**，后续最终全部字段一致；明确配置 Kafka session_timeout=8s/heartbeat=2s/rebalance=10s 后，重复 SIGKILL+离线 update/delete/insert，MO **8.215s** / MySQL **7.358s** sampled reconciliation，通过；消费 next offset=23 | 只是一次故障的采样恢复耗时，不是 p99/SLA/吞吐。短会话配置改变了故障检测条件；原 deadline 失败独立记录 |
| Confluent JDBC 原生 sink→MO/MySQL | **8 检查通过**：完整宽类型、tombstone delete/换主键、pause-backlog-resume、301 字符坏行进 DLQ 后有效行继续；两端各一条 DLQ 且 key/payload/context headers 保留 | 用真实 schema-aware Kafka producer，未冒充 source connector；uint64 用 Decimal20,0，微秒 timestamp 明确用 STRING profile；未认证 EOS |
| dlt 默认 sqlalchemy destination | 初始能加载；默认 merge 被 #29877 阻断；dedup-sort 或 hex 编码单独不能修复 #29876 误删 | dlt empty bytes 在两端均会 normalize 到 NULL+payload__v_text，归 upstream normalization；不能按两端相同就说 b'' 保真 |
| dlt 官方 PG incremental source + **明确测试 adapter** | **7 检查阶段逐字段通过**：初始、无变化无新 package、真正增量 update/insert、hard-delete、schema-add、extract+normalize 后 SIGKILL/独立进程 load pending package、恢复后无变化无重复 | 同时使用 dedup_sort、BYTEA hex envelope、只匹配精确 SQL 形状的显式别名 DELETE rewrite；这是绕过方案，不是默认 dlt/MO 原生兼容修复 |

最终 Kafka Connect 本轮 14 个 connector：12 个非 ARRAY connector task 正常，2 个原生 ARRAY sink 保留 FAILED/NPE 证据；没有声称全部绿灯。最终各条通过路径的主键集合、逐字段数据及消费位点已复核。

### 证据、优先级与后续

本地 `work/ecosystem-4/round-manifest.json` 汇总实际版本、21 个原始/复核 receipt 的 SHA256、status precedence、最后目标状态和适配条件。这些是本地证据标识，**不是公开下载链接**；四个新增问题正文都有实际执行的最小 SQL/Python 和 MySQL 对照。

结果文件复用曾覆盖一个 default-session recovery JSON；原输入/进程日志和捕获输出仍保留，该 deadline 记录已恢复为明确标注的 **reconstructed evidence**，不是伪称原始 byte-for-byte receipt。短会话计时重复有独立原始 receipt。原生 ARRAY NPE、dlt 空 bytes、测试脚本的比较/映射错误均未冒充 MatrixOne 缺陷。

修复顺序：**先 #29876 静默误删；再 #29877 默认生态 SQL 阻断；随后 #29878 / #29879 与既有 unsigned 元数据兼容。** 新增性能/长稳资格测试必须在这些正确性门槛之后，并单独固定组件 profile、资源、语义、故障点和观测时长。

后续扩展建议进入复合/无主键 CDC、schema rename/drop/type-widen、snapshot 与 WAL 接续竞争、目标离线的 DLQ/retry 策略，以及增量合并的全量行级 oracle。当前回合未执行的用例不计入通过。
