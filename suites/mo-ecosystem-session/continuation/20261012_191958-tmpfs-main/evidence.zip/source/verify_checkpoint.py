"""Reconstruct original case oracles from immutable complete typed archives."""
import sys,json,gzip,hashlib,collections,decimal,datetime,os
from pathlib import Path
B=Path(__file__).resolve().parent;sys.path.insert(0,str(B/'windowed'));from heavy import canon,PROFILES,sha
decimal.getcontext().prec=100;profiles={p['name']:p for p in PROFILES};OUT=B/'checkpoints';OUT.mkdir(exist_ok=True)
stamp=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y%m%d_%H%M%S');O=OUT/stamp;O.mkdir()
archives=[]
for p in sorted((B/'results/window-archives').glob('*.receipt.json')):
 r=json.loads(p.read_text())
 if r.get('applied') and r.get('archive_verified') and r.get('case_ids'):archives.append((p,r))
cases={};routes={}
for p in (B/'results/core-results').glob('*.jsonl'):
 if p.name=='file-manifest.jsonl':continue
 rows=[]
 for line in p.read_text().splitlines():
  try:r=json.loads(line)
  except json.JSONDecodeError:continue
  if 'id' not in r or 'status' not in r:continue
  assert r['id'] not in cases,r['id'];cases[r['id']]=r;rows.append(r)
 routes[p.stem]={'completed':len(rows),'counts':dict(collections.Counter(r['status'] for r in rows)),'new_runtime_cases':sum('runtime_id' in r for r in rows)}
def decode(v):
 tag=v[0];x=v[1] if len(v)>1 else None
 return {'null':lambda:None,'scalar':lambda:x,'bytes':lambda:bytes.fromhex(x),'decimal':lambda:decimal.Decimal(x),'datetime':lambda:datetime.datetime.fromisoformat(x),'date':lambda:datetime.date.fromisoformat(x),'time_us':lambda:datetime.timedelta(microseconds=x),'float_hex':lambda:float.fromhex(x),'set':lambda:set(x)}[tag]()
proof=[];seen=set();table_rows=0;archive_members=[];selected_cases=[]
for p,r in archives:
 a=Path(r['archive']);compressed=a.read_bytes();assert hashlib.sha256(compressed).hexdigest()==r['sha256'] and len(compressed)==r['bytes'];d=json.loads(gzip.decompress(compressed));assert d['database']=='mo_ecosystem_heavy_20261012'
 decoded={}
 for t in d['tables']:
  h=hashlib.sha256()
  for row in t['rows']:h.update(json.dumps(row,ensure_ascii=False,separators=(',',':')).encode()+b'\n')
  assert len(t['rows'])==t['row_count'] and h.hexdigest()==t['row_sha256']
  match=next(x for x in r['tables'] if (x['endpoint'],x['table'])==(t['endpoint'],t['table']));assert match['rows']==t['row_count'] and match['row_sha256']==t['row_sha256'];table_rows+=t['row_count']
  if t['table'].startswith('t_'):
   by=collections.defaultdict(list)
   for row in t['rows']:by[int(row[0][1])].append([decode(v) for v in row[:5]])
   decoded[t['endpoint']]=by
 for cid in r['case_ids']:
  assert cid not in seen;seen.add(cid);c=cases[cid];actual=decoded[c['port']][c['logical_case_id']];digest=sha(canon(actual,profiles[c['profile']]))
  ok=len(actual)==c.get('expected_rows') and digest==c.get('expected_sha256')
  assert ok or c['status']!='passed',(cid,'Archived effects differ from passing oracle')
  proof.append({'id':cid,'status':'passed' if ok else 'failed_effect_preserved','recorded_status':c['status'],'rows':len(actual),'sha256':digest,'archive':a.name});selected_cases.append(c)
 archive_members += [a,p]
(O/'archived-case-readback.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in proof))
(O/'new-executed-cases.jsonl').write_text(''.join(json.dumps(c,ensure_ascii=False)+'\n' for c in selected_cases))
summary={'date_Asia_Shanghai':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat(),'runtime_id':json.loads((B/'review-plan.json').read_text())['runtime_id'],'main_completed':30000+sum(r['completed'] for r in routes.values()),'main_remaining':160000-30000-sum(r['completed'] for r in routes.values()),'routes':routes,'fully_archived_new_cases':len(seen),'full_typed_archive_windows':len(archives),'full_table_rows':table_rows,'archived_readback_counts':dict(collections.Counter(r['status'] for r in proof)),'new_receipts_waiting_for_current_window_archive':sum(r['new_runtime_cases'] for r in routes.values())-len(seen),'case_definition':'Parameterized datatype/scenario/seed/backend row-set assertions,controls included;notdistinctDAGs/crashes','scope':'Functional native/configured writer and explicit SQL effects;tmpfs;notdiskthroughput/longsoak/nativecrosssystemEOS','old_data_retained':True}
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');(O/'archive-files.json').write_text(json.dumps([str(p) for p in archive_members],indent=2)+'\n');(B/'latest-checkpoint.json').write_text(json.dumps({'directory':str(O),**summary},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
