import collections,datetime,gzip,hashlib,json,os,sys,decimal
from pathlib import Path
B=Path('/workspace/work/heavy-5000')
sys.path.insert(0,str(B))
from heavy import canon,PROFILES
decimal.getcontext().prec=100
profiles={p['name']:p for p in PROFILES}
def decode(v):
 tag=v[0];x=v[1] if len(v)>1 else None
 return {'null':lambda:None,'scalar':lambda:x,'bytes':lambda:bytes.fromhex(x),'decimal':lambda:decimal.Decimal(x),'datetime':lambda:datetime.datetime.fromisoformat(x),'date':lambda:datetime.date.fromisoformat(x),'time_us':lambda:datetime.timedelta(microseconds=x),'float_hex':lambda:float.fromhex(x),'set':lambda:set(x)}[tag]()
def read(p): return json.loads(p.read_text())
def save(p,d): p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
routes={}
for route in ['petl','pandas']:
 p=B/'windowed-results/core-results'/f'{route}.jsonl'
 rows=[json.loads(l) for l in p.read_text().splitlines()]
 assert len(rows)==len({r['id'] for r in rows})
 counts=dict(collections.Counter(r['status'] for r in rows))
 assert counts=={'passed':len(rows)}
 routes[route]={'completed':len(rows),'counts':counts,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
archives=[];covered=[];case_receipts={}
for route in ['petl','pandas']:
 for l in (B/'windowed-results/core-results'/f'{route}.jsonl').read_text().splitlines():
  r=json.loads(l);case_receipts[r['id']]=r
for p in sorted((B/'windowed-results/window-archives').glob('*.receipt.json')):
 r=read(p);a=Path(r['archive']);data=a.read_bytes()
 assert hashlib.sha256(data).hexdigest()==r['sha256'] and len(data)==r['bytes']
 d=json.loads(gzip.decompress(data));assert d['database']=='mo_ecosystem_heavy_20261012'
 for t in d['tables']:
  h=hashlib.sha256()
  for row in t['rows']:h.update(json.dumps(row,ensure_ascii=False,separators=(',',':')).encode()+b'\n')
  assert h.hexdigest()==t['row_sha256'] and len(t['rows'])==t['row_count']
  m=next(x for x in r['tables'] if (x['endpoint'],x['table'])==(t['endpoint'],t['table']))
  assert m['rows']==t['row_count'] and m['row_sha256']==t['row_sha256']
 if r['applied']:
  assert r['archive_verified']
  covered+=r.get('case_ids',[])
  for cid in r.get('case_ids',[]):
   case=case_receipts[cid]
   t=next(x for x in d['tables'] if x['endpoint']==case['port'] and x['table'].startswith('t_'))
   rows=[[decode(v) for v in row[:5]] for row in t['rows'] if row[0][1]==case['logical_case_id']]
   c=canon(rows,profiles[case['profile']])
   digest=hashlib.sha256(json.dumps(c,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
   assert len(rows)==case['expected_rows'] and digest==case['expected_sha256'],cid
 archives.append({'archive':a.name,'sha256':r['sha256'],'verified_tables':len(d['tables']),'typed_rows':sum(t['row_count'] for t in d['tables']),'applied':r['applied'],'case_count':len(r.get('case_ids',[]))})
assert len(covered)==len(set(covered))
for route in ['petl','pandas']:
 rows=[json.loads(l) for l in (B/'windowed-results/core-results'/f'{route}.jsonl').read_text().splitlines()]
 for r in rows:
  if r.get('database')=='mo_ecosystem_heavy_20261012':assert r['id'] in covered
s=read(B/'current-status.json')
for t in s['tools']:
 route=t['tool'].lower()
 if route in routes:
  r=routes[route];t.update(completed_cases=r['completed'],counts=r['counts'],receipt_sha256=r['sha256'])
  t['status']='completed_native_writer_with_explicit_effects' if r['completed']==5000 else 'partial_capacity_paused'
  t['receipt_path']=f'windowed-results/core-results/{route}.jsonl'
s['completed_unique_cases']=sum(t.get('completed_cases',0) for t in s['tools'])
s['remaining_planned_cases']=s['planned_cases']-s['completed_unique_cases']
s['capacity_blocked']='User chose disk expansion to at least64GiB; observed32GiB, writes paused until expansion is verified. Reserve guard not lowered.'
s['date_Asia_Shanghai']=datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=8))).isoformat()
s['table_reuse_approval']='Explicitly approved registered new-schema scratch tables only, after full typed archive/readback/hash verification; old data retained'
save(B/'current-status.json',s)
proof={'routes':routes,'archive_windows':archives,'covered_new_schema_cases':len(covered),'old_petl_fresh_full_readback':read(B/'core-results/petl-full-readback.json'),'main_completed':s['completed_unique_cases'],'main_remaining':s['remaining_planned_cases'],'disk_total_bytes':os.statvfs(B).f_blocks*os.statvfs(B).f_frsize,'disk_free_bytes':os.statvfs(B).f_bavail*os.statvfs(B).f_frsize,'old_data_retained':True}
save(B/'continuation-verification.json',proof)
print(json.dumps({'routes':routes,'archive_windows':len(archives),'archive_cases':len(covered),'main_completed':s['completed_unique_cases'],'main_remaining':s['remaining_planned_cases']},ensure_ascii=False))
