# catalog-ddl-and-discovery

- status: `passed`
- rows: `6`
- checksum: `111d67bbe7a0aa8231b379eaf70ea5225256ad885fb61e4e2778ae50b874e6a4`
