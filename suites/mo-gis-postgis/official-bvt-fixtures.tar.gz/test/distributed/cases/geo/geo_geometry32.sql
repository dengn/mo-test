-- GIS: GEOMETRY32 (float32-coordinate) type — storage, functions, and casts.

drop database if exists geo32;
create database geo32;
use geo32;

-- DDL: generic geometry32 and a subtype alias; SHOW CREATE renders the 32 family.
drop table if exists t32;
create table t32(id int, g geometry32, p point32, l linestring32);
show create table t32;
drop table t32;

-- Storage round-trip: values are stored as float32 WKB, rendered as WKT.
drop table if exists g32;
create table g32(id int, g geometry32);
insert into g32 values (1, st_geomfromtext('POINT(1 2)'));
insert into g32 values (2, st_geomfromtext('LINESTRING(0 0,3 4)'));
insert into g32 values (3, st_geomfromtext('POLYGON((0 0,2 0,2 2,0 2,0 0))'));
select id, st_astext(g) as wkt from g32 order by id;
-- A 2D point stored as float32 WKB occupies 13 bytes (vs 21 for float64).
-- length() is a byte-length function over the raw payload, so cast to
-- varbinary to measure the stored WKB size.
select length(cast(g as varbinary)) as f32_point_bytes from g32 where id = 1;
select id, st_geometrytype(g) as gtype from g32 order by id;

-- Spatial functions read GEOMETRY32 correctly (computation is float64 internally).
select st_x(g) as x, st_y(g) as y from g32 where id = 1;
select st_area(g) as area from g32 where id = 3;
select st_length(g) as len from g32 where id = 2;
select st_astext(st_centroid(g)) as centroid from g32 where id = 3;
drop table g32;

-- Casts between geometry and geometry32 preserve the geometry (to float32
-- precision).
select st_astext(cast(st_geomfromtext('POINT(1.5 2.25)') as geometry32)) as to32;
select st_astext(cast(cast(st_geomfromtext('POINT(1.5 2.25)') as geometry32) as geometry)) as roundtrip;
select st_astext(cast('LINESTRING(0 0,1 1)' as geometry32)) as text_to_32;

-- GEOMETRY32 precision propagation: coordinate accessors return float32, and
-- geometry-returning functions stay GEOMETRY32 (float32 WKB, shorter bytes).
drop table if exists g32p;
create table g32p(id int, g geometry32);
insert into g32p values
  (1, st_geomfromtext('POINT(1.5 2.5)')),
  (2, st_geomfromtext('LINESTRING(0 0, 3 4)')),
  (3, st_geomfromtext('POLYGON((0 0, 4 0, 4 4, 0 4, 0 0))'));

-- ST_X / ST_Y on a POINT32 yield float32 values.
select st_x(g) as x, st_y(g) as y from g32p where id = 1;

-- Geometry-returning functions preserve GEOMETRY32: a float32-WKB point is 13
-- bytes, a float64-WKB point is 21. ST_Centroid / ST_StartPoint of a
-- GEOMETRY32 column stay float32 (13 bytes).
select length(cast(st_centroid(g) as varbinary)) as centroid_bytes from g32p where id = 3;
select length(cast(st_startpoint(g) as varbinary)) as start_bytes from g32p where id = 2;
select st_astext(st_swapxy(g)) as swapped from g32p where id = 1;
select st_astext(st_envelope(g)) as env from g32p where id = 2;

-- ST_ConvexHull / ST_Buffer over GEOMETRY32 also stay float32.
select st_astext(st_convexhull(g)) as hull from g32p where id = 3;
select length(cast(st_buffer(g, 1) as varbinary)) > 0 as buffered from g32p where id = 1;

-- Measures over GEOMETRY32 return float32.
select st_length(g) as len from g32p where id = 2;
select st_area(g) as area from g32p where id = 3;

-- Distance between two GEOMETRY32 values returns float32.
select st_distance(a.g, b.g) as dist from g32p a, g32p b where a.id = 1 and b.id = 1;
drop table g32p;

-- Derived empty geometries must be real WKB and survive storage/reuse.
create table empty32(id int, g geometry32);
insert into empty32 values
  (1, st_boundary(cast('LINESTRING(0 0,1 1,0 0)' as geometry32))),
  (2, st_geometryn(st_collect(cast('POINT EMPTY' as geometry32), cast('POINT(1 2)' as geometry32)), 1)),
  (3, st_geometryn(st_collect(cast('LINESTRING EMPTY' as geometry32), cast('LINESTRING(0 0,1 1)' as geometry32)), 1)),
  (4, st_geometryn(st_collect(cast('POLYGON EMPTY' as geometry32), cast('POLYGON((0 0,1 0,0 1,0 0))' as geometry32)), 1));
select id, st_astext(g) as wkt, st_isempty(g) as is_empty from empty32 order by id;
select st_astext(st_boundary(cast('LINESTRING(0 0,1 1)' as geometry32))) as open_boundary;
insert into empty32 values (5, null);
select st_boundary(g) is null as null_boundary from empty32 where id = 5;
-- Empty sentinels remain valid; real coordinate overflow must still abort
-- the entire statement, including the preceding valid row.
insert into empty32 values (6, cast('POINT(1 2)' as geometry32)), (7, cast('POINT(3.5e38 0)' as geometry32));
select count(*) as retained_rows, max(id) as last_id from empty32;
drop table empty32;

drop database geo32;
