# GIS / GEOMETRY BVT tests

BVT coverage for the GEOMETRY type and spatial functions (see
`docs/design/gisimpl.md`). Geometry values are stored as bare WKB; SRID lives in
the column/expression type.

## Files

| File | Covers |
|------|--------|
| `geo_constructors.sql` | Typed `ST_*FromText` / `ST_*FromWKB` constructors and synonyms, subtype mismatch rejection, `ST_NumInteriorRing`. |
| `geo_io.sql` | WKT↔WKB↔geometry round-trips (`ST_GeomFromText`, `ST_AsText`/`ST_AsWKT`, `ST_AsWKB`/`ST_GeomFromWKB` and the `*Binary` synonyms, `CAST`), all seven kinds + `EMPTY`, number formats, NULL and invalid-input handling. |
| `geo_type_ddl.sql` | DDL for `GEOMETRY` and the subtype aliases, the `GEOMETRY32`/`GEOGRAPHY`/`*32` aliases, `SRID` attribute, `SHOW CREATE TABLE`, insert/select/update/delete storage, and subtype enforcement. |
| `geo_functions_unary.sql` | Accessors (`ST_GeometryType`, `ST_X`, `ST_Y`, `ST_Dimension`, `ST_NumPoints`, `ST_NumGeometries`, `ST_NumInteriorRings`, `ST_IsEmpty`, `ST_IsClosed`, `ST_IsCollection`, …), measures (`ST_Area`, `ST_Length`), and derived geometries (`ST_Centroid`, `ST_Boundary`, `ST_Envelope`, `ST_StartPoint`, `ST_EndPoint`, `ST_PointN`, `ST_ExteriorRing`, `ST_InteriorRingN`, `ST_GeometryN`, `ST_PointOnSurface`). |
| `geo_functions_binary.sql` | `ST_Distance` and the relationship predicates `ST_Contains`, `ST_Within`, `ST_Intersects`, `ST_Disjoint`, `ST_Touches`, `ST_Crosses`, `ST_Overlaps`, `ST_Equals`, `ST_Covers`, `ST_CoveredBy` (Cartesian / SRID 0). |
| `geo_validity.sql` | `ST_IsSimple`, `ST_IsRing`, `ST_IsValid`. |
| `geo_srid.sql` | SRID carried by the type: `ST_GeomFromText(wkt, srid)` + `ST_SRID`, SRID propagation through derived geometries, `SRID` columns, and binary-function SRID-mismatch rejection. |
| `geo_geometry32.sql` | `GEOMETRY32` (float32-coordinate) DDL, storage round-trips (float32 WKB), spatial functions, and `geometry`↔`geometry32` casts. |
| `geo_load.sql` | Loading GEOMETRY from CSV via all three paths — external table, `LOAD DATA INFILE`, and `LOAD DATA INLINE`; WKT fields parse to WKB, generic `GEOMETRY` accepts any subtype, subtype-constrained columns enforce their subtype, and the `GEOMETRY32`/`GEOGRAPHY` aliases work. |
| `geo_geodetic.sql` | SRID 4326 measures (`ST_Length`, `ST_Distance`, `ST_Area`) return meters / m² (geodesic) vs Cartesian for SRID 0, incl. a `GEOGRAPHY` column. |
| `geo_antimeridian.sql` | SRID 4326 local topology/overlay across the antimeridian, operand-order and high-latitude controls, `GEOMETRY32`, masked execution, and the safe spatial-index fallback. |
| `geo_geohash.sql` | `ST_GeoHash` (point and lon/lat forms), `ST_LatFromGeoHash`, `ST_LongFromGeoHash`, `ST_PointFromGeoHash`. |
| `geo_mbr.sql` | MBR bounding-box predicates: `MBRContains`, `MBRCoveredBy`, `MBRCovers`, `MBRDisjoint`, `MBREquals`, `MBRIntersects`, `MBROverlaps`, `MBRTouches`, `MBRWithin`. |
| `geo_geojson.sql` | `ST_AsGeoJSON` (with `maxdecimaldigits`) and `ST_GeomFromGeoJSON` (default SRID 4326, explicit SRID), round-trips, invalid-input rejection. |
| `geo_construct.sql` | `ST_ConvexHull`, `ST_Simplify`, `ST_Collect` (native), with SRID preservation. |
| `geo_lineref.sql` | Linear referencing: `ST_LineInterpolatePoint`, `ST_LineInterpolatePoints`, `ST_PointAtDistance` (planar). |
| `geo_discrete.sql` | Discrete curve distances `ST_FrechetDistance`, `ST_HausdorffDistance` (planar). |
| `geo_overlay.sql` | Polygon Boolean overlay `ST_Union`, `ST_Intersection`, `ST_Difference`, `ST_SymDifference` (Martinez-Rueda), area-checked. |
| `geo_buffer.sql` | `ST_Buffer(geom, distance [, segs_per_quarter])` (planar Minkowski-sum buffer via union). |

Together these exercise every implemented `ST_*` function (the I/O constructors
and accessors, the unary measures and derived geometries, the binary distance
and relationship predicates, the validity predicates, `ST_SRID`, the WKB
binary I/O, GeoHash, MBR predicates, GeoJSON, the native constructive ops
— convex hull, simplify, collect, buffer — linear referencing, discrete curve
distances, and the polygon Boolean overlay) plus their synonyms.

## Generating the `.result` files

These are `.sql` test inputs. Generate the paired `.result` files against a
running MatrixOne with mo-tester:

```bash
cd /root/mo-tester
./run.sh -m genrs -n -g -p /root/matrixone/test/distributed/cases/geo
```

Then run them normally:

```bash
./run.sh -n -g -p /root/matrixone/test/distributed/cases/geo
```

## Scope notes

Tests intentionally cover only what is implemented today. SRID 4326 geodetic
computation is wired into the measures (`ST_Length`/`ST_Distance`/`ST_Area`)
and into local-window topology/overlay evaluation across the antimeridian.
Ambiguous windows spanning 180 degrees or containing pole vertices are
rejected explicitly; the existing Cartesian relationship path remains
unchanged for SRID 0.
